import{gk as i}from"./entry.7401566a.js";const n=o=>["",...i].includes(o);export{n as i};
