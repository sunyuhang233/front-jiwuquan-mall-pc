import{gl as i}from"./entry.1d0ff192.js";const n=o=>["",...i].includes(o);export{n as i};
