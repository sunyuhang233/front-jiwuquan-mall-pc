import{hc as o}from"./entry.1d0ff192.js";const r=()=>o("color-mode").value;export{r as u};
