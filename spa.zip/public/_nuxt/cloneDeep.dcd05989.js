import{gs as o}from"./entry.1d0ff192.js";var r=1,n=4;function a(e){return o(e,r|n)}export{a as c};
