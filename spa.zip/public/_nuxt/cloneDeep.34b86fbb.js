import{gr as r}from"./entry.7401566a.js";var o=1,n=4;function a(e){return r(e,o|n)}export{a as c};
