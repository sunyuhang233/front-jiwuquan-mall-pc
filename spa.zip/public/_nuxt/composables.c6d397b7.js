import{hb as o}from"./entry.7401566a.js";const r=()=>o("color-mode").value;export{r as u};
