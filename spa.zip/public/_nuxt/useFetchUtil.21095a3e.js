import{b9 as a}from"./entry.7401566a.js";const s=a,r=`${s}/res/`,o=`${s}/res/`;export{r as B,o as a,s as b};
