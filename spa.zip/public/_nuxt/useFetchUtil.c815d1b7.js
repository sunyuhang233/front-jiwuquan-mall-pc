import{ba as a}from"./entry.1d0ff192.js";const s=a,r=`${s}/res/`,o=`${s}/res/`;export{r as B,o as a,s as b};
