const client_manifest = {
  "Footer.css": {
    "resourceType": "style",
    "file": "Footer.dca36282.css",
    "src": "Footer.css"
  },
  "GoodsList.css": {
    "resourceType": "style",
    "file": "GoodsList.00ac3138.css",
    "src": "GoodsList.css"
  },
  "RightButtons.css": {
    "resourceType": "style",
    "file": "RightButtons.add1503b.css",
    "src": "RightButtons.css"
  },
  "ShopLine.css": {
    "resourceType": "style",
    "file": "ShopLine.bde401b7.css",
    "src": "ShopLine.css"
  },
  "Switch.css": {
    "resourceType": "style",
    "file": "Switch.6e8449cf.css",
    "src": "Switch.css"
  },
  "_AutoIncre.vue.aa839dd8.js": {
    "resourceType": "script",
    "module": true,
    "file": "AutoIncre.vue.aa839dd8.js",
    "imports": [
      "_index.a21fd3fe.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "_DelayTimer.vue.fcf975ff.js": {
    "resourceType": "script",
    "module": true,
    "file": "DelayTimer.vue.fcf975ff.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_Footer.5833f65c.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "kiwi_strong.302ebbc3.svg",
      "logo_txt.318d9294.png"
    ],
    "css": [
      "Footer.dca36282.css",
      "popover.1f4352fc.css"
    ],
    "file": "Footer.5833f65c.js",
    "imports": [
      "_nuxt-link.076cd19c.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js",
      "_RightButtons.f41c795a.js",
      "_Switch.b372799a.js",
      "_index.7d8b4588.js",
      "_avatar.504d33a6.js",
      "_upload.879ac519.js",
      "_progress.de31a7be.js",
      "_popper.51715de2.js",
      "_message-box.1728334f.js",
      "_overlay.a57d50d1.js",
      "_useFetchUtil.c815d1b7.js"
    ]
  },
  "Footer.dca36282.css": {
    "file": "Footer.dca36282.css",
    "resourceType": "style"
  },
  "popover.1f4352fc.css": {
    "file": "popover.1f4352fc.css",
    "resourceType": "style"
  },
  "kiwi_strong.302ebbc3.svg": {
    "file": "kiwi_strong.302ebbc3.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "logo_txt.318d9294.png": {
    "file": "logo_txt.318d9294.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "_GoodsList.4851e079.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "GoodsList.00ac3138.css"
    ],
    "file": "GoodsList.4851e079.js",
    "imports": [
      "_image-viewer.a57f8530.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_useFetchUtil.c815d1b7.js",
      "_swiper-vue.87e2a882.js",
      "_nuxt-link.076cd19c.js",
      "_AutoIncre.vue.aa839dd8.js"
    ]
  },
  "GoodsList.00ac3138.css": {
    "file": "GoodsList.00ac3138.css",
    "resourceType": "style"
  },
  "_RightButtons.f41c795a.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "logo_dark.692df090.png"
    ],
    "css": [
      "RightButtons.add1503b.css",
      "popover.1f4352fc.css",
      "checkbox-group.987ef89c.css",
      "tooltip.e3b0c442.css"
    ],
    "file": "RightButtons.f41c795a.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_index.7d8b4588.js",
      "_popper.51715de2.js",
      "_swiper-vue.87e2a882.js",
      "_nuxt-link.076cd19c.js",
      "_checkbox.27f8a384.js",
      "_ShopLine.9dae93ba.js",
      "_scrollbar.338d4a20.js",
      "_message-box.1728334f.js",
      "_overlay.a57d50d1.js",
      "_index.3404649f.js"
    ]
  },
  "RightButtons.add1503b.css": {
    "file": "RightButtons.add1503b.css",
    "resourceType": "style"
  },
  "checkbox-group.987ef89c.css": {
    "file": "checkbox-group.987ef89c.css",
    "resourceType": "style"
  },
  "tooltip.e3b0c442.css": {
    "file": "tooltip.e3b0c442.css",
    "resourceType": "style"
  },
  "logo_dark.692df090.png": {
    "file": "logo_dark.692df090.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "_ShopLine.9dae93ba.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "ShopLine.bde401b7.css"
    ],
    "file": "ShopLine.9dae93ba.js",
    "imports": [
      "_image-viewer.a57f8530.js",
      "_nuxt-link.076cd19c.js",
      "_select.db777ad8.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_input-number.a0212393.js",
      "_tag.55f0b9b2.js",
      "_scrollbar.338d4a20.js",
      "_popper.51715de2.js",
      "_message-box.1728334f.js",
      "_overlay.a57d50d1.js",
      "_useFetchUtil.c815d1b7.js",
      "_sku.f9edecf6.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "ShopLine.bde401b7.css": {
    "file": "ShopLine.bde401b7.css",
    "resourceType": "style"
  },
  "_Switch.b372799a.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "sun.bc0856fb.svg",
      "moon.768cb03d.svg"
    ],
    "css": [
      "Switch.6e8449cf.css"
    ],
    "file": "Switch.b372799a.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_composables.3b53c41a.js",
      "_index.a21fd3fe.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "Switch.6e8449cf.css": {
    "file": "Switch.6e8449cf.css",
    "resourceType": "style"
  },
  "sun.bc0856fb.svg": {
    "file": "sun.bc0856fb.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "moon.768cb03d.svg": {
    "file": "moon.768cb03d.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "_arrays.e667dc24.js": {
    "resourceType": "script",
    "module": true,
    "file": "arrays.e667dc24.js"
  },
  "_avatar.504d33a6.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "avatar.71943dab.css"
    ],
    "file": "avatar.504d33a6.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "avatar.71943dab.css": {
    "file": "avatar.71943dab.css",
    "resourceType": "style"
  },
  "_bills.834030d1.js": {
    "resourceType": "script",
    "module": true,
    "file": "bills.834030d1.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_category.f0a8bcdc.js": {
    "resourceType": "script",
    "module": true,
    "file": "category.f0a8bcdc.js",
    "imports": [
      "_nuxt-link.076cd19c.js",
      "_useFetchUtil.c815d1b7.js"
    ]
  },
  "_checkbox.27f8a384.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "checkbox.3d04fbdb.css"
    ],
    "file": "checkbox.27f8a384.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_isEqual.fb3c55d2.js",
      "_flatten.0dbf6d4b.js"
    ]
  },
  "checkbox.3d04fbdb.css": {
    "file": "checkbox.3d04fbdb.css",
    "resourceType": "style"
  },
  "_cloneDeep.dcd05989.js": {
    "resourceType": "script",
    "module": true,
    "file": "cloneDeep.dcd05989.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_collect.fef0a0f2.js": {
    "resourceType": "script",
    "module": true,
    "file": "collect.fef0a0f2.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_composables.3b53c41a.js": {
    "resourceType": "script",
    "module": true,
    "file": "composables.3b53c41a.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_debounce.3beb343f.js": {
    "resourceType": "script",
    "module": true,
    "file": "debounce.3beb343f.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_divider.d4f2f936.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "divider.07810808.css"
    ],
    "file": "divider.d4f2f936.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "divider.07810808.css": {
    "file": "divider.07810808.css",
    "resourceType": "style"
  },
  "_flatten.0dbf6d4b.js": {
    "resourceType": "script",
    "module": true,
    "file": "flatten.0dbf6d4b.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_focus-trap.ef80684b.js": {
    "resourceType": "script",
    "module": true,
    "file": "focus-trap.ef80684b.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_image-viewer.a57f8530.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "image-viewer.bcc58336.css"
    ],
    "file": "image-viewer.a57f8530.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js",
      "_debounce.3beb343f.js",
      "_scroll.93faf99e.js"
    ]
  },
  "image-viewer.bcc58336.css": {
    "file": "image-viewer.bcc58336.css",
    "resourceType": "style"
  },
  "_index.1af78815.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.1af78815.js",
    "imports": [
      "_vnode.98844ac6.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "_index.1e34d4fc.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.1e34d4fc.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.3404649f.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.3404649f.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "_image-viewer.a57f8530.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_scroll.93faf99e.js"
    ]
  },
  "_index.37a97259.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.37a97259.js",
    "imports": [
      "_swiper-vue.87e2a882.js"
    ]
  },
  "_index.44abc126.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.44abc126.js",
    "imports": [
      "_nuxt-link.076cd19c.js",
      "_useFetchUtil.c815d1b7.js"
    ]
  },
  "_index.721d6832.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.721d6832.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "_index.7d8b4588.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.7d8b4588.js",
    "imports": [
      "_popper.51715de2.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "_index.a21fd3fe.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.a21fd3fe.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "_index.f2acc437.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.f2acc437.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_input-number.a0212393.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "input-number.706384ee.css"
    ],
    "file": "input-number.a0212393.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_index.37a97259.js"
    ]
  },
  "input-number.706384ee.css": {
    "file": "input-number.706384ee.css",
    "resourceType": "style"
  },
  "_isEqual.fb3c55d2.js": {
    "resourceType": "script",
    "module": true,
    "file": "isEqual.fb3c55d2.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_localeData.0b229474.js": {
    "resourceType": "script",
    "module": true,
    "file": "localeData.0b229474.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "_menu.c0494e22.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "menu.d3c11cc9.css"
    ],
    "file": "menu.c0494e22.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_message-box.1728334f.js",
      "_swiper-vue.87e2a882.js",
      "_index.f2acc437.js",
      "_popper.51715de2.js",
      "_vnode.98844ac6.js"
    ]
  },
  "menu.d3c11cc9.css": {
    "file": "menu.d3c11cc9.css",
    "resourceType": "style"
  },
  "_message-box.1728334f.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "message-box.7f332db5.css"
    ],
    "file": "message-box.1728334f.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_overlay.a57d50d1.js",
      "_focus-trap.ef80684b.js",
      "_validator.409c16d0.js"
    ]
  },
  "message-box.7f332db5.css": {
    "file": "message-box.7f332db5.css",
    "resourceType": "style"
  },
  "_notification.5c26b3d0.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "notification.af5dcd65.css"
    ],
    "file": "notification.5c26b3d0.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "notification.af5dcd65.css": {
    "file": "notification.af5dcd65.css",
    "resourceType": "style"
  },
  "_nuxt-link.076cd19c.js": {
    "resourceType": "script",
    "module": true,
    "file": "nuxt-link.076cd19c.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "_overlay.a57d50d1.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "overlay.6e0625dd.css"
    ],
    "file": "overlay.a57d50d1.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js",
      "_scroll.93faf99e.js",
      "_vnode.98844ac6.js"
    ]
  },
  "overlay.6e0625dd.css": {
    "file": "overlay.6e0625dd.css",
    "resourceType": "style"
  },
  "_popper.51715de2.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "popper.0d433965.css"
    ],
    "file": "popper.51715de2.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js",
      "_focus-trap.ef80684b.js"
    ]
  },
  "popper.0d433965.css": {
    "file": "popper.0d433965.css",
    "resourceType": "style"
  },
  "_progress.de31a7be.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "progress.1f193c71.css"
    ],
    "file": "progress.de31a7be.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "progress.1f193c71.css": {
    "file": "progress.1f193c71.css",
    "resourceType": "style"
  },
  "_radio.f3092f9b.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "radio.2efacd0a.css"
    ],
    "file": "radio.f3092f9b.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "radio.2efacd0a.css": {
    "file": "radio.2efacd0a.css",
    "resourceType": "style"
  },
  "_rand.14326ce1.js": {
    "resourceType": "script",
    "module": true,
    "file": "rand.14326ce1.js"
  },
  "_rate.2ee4464f.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "rate.22f46704.css"
    ],
    "file": "rate.2ee4464f.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "rate.22f46704.css": {
    "file": "rate.22f46704.css",
    "resourceType": "style"
  },
  "_scroll.93faf99e.js": {
    "resourceType": "script",
    "module": true,
    "file": "scroll.93faf99e.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_scrollbar.338d4a20.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "scrollbar.77c43fec.css"
    ],
    "file": "scrollbar.338d4a20.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "scrollbar.77c43fec.css": {
    "file": "scrollbar.77c43fec.css",
    "resourceType": "style"
  },
  "_select.db777ad8.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "select.d289ec57.css"
    ],
    "file": "select.db777ad8.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_popper.51715de2.js",
      "_scrollbar.338d4a20.js",
      "_tag.55f0b9b2.js",
      "_strings.1a075906.js",
      "_scroll.93faf99e.js",
      "_isEqual.fb3c55d2.js",
      "_debounce.3beb343f.js",
      "_index.1e34d4fc.js",
      "_validator.409c16d0.js"
    ]
  },
  "select.d289ec57.css": {
    "file": "select.d289ec57.css",
    "resourceType": "style"
  },
  "_sku.f9edecf6.js": {
    "resourceType": "script",
    "module": true,
    "file": "sku.f9edecf6.js",
    "imports": [
      "_nuxt-link.076cd19c.js",
      "_useFetchUtil.c815d1b7.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_strings.1a075906.js": {
    "resourceType": "script",
    "module": true,
    "file": "strings.1a075906.js",
    "imports": [
      "_swiper-vue.87e2a882.js"
    ]
  },
  "_swiper-vue.87e2a882.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "swiper-vue.9c2b2ee8.css"
    ],
    "file": "swiper-vue.87e2a882.js"
  },
  "swiper-vue.9c2b2ee8.css": {
    "file": "swiper-vue.9c2b2ee8.css",
    "resourceType": "style"
  },
  "_tabs.79de4b2d.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "tabs.ddb6c28f.css"
    ],
    "file": "tabs.79de4b2d.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_strings.1a075906.js",
      "_swiper-vue.87e2a882.js",
      "_index.1af78815.js"
    ]
  },
  "tabs.ddb6c28f.css": {
    "file": "tabs.ddb6c28f.css",
    "resourceType": "style"
  },
  "_tag.55f0b9b2.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "tag.da83e147.css"
    ],
    "file": "tag.55f0b9b2.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "tag.da83e147.css": {
    "file": "tag.da83e147.css",
    "resourceType": "style"
  },
  "_upload.879ac519.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "upload.40d65e69.css"
    ],
    "file": "upload.879ac519.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_progress.de31a7be.js",
      "_cloneDeep.dcd05989.js",
      "_isEqual.fb3c55d2.js"
    ]
  },
  "upload.40d65e69.css": {
    "file": "upload.40d65e69.css",
    "resourceType": "style"
  },
  "_useFetchUtil.c815d1b7.js": {
    "resourceType": "script",
    "module": true,
    "file": "useFetchUtil.c815d1b7.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_validator.409c16d0.js": {
    "resourceType": "script",
    "module": true,
    "file": "validator.409c16d0.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_vnode.98844ac6.js": {
    "resourceType": "script",
    "module": true,
    "file": "vnode.98844ac6.js",
    "imports": [
      "_swiper-vue.87e2a882.js"
    ]
  },
  "assets/images/icon/moon.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "moon.768cb03d.svg",
    "src": "assets/images/icon/moon.svg"
  },
  "assets/images/icon/success_cone.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "success_cone.dbb5ad81.svg",
    "src": "assets/images/icon/success_cone.svg"
  },
  "assets/images/icon/sun.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "sun.bc0856fb.svg",
    "src": "assets/images/icon/sun.svg"
  },
  "assets/images/logo/kiwi_strong.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "kiwi_strong.302ebbc3.svg",
    "src": "assets/images/logo/kiwi_strong.svg"
  },
  "assets/images/logo/logo.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "logo.d378a10a.png",
    "src": "assets/images/logo/logo.png"
  },
  "assets/images/logo/logo_dark.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "logo_dark.692df090.png",
    "src": "assets/images/logo/logo_dark.png"
  },
  "assets/images/logo/logo_txt.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "logo_txt.318d9294.png",
    "src": "assets/images/logo/logo_txt.png"
  },
  "assets/images/other/index_bg.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "index_bg.496ee798.png",
    "src": "assets/images/other/index_bg.png"
  },
  "avatar.css": {
    "resourceType": "style",
    "file": "avatar.71943dab.css",
    "src": "avatar.css"
  },
  "checkbox-group.css": {
    "resourceType": "style",
    "file": "checkbox-group.987ef89c.css",
    "src": "checkbox-group.css"
  },
  "checkbox.css": {
    "resourceType": "style",
    "file": "checkbox.3d04fbdb.css",
    "src": "checkbox.css"
  },
  "dialog.css": {
    "resourceType": "style",
    "file": "dialog.c614b8ee.css",
    "src": "dialog.css"
  },
  "divider.css": {
    "resourceType": "style",
    "file": "divider.07810808.css",
    "src": "divider.css"
  },
  "image-viewer.css": {
    "resourceType": "style",
    "file": "image-viewer.bcc58336.css",
    "src": "image-viewer.css"
  },
  "input-number.css": {
    "resourceType": "style",
    "file": "input-number.706384ee.css",
    "src": "input-number.css"
  },
  "layouts/error.vue": {
    "resourceType": "script",
    "module": true,
    "file": "error.b6a9be4b.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/error.vue"
  },
  "layouts/main.css": {
    "resourceType": "style",
    "file": "main.8299cc0d.css",
    "src": "layouts/main.css"
  },
  "layouts/main.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "main.8299cc0d.css",
      "tooltip.e3b0c442.css",
      "popover.1f4352fc.css",
      "checkbox-group.987ef89c.css"
    ],
    "file": "main.0a4540c2.js",
    "imports": [
      "_Footer.5833f65c.js",
      "_image-viewer.a57f8530.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_useFetchUtil.c815d1b7.js",
      "_menu.c0494e22.js",
      "_swiper-vue.87e2a882.js",
      "_scrollbar.338d4a20.js",
      "_popper.51715de2.js",
      "_nuxt-link.076cd19c.js",
      "_RightButtons.f41c795a.js",
      "_index.a21fd3fe.js",
      "_Switch.b372799a.js",
      "_composables.3b53c41a.js",
      "_index.7d8b4588.js",
      "_avatar.504d33a6.js",
      "_upload.879ac519.js",
      "_progress.de31a7be.js",
      "_cloneDeep.dcd05989.js",
      "_isEqual.fb3c55d2.js",
      "_message-box.1728334f.js",
      "_overlay.a57d50d1.js",
      "_scroll.93faf99e.js",
      "_vnode.98844ac6.js",
      "_focus-trap.ef80684b.js",
      "_validator.409c16d0.js",
      "_debounce.3beb343f.js",
      "_index.f2acc437.js",
      "_checkbox.27f8a384.js",
      "_flatten.0dbf6d4b.js",
      "_ShopLine.9dae93ba.js",
      "_select.db777ad8.js",
      "_tag.55f0b9b2.js",
      "_strings.1a075906.js",
      "_index.1e34d4fc.js",
      "_input-number.a0212393.js",
      "_index.37a97259.js",
      "_sku.f9edecf6.js",
      "_index.3404649f.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/main.vue"
  },
  "main.8299cc0d.css": {
    "file": "main.8299cc0d.css",
    "resourceType": "style"
  },
  "layouts/second.css": {
    "resourceType": "style",
    "file": "second.c4a23853.css",
    "src": "layouts/second.css"
  },
  "layouts/second.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "second.c4a23853.css",
      "popover.1f4352fc.css",
      "checkbox-group.987ef89c.css",
      "tooltip.e3b0c442.css"
    ],
    "file": "second.d9650c13.js",
    "imports": [
      "_Footer.5833f65c.js",
      "_RightButtons.f41c795a.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js",
      "_nuxt-link.076cd19c.js",
      "_Switch.b372799a.js",
      "_composables.3b53c41a.js",
      "_index.a21fd3fe.js",
      "_index.7d8b4588.js",
      "_popper.51715de2.js",
      "_focus-trap.ef80684b.js",
      "_avatar.504d33a6.js",
      "_upload.879ac519.js",
      "_progress.de31a7be.js",
      "_cloneDeep.dcd05989.js",
      "_isEqual.fb3c55d2.js",
      "_message-box.1728334f.js",
      "_overlay.a57d50d1.js",
      "_scroll.93faf99e.js",
      "_vnode.98844ac6.js",
      "_validator.409c16d0.js",
      "_useFetchUtil.c815d1b7.js",
      "_checkbox.27f8a384.js",
      "_flatten.0dbf6d4b.js",
      "_ShopLine.9dae93ba.js",
      "_image-viewer.a57f8530.js",
      "_debounce.3beb343f.js",
      "_select.db777ad8.js",
      "_scrollbar.338d4a20.js",
      "_tag.55f0b9b2.js",
      "_strings.1a075906.js",
      "_index.1e34d4fc.js",
      "_input-number.a0212393.js",
      "_index.37a97259.js",
      "_sku.f9edecf6.js",
      "_index.3404649f.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/second.vue"
  },
  "second.c4a23853.css": {
    "file": "second.c4a23853.css",
    "resourceType": "style"
  },
  "layouts/user.css": {
    "resourceType": "style",
    "file": "user.2f9261e3.css",
    "src": "layouts/user.css"
  },
  "layouts/user.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "user.2f9261e3.css",
      "popover.1f4352fc.css",
      "tooltip.e3b0c442.css",
      "checkbox-group.987ef89c.css"
    ],
    "file": "user.677ba332.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.076cd19c.js",
      "_Switch.b372799a.js",
      "_index.7d8b4588.js",
      "_popper.51715de2.js",
      "_message-box.1728334f.js",
      "_overlay.a57d50d1.js",
      "_useFetchUtil.c815d1b7.js",
      "_swiper-vue.87e2a882.js",
      "_RightButtons.f41c795a.js",
      "_menu.c0494e22.js",
      "_index.a21fd3fe.js",
      "_composables.3b53c41a.js",
      "_focus-trap.ef80684b.js",
      "_validator.409c16d0.js",
      "_scroll.93faf99e.js",
      "_vnode.98844ac6.js",
      "_checkbox.27f8a384.js",
      "_isEqual.fb3c55d2.js",
      "_flatten.0dbf6d4b.js",
      "_ShopLine.9dae93ba.js",
      "_image-viewer.a57f8530.js",
      "_debounce.3beb343f.js",
      "_select.db777ad8.js",
      "_scrollbar.338d4a20.js",
      "_tag.55f0b9b2.js",
      "_strings.1a075906.js",
      "_index.1e34d4fc.js",
      "_input-number.a0212393.js",
      "_index.37a97259.js",
      "_sku.f9edecf6.js",
      "_index.3404649f.js",
      "_index.f2acc437.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/user.vue"
  },
  "user.2f9261e3.css": {
    "file": "user.2f9261e3.css",
    "resourceType": "style"
  },
  "menu.css": {
    "resourceType": "style",
    "file": "menu.d3c11cc9.css",
    "src": "menu.css"
  },
  "message-box.css": {
    "resourceType": "style",
    "file": "message-box.7f332db5.css",
    "src": "message-box.css"
  },
  "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/dialog/index.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "index.9619c765.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "_overlay.a57d50d1.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_focus-trap.ef80684b.js",
      "_scroll.93faf99e.js",
      "_vnode.98844ac6.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/dialog/index.mjs"
  },
  "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/text/index.css": {
    "resourceType": "style",
    "file": "index.779bf283.css",
    "src": "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/text/index.css"
  },
  "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/text/index.mjs": {
    "resourceType": "script",
    "module": true,
    "css": [
      "index.779bf283.css"
    ],
    "file": "index.0d74788c.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/text/index.mjs"
  },
  "index.779bf283.css": {
    "file": "index.779bf283.css",
    "resourceType": "style"
  },
  "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.9503c545.css",
    "src": "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "logo.d378a10a.png"
    ],
    "css": [
      "entry.9503c545.css"
    ],
    "dynamicImports": [
      "layouts/error.vue",
      "layouts/main.vue",
      "layouts/second.vue",
      "layouts/user.vue",
      "node_modules/.pnpm/workbox-window@7.0.0/node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
    ],
    "file": "entry.1d0ff192.js",
    "imports": [
      "_swiper-vue.87e2a882.js"
    ],
    "isEntry": true,
    "src": "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
  },
  "entry.9503c545.css": {
    "file": "entry.9503c545.css",
    "resourceType": "style"
  },
  "logo.d378a10a.png": {
    "file": "logo.d378a10a.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "node_modules/.pnpm/workbox-window@7.0.0/node_modules/workbox-window/build/workbox-window.prod.es5.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "workbox-window.prod.es5.a7b12eab.js",
    "isDynamicEntry": true,
    "src": "node_modules/.pnpm/workbox-window@7.0.0/node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
  },
  "notification.css": {
    "resourceType": "style",
    "file": "notification.af5dcd65.css",
    "src": "notification.css"
  },
  "overlay.css": {
    "resourceType": "style",
    "file": "overlay.6e0625dd.css",
    "src": "overlay.css"
  },
  "pages/[...all].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_...all_.a27f233e.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/[...all].vue"
  },
  "pages/category/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.feddc1f9.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/category/index.vue"
  },
  "pages/community/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.b7cd6de3.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/index.vue"
  },
  "pages/event/detail.css": {
    "resourceType": "style",
    "file": "detail.9ceddf54.css",
    "src": "pages/event/detail.css"
  },
  "pages/event/detail.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "detail.9ceddf54.css"
    ],
    "file": "detail.075acde0.js",
    "imports": [
      "_image-viewer.a57f8530.js",
      "_tag.55f0b9b2.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_useFetchUtil.c815d1b7.js",
      "_swiper-vue.87e2a882.js",
      "_nuxt-link.076cd19c.js",
      "_index.721d6832.js",
      "_index.44abc126.js",
      "_debounce.3beb343f.js",
      "_scroll.93faf99e.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/event/detail.vue"
  },
  "detail.9ceddf54.css": {
    "file": "detail.9ceddf54.css",
    "resourceType": "style"
  },
  "pages/goods/comments/[id].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_id_.f2b5a7cb.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/comments/[id].vue"
  },
  "pages/goods/detail/[id].css": {
    "resourceType": "style",
    "file": "_id_.2d175b3f.css",
    "src": "pages/goods/detail/[id].css"
  },
  "pages/goods/detail/[id].vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "_id_.2d175b3f.css",
      "popover.1f4352fc.css",
      "radio-group.3b9ac3ad.css",
      "dialog.c614b8ee.css"
    ],
    "file": "_id_.2ecfa979.js",
    "imports": [
      "_nuxt-link.076cd19c.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js",
      "_category.f0a8bcdc.js",
      "_image-viewer.a57f8530.js",
      "_index.1af78815.js",
      "_useFetchUtil.c815d1b7.js",
      "_tag.55f0b9b2.js",
      "_popper.51715de2.js",
      "_collect.fef0a0f2.js",
      "_radio.f3092f9b.js",
      "_input-number.a0212393.js",
      "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/text/index.mjs",
      "_tabs.79de4b2d.js",
      "_rate.2ee4464f.js",
      "_scrollbar.338d4a20.js",
      "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/dialog/index.mjs",
      "_overlay.a57d50d1.js",
      "_index.3404649f.js",
      "_index.f2acc437.js",
      "_rand.14326ce1.js",
      "_GoodsList.4851e079.js",
      "_index.721d6832.js",
      "_sku.f9edecf6.js",
      "_debounce.3beb343f.js",
      "_scroll.93faf99e.js",
      "_vnode.98844ac6.js",
      "_focus-trap.ef80684b.js",
      "_index.37a97259.js",
      "_strings.1a075906.js",
      "_AutoIncre.vue.aa839dd8.js",
      "_index.a21fd3fe.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/detail/[id].vue"
  },
  "_id_.2d175b3f.css": {
    "file": "_id_.2d175b3f.css",
    "resourceType": "style"
  },
  "radio-group.3b9ac3ad.css": {
    "file": "radio-group.3b9ac3ad.css",
    "resourceType": "style"
  },
  "dialog.c614b8ee.css": {
    "file": "dialog.c614b8ee.css",
    "resourceType": "style"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.7d1d95b8.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "index_bg.496ee798.png"
    ],
    "css": [
      "index.7d1d95b8.css",
      "popover.1f4352fc.css"
    ],
    "file": "index.943ae561.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_tag.55f0b9b2.js",
      "_image-viewer.a57f8530.js",
      "_useFetchUtil.c815d1b7.js",
      "_swiper-vue.87e2a882.js",
      "_divider.d4f2f936.js",
      "_nuxt-link.076cd19c.js",
      "_scrollbar.338d4a20.js",
      "_index.7d8b4588.js",
      "_popper.51715de2.js",
      "_index.a21fd3fe.js",
      "_GoodsList.4851e079.js",
      "_index.44abc126.js",
      "_AutoIncre.vue.aa839dd8.js",
      "_category.f0a8bcdc.js",
      "_tabs.79de4b2d.js",
      "_debounce.3beb343f.js",
      "_scroll.93faf99e.js",
      "_focus-trap.ef80684b.js",
      "_strings.1a075906.js",
      "_index.1af78815.js",
      "_vnode.98844ac6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.7d1d95b8.css": {
    "file": "index.7d1d95b8.css",
    "resourceType": "style"
  },
  "index_bg.496ee798.png": {
    "file": "index_bg.496ee798.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "pages/order/comment/[id].css": {
    "resourceType": "style",
    "file": "_id_.b84d9efa.css",
    "src": "pages/order/comment/[id].css"
  },
  "pages/order/comment/[id].vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "success_cone.dbb5ad81.svg"
    ],
    "css": [
      "_id_.b84d9efa.css",
      "dialog.c614b8ee.css"
    ],
    "file": "_id_.1990dedd.js",
    "imports": [
      "_Switch.b372799a.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_progress.de31a7be.js",
      "_upload.879ac519.js",
      "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/dialog/index.mjs",
      "_overlay.a57d50d1.js",
      "_message-box.1728334f.js",
      "_swiper-vue.87e2a882.js",
      "_image-viewer.a57f8530.js",
      "_useFetchUtil.c815d1b7.js",
      "_rate.2ee4464f.js",
      "_checkbox.27f8a384.js",
      "_index.a21fd3fe.js",
      "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/text/index.mjs",
      "_notification.5c26b3d0.js",
      "_composables.3b53c41a.js",
      "_cloneDeep.dcd05989.js",
      "_isEqual.fb3c55d2.js",
      "_focus-trap.ef80684b.js",
      "_scroll.93faf99e.js",
      "_vnode.98844ac6.js",
      "_validator.409c16d0.js",
      "_debounce.3beb343f.js",
      "_flatten.0dbf6d4b.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/comment/[id].vue"
  },
  "_id_.b84d9efa.css": {
    "file": "_id_.b84d9efa.css",
    "resourceType": "style"
  },
  "success_cone.dbb5ad81.svg": {
    "file": "success_cone.dbb5ad81.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "pages/order/detail.css": {
    "resourceType": "style",
    "file": "detail.a5f28f24.css",
    "src": "pages/order/detail.css"
  },
  "pages/order/detail.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "detail.a5f28f24.css",
      "radio-group.3b9ac3ad.css"
    ],
    "dynamicImports": [
      "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/text/index.mjs"
    ],
    "file": "detail.adc82395.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_image-viewer.a57f8530.js",
      "_nuxt-link.076cd19c.js",
      "_divider.d4f2f936.js",
      "_DelayTimer.vue.fcf975ff.js",
      "_swiper-vue.87e2a882.js",
      "_Switch.b372799a.js",
      "_index.1af78815.js",
      "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/text/index.mjs",
      "_bills.834030d1.js",
      "_radio.f3092f9b.js",
      "_tag.55f0b9b2.js",
      "_scrollbar.338d4a20.js",
      "_select.db777ad8.js",
      "_input-number.a0212393.js",
      "_popper.51715de2.js",
      "_useFetchUtil.c815d1b7.js",
      "_sku.f9edecf6.js",
      "_notification.5c26b3d0.js",
      "_message-box.1728334f.js",
      "_overlay.a57d50d1.js",
      "_debounce.3beb343f.js",
      "_scroll.93faf99e.js",
      "_composables.3b53c41a.js",
      "_index.a21fd3fe.js",
      "_vnode.98844ac6.js",
      "_strings.1a075906.js",
      "_isEqual.fb3c55d2.js",
      "_index.1e34d4fc.js",
      "_validator.409c16d0.js",
      "_index.37a97259.js",
      "_focus-trap.ef80684b.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/detail.vue"
  },
  "detail.a5f28f24.css": {
    "file": "detail.a5f28f24.css",
    "resourceType": "style"
  },
  "pages/order/list.css": {
    "resourceType": "style",
    "file": "list.ae6b4ade.css",
    "src": "pages/order/list.css"
  },
  "pages/order/list.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "list.ae6b4ade.css"
    ],
    "file": "list.5c9e3279.js",
    "imports": [
      "_divider.d4f2f936.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_localeData.0b229474.js",
      "_swiper-vue.87e2a882.js",
      "_arrays.e667dc24.js",
      "_flatten.0dbf6d4b.js",
      "_popper.51715de2.js",
      "_scrollbar.338d4a20.js",
      "_index.37a97259.js",
      "_debounce.3beb343f.js",
      "_index.1e34d4fc.js",
      "_isEqual.fb3c55d2.js",
      "_DelayTimer.vue.fcf975ff.js",
      "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/text/index.mjs",
      "_image-viewer.a57f8530.js",
      "_tag.55f0b9b2.js",
      "_useFetchUtil.c815d1b7.js",
      "_message-box.1728334f.js",
      "_overlay.a57d50d1.js",
      "_notification.5c26b3d0.js",
      "_index.3404649f.js",
      "_tabs.79de4b2d.js",
      "_focus-trap.ef80684b.js",
      "_scroll.93faf99e.js",
      "_validator.409c16d0.js",
      "_vnode.98844ac6.js",
      "_strings.1a075906.js",
      "_index.1af78815.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/list.vue"
  },
  "list.ae6b4ade.css": {
    "file": "list.ae6b4ade.css",
    "resourceType": "style"
  },
  "pages/search/index.css": {
    "resourceType": "style",
    "file": "index.7a00cec5.css",
    "src": "pages/search/index.css"
  },
  "pages/search/index.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "index.7a00cec5.css"
    ],
    "file": "index.c8eed2e2.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_checkbox.27f8a384.js",
      "_select.db777ad8.js",
      "_tag.55f0b9b2.js",
      "_GoodsList.4851e079.js",
      "_scrollbar.338d4a20.js",
      "_popper.51715de2.js",
      "_swiper-vue.87e2a882.js",
      "_index.a21fd3fe.js",
      "_isEqual.fb3c55d2.js",
      "_flatten.0dbf6d4b.js",
      "_strings.1a075906.js",
      "_scroll.93faf99e.js",
      "_debounce.3beb343f.js",
      "_index.1e34d4fc.js",
      "_validator.409c16d0.js",
      "_image-viewer.a57f8530.js",
      "_useFetchUtil.c815d1b7.js",
      "_nuxt-link.076cd19c.js",
      "_AutoIncre.vue.aa839dd8.js",
      "_focus-trap.ef80684b.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/search/index.vue"
  },
  "index.7a00cec5.css": {
    "file": "index.7a00cec5.css",
    "resourceType": "style"
  },
  "pages/user/address.css": {
    "resourceType": "style",
    "file": "address.4d7fe403.css",
    "src": "pages/user/address.css"
  },
  "pages/user/address.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "address.4d7fe403.css",
      "dialog.c614b8ee.css",
      "checkbox-group.987ef89c.css"
    ],
    "dynamicImports": [
      "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/dialog/index.mjs"
    ],
    "file": "address.f29e5a89.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/text/index.mjs",
      "_swiper-vue.87e2a882.js",
      "_scrollbar.338d4a20.js",
      "_checkbox.27f8a384.js",
      "_radio.f3092f9b.js",
      "_rand.14326ce1.js",
      "_strings.1a075906.js",
      "_isEqual.fb3c55d2.js",
      "_message-box.1728334f.js",
      "_arrays.e667dc24.js",
      "_scroll.93faf99e.js",
      "_flatten.0dbf6d4b.js",
      "_cloneDeep.dcd05989.js",
      "_popper.51715de2.js",
      "_tag.55f0b9b2.js",
      "_index.1e34d4fc.js",
      "_debounce.3beb343f.js",
      "_divider.d4f2f936.js",
      "_overlay.a57d50d1.js",
      "_focus-trap.ef80684b.js",
      "_validator.409c16d0.js",
      "_vnode.98844ac6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/address.vue"
  },
  "address.4d7fe403.css": {
    "file": "address.4d7fe403.css",
    "resourceType": "style"
  },
  "pages/user/collect.css": {
    "resourceType": "style",
    "file": "collect.d6cd5d85.css",
    "src": "pages/user/collect.css"
  },
  "pages/user/collect.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "collect.d6cd5d85.css",
      "checkbox-group.987ef89c.css"
    ],
    "file": "collect.00878209.js",
    "imports": [
      "_divider.d4f2f936.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_checkbox.27f8a384.js",
      "_image-viewer.a57f8530.js",
      "_useFetchUtil.c815d1b7.js",
      "_swiper-vue.87e2a882.js",
      "_scrollbar.338d4a20.js",
      "_message-box.1728334f.js",
      "_overlay.a57d50d1.js",
      "_collect.fef0a0f2.js",
      "_tabs.79de4b2d.js",
      "_isEqual.fb3c55d2.js",
      "_flatten.0dbf6d4b.js",
      "_debounce.3beb343f.js",
      "_scroll.93faf99e.js",
      "_focus-trap.ef80684b.js",
      "_validator.409c16d0.js",
      "_vnode.98844ac6.js",
      "_strings.1a075906.js",
      "_index.1af78815.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/collect.vue"
  },
  "collect.d6cd5d85.css": {
    "file": "collect.d6cd5d85.css",
    "resourceType": "style"
  },
  "pages/user/info.css": {
    "resourceType": "style",
    "file": "info.e0008b9e.css",
    "src": "pages/user/info.css"
  },
  "pages/user/info.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "info.e0008b9e.css",
      "popover.1f4352fc.css",
      "tooltip.e3b0c442.css"
    ],
    "file": "info.5f5b91a3.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_image-viewer.a57f8530.js",
      "_index.7d8b4588.js",
      "_popper.51715de2.js",
      "_useFetchUtil.c815d1b7.js",
      "_index.a21fd3fe.js",
      "_swiper-vue.87e2a882.js",
      "_upload.879ac519.js",
      "_select.db777ad8.js",
      "_progress.de31a7be.js",
      "_tag.55f0b9b2.js",
      "_scrollbar.338d4a20.js",
      "_tabs.79de4b2d.js",
      "_debounce.3beb343f.js",
      "_scroll.93faf99e.js",
      "_focus-trap.ef80684b.js",
      "_cloneDeep.dcd05989.js",
      "_isEqual.fb3c55d2.js",
      "_strings.1a075906.js",
      "_index.1e34d4fc.js",
      "_validator.409c16d0.js",
      "_index.1af78815.js",
      "_vnode.98844ac6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/info.vue"
  },
  "info.e0008b9e.css": {
    "file": "info.e0008b9e.css",
    "resourceType": "style"
  },
  "pages/user/safe.css": {
    "resourceType": "style",
    "file": "safe.71c0a412.css",
    "src": "pages/user/safe.css"
  },
  "pages/user/safe.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "safe.71c0a412.css"
    ],
    "file": "safe.2777a56e.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_tag.55f0b9b2.js",
      "_swiper-vue.87e2a882.js",
      "_scrollbar.338d4a20.js",
      "_message-box.1728334f.js",
      "_overlay.a57d50d1.js",
      "_avatar.504d33a6.js",
      "_divider.d4f2f936.js",
      "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/text/index.mjs",
      "_useFetchUtil.c815d1b7.js",
      "_focus-trap.ef80684b.js",
      "_validator.409c16d0.js",
      "_scroll.93faf99e.js",
      "_vnode.98844ac6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/safe.vue"
  },
  "safe.71c0a412.css": {
    "file": "safe.71c0a412.css",
    "resourceType": "style"
  },
  "pages/user/shopcart.css": {
    "resourceType": "style",
    "file": "shopcart.08d01407.css",
    "src": "pages/user/shopcart.css"
  },
  "pages/user/shopcart.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "shopcart.08d01407.css",
      "checkbox-group.987ef89c.css"
    ],
    "file": "shopcart.62c1fab1.js",
    "imports": [
      "_checkbox.27f8a384.js",
      "_ShopLine.9dae93ba.js",
      "_AutoIncre.vue.aa839dd8.js",
      "_scrollbar.338d4a20.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_message-box.1728334f.js",
      "_overlay.a57d50d1.js",
      "_swiper-vue.87e2a882.js",
      "_isEqual.fb3c55d2.js",
      "_flatten.0dbf6d4b.js",
      "_image-viewer.a57f8530.js",
      "_debounce.3beb343f.js",
      "_scroll.93faf99e.js",
      "_nuxt-link.076cd19c.js",
      "_select.db777ad8.js",
      "_popper.51715de2.js",
      "_focus-trap.ef80684b.js",
      "_tag.55f0b9b2.js",
      "_strings.1a075906.js",
      "_index.1e34d4fc.js",
      "_validator.409c16d0.js",
      "_input-number.a0212393.js",
      "_index.37a97259.js",
      "_useFetchUtil.c815d1b7.js",
      "_sku.f9edecf6.js",
      "_index.a21fd3fe.js",
      "_vnode.98844ac6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/shopcart.vue"
  },
  "shopcart.08d01407.css": {
    "file": "shopcart.08d01407.css",
    "resourceType": "style"
  },
  "pages/user/wallet.css": {
    "resourceType": "style",
    "file": "wallet.468a7c3f.css",
    "src": "pages/user/wallet.css"
  },
  "pages/user/wallet.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "wallet.468a7c3f.css",
      "popover.1f4352fc.css"
    ],
    "file": "wallet.c6fbd66c.js",
    "imports": [
      "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/text/index.mjs",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js",
      "_progress.de31a7be.js",
      "_index.7d8b4588.js",
      "_popper.51715de2.js",
      "_bills.834030d1.js",
      "_input-number.a0212393.js",
      "_message-box.1728334f.js",
      "_overlay.a57d50d1.js",
      "_select.db777ad8.js",
      "_tag.55f0b9b2.js",
      "_scrollbar.338d4a20.js",
      "_composables.3b53c41a.js",
      "_localeData.0b229474.js",
      "_divider.d4f2f936.js",
      "_focus-trap.ef80684b.js",
      "_index.37a97259.js",
      "_validator.409c16d0.js",
      "_scroll.93faf99e.js",
      "_vnode.98844ac6.js",
      "_strings.1a075906.js",
      "_isEqual.fb3c55d2.js",
      "_debounce.3beb343f.js",
      "_index.1e34d4fc.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/wallet.vue"
  },
  "wallet.468a7c3f.css": {
    "file": "wallet.468a7c3f.css",
    "resourceType": "style"
  },
  "popover.css": {
    "resourceType": "style",
    "file": "popover.1f4352fc.css",
    "src": "popover.css"
  },
  "popper.css": {
    "resourceType": "style",
    "file": "popper.0d433965.css",
    "src": "popper.css"
  },
  "progress.css": {
    "resourceType": "style",
    "file": "progress.1f193c71.css",
    "src": "progress.css"
  },
  "radio-group.css": {
    "resourceType": "style",
    "file": "radio-group.3b9ac3ad.css",
    "src": "radio-group.css"
  },
  "radio.css": {
    "resourceType": "style",
    "file": "radio.2efacd0a.css",
    "src": "radio.css"
  },
  "rate.css": {
    "resourceType": "style",
    "file": "rate.22f46704.css",
    "src": "rate.css"
  },
  "scrollbar.css": {
    "resourceType": "style",
    "file": "scrollbar.77c43fec.css",
    "src": "scrollbar.css"
  },
  "select.css": {
    "resourceType": "style",
    "file": "select.d289ec57.css",
    "src": "select.css"
  },
  "swiper-vue.css": {
    "resourceType": "style",
    "file": "swiper-vue.9c2b2ee8.css",
    "src": "swiper-vue.css"
  },
  "tabs.css": {
    "resourceType": "style",
    "file": "tabs.ddb6c28f.css",
    "src": "tabs.css"
  },
  "tag.css": {
    "resourceType": "style",
    "file": "tag.da83e147.css",
    "src": "tag.css"
  },
  "tooltip.css": {
    "resourceType": "style",
    "file": "tooltip.e3b0c442.css",
    "src": "tooltip.css"
  },
  "upload.css": {
    "resourceType": "style",
    "file": "upload.40d65e69.css",
    "src": "upload.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
