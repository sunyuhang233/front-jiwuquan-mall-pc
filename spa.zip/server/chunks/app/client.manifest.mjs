const client_manifest = {
  "Footer.css": {
    "resourceType": "style",
    "file": "Footer.9b8a113b.css",
    "src": "Footer.css"
  },
  "GoodsList.css": {
    "resourceType": "style",
    "file": "GoodsList.e598b851.css",
    "src": "GoodsList.css"
  },
  "RightButtons.css": {
    "resourceType": "style",
    "file": "RightButtons.add1503b.css",
    "src": "RightButtons.css"
  },
  "ShopLine.css": {
    "resourceType": "style",
    "file": "ShopLine.bde401b7.css",
    "src": "ShopLine.css"
  },
  "Switch.css": {
    "resourceType": "style",
    "file": "Switch.6e8449cf.css",
    "src": "Switch.css"
  },
  "_AutoIncre.vue.6e76b6b5.js": {
    "resourceType": "script",
    "module": true,
    "file": "AutoIncre.vue.6e76b6b5.js",
    "imports": [
      "_index.af0edcd3.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "_DelayTimer.vue.0d42ed26.js": {
    "resourceType": "script",
    "module": true,
    "file": "DelayTimer.vue.0d42ed26.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_Footer.bf5ffdd0.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "kiwi_strong.d8d5a707.svg",
      "logo_txt.5037f97c.png"
    ],
    "css": [
      "Footer.9b8a113b.css",
      "popover.1f4352fc.css"
    ],
    "file": "Footer.bf5ffdd0.js",
    "imports": [
      "_nuxt-link.36cbee57.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js",
      "_RightButtons.7f8b2cd8.js",
      "_Switch.21fd7df6.js",
      "_index.4b571e96.js",
      "_avatar.424fa936.js",
      "_upload.4a1ce826.js",
      "_progress.512faf4a.js",
      "_popper.0f963667.js",
      "_message-box.7331dc3d.js",
      "_overlay.3f60074c.js",
      "_useFetchUtil.21095a3e.js"
    ]
  },
  "Footer.9b8a113b.css": {
    "file": "Footer.9b8a113b.css",
    "resourceType": "style"
  },
  "popover.1f4352fc.css": {
    "file": "popover.1f4352fc.css",
    "resourceType": "style"
  },
  "kiwi_strong.d8d5a707.svg": {
    "file": "kiwi_strong.d8d5a707.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "logo_txt.5037f97c.png": {
    "file": "logo_txt.5037f97c.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "_GoodsList.97e7a5ca.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "GoodsList.e598b851.css"
    ],
    "file": "GoodsList.97e7a5ca.js",
    "imports": [
      "_image-viewer.1b5f3906.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_useFetchUtil.21095a3e.js",
      "_swiper-vue.87e2a882.js",
      "_nuxt-link.36cbee57.js",
      "_AutoIncre.vue.6e76b6b5.js"
    ]
  },
  "GoodsList.e598b851.css": {
    "file": "GoodsList.e598b851.css",
    "resourceType": "style"
  },
  "_RightButtons.7f8b2cd8.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "RightButtons.add1503b.css",
      "popover.1f4352fc.css",
      "checkbox-group.987ef89c.css",
      "tooltip.e3b0c442.css"
    ],
    "file": "RightButtons.7f8b2cd8.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_index.4b571e96.js",
      "_popper.0f963667.js",
      "_swiper-vue.87e2a882.js",
      "_nuxt-link.36cbee57.js",
      "_checkbox.1b4e4bd0.js",
      "_ShopLine.7b9d806b.js",
      "_scrollbar.17e94c66.js",
      "_message-box.7331dc3d.js",
      "_overlay.3f60074c.js",
      "_index.f805e475.js"
    ]
  },
  "RightButtons.add1503b.css": {
    "file": "RightButtons.add1503b.css",
    "resourceType": "style"
  },
  "checkbox-group.987ef89c.css": {
    "file": "checkbox-group.987ef89c.css",
    "resourceType": "style"
  },
  "tooltip.e3b0c442.css": {
    "file": "tooltip.e3b0c442.css",
    "resourceType": "style"
  },
  "_ShopLine.7b9d806b.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "ShopLine.bde401b7.css"
    ],
    "file": "ShopLine.7b9d806b.js",
    "imports": [
      "_image-viewer.1b5f3906.js",
      "_nuxt-link.36cbee57.js",
      "_select.7a9191d2.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_input-number.b873307a.js",
      "_tag.84276827.js",
      "_scrollbar.17e94c66.js",
      "_popper.0f963667.js",
      "_message-box.7331dc3d.js",
      "_overlay.3f60074c.js",
      "_useFetchUtil.21095a3e.js",
      "_sku.c469120f.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "ShopLine.bde401b7.css": {
    "file": "ShopLine.bde401b7.css",
    "resourceType": "style"
  },
  "_Switch.21fd7df6.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "sun.bc0856fb.svg",
      "moon.768cb03d.svg"
    ],
    "css": [
      "Switch.6e8449cf.css"
    ],
    "file": "Switch.21fd7df6.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_composables.c6d397b7.js",
      "_index.af0edcd3.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "Switch.6e8449cf.css": {
    "file": "Switch.6e8449cf.css",
    "resourceType": "style"
  },
  "sun.bc0856fb.svg": {
    "file": "sun.bc0856fb.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "moon.768cb03d.svg": {
    "file": "moon.768cb03d.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "_arrays.e667dc24.js": {
    "resourceType": "script",
    "module": true,
    "file": "arrays.e667dc24.js"
  },
  "_avatar.424fa936.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "avatar.71943dab.css"
    ],
    "file": "avatar.424fa936.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "avatar.71943dab.css": {
    "file": "avatar.71943dab.css",
    "resourceType": "style"
  },
  "_bills.9e062609.js": {
    "resourceType": "script",
    "module": true,
    "file": "bills.9e062609.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_category.af8595fb.js": {
    "resourceType": "script",
    "module": true,
    "file": "category.af8595fb.js",
    "imports": [
      "_nuxt-link.36cbee57.js",
      "_useFetchUtil.21095a3e.js"
    ]
  },
  "_checkbox.1b4e4bd0.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "checkbox.3d04fbdb.css"
    ],
    "file": "checkbox.1b4e4bd0.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_isEqual.4757671b.js",
      "_flatten.e7f84d99.js"
    ]
  },
  "checkbox.3d04fbdb.css": {
    "file": "checkbox.3d04fbdb.css",
    "resourceType": "style"
  },
  "_cloneDeep.34b86fbb.js": {
    "resourceType": "script",
    "module": true,
    "file": "cloneDeep.34b86fbb.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_collect.b4306b54.js": {
    "resourceType": "script",
    "module": true,
    "file": "collect.b4306b54.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_composables.c6d397b7.js": {
    "resourceType": "script",
    "module": true,
    "file": "composables.c6d397b7.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_debounce.87d738e8.js": {
    "resourceType": "script",
    "module": true,
    "file": "debounce.87d738e8.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_divider.c3b952e6.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "divider.07810808.css"
    ],
    "file": "divider.c3b952e6.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "divider.07810808.css": {
    "file": "divider.07810808.css",
    "resourceType": "style"
  },
  "_flatten.e7f84d99.js": {
    "resourceType": "script",
    "module": true,
    "file": "flatten.e7f84d99.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_focus-trap.1f18f3f6.js": {
    "resourceType": "script",
    "module": true,
    "file": "focus-trap.1f18f3f6.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_image-viewer.1b5f3906.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "image-viewer.bcc58336.css"
    ],
    "file": "image-viewer.1b5f3906.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js",
      "_debounce.87d738e8.js",
      "_scroll.62343251.js"
    ]
  },
  "image-viewer.bcc58336.css": {
    "file": "image-viewer.bcc58336.css",
    "resourceType": "style"
  },
  "_index.1af78815.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.1af78815.js",
    "imports": [
      "_vnode.98844ac6.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "_index.37a97259.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.37a97259.js",
    "imports": [
      "_swiper-vue.87e2a882.js"
    ]
  },
  "_index.4b571e96.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.4b571e96.js",
    "imports": [
      "_popper.0f963667.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "_index.62c91f75.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.62c91f75.js",
    "imports": [
      "_nuxt-link.36cbee57.js",
      "_useFetchUtil.21095a3e.js"
    ]
  },
  "_index.9c5191e7.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.9c5191e7.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.af0edcd3.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.af0edcd3.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "_index.c7bd2e8b.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.c7bd2e8b.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.f4aea1f7.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.f4aea1f7.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "_index.f805e475.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.f805e475.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "_image-viewer.1b5f3906.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_scroll.62343251.js"
    ]
  },
  "_input-number.b873307a.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "input-number.706384ee.css"
    ],
    "file": "input-number.b873307a.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_index.37a97259.js"
    ]
  },
  "input-number.706384ee.css": {
    "file": "input-number.706384ee.css",
    "resourceType": "style"
  },
  "_isEqual.4757671b.js": {
    "resourceType": "script",
    "module": true,
    "file": "isEqual.4757671b.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_localeData.fe6ea330.js": {
    "resourceType": "script",
    "module": true,
    "file": "localeData.fe6ea330.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "_menu.09b8453d.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "menu.d3c11cc9.css"
    ],
    "file": "menu.09b8453d.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_message-box.7331dc3d.js",
      "_swiper-vue.87e2a882.js",
      "_index.9c5191e7.js",
      "_popper.0f963667.js",
      "_vnode.98844ac6.js"
    ]
  },
  "menu.d3c11cc9.css": {
    "file": "menu.d3c11cc9.css",
    "resourceType": "style"
  },
  "_message-box.7331dc3d.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "message-box.7f332db5.css"
    ],
    "file": "message-box.7331dc3d.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_overlay.3f60074c.js",
      "_focus-trap.1f18f3f6.js",
      "_validator.31f08995.js"
    ]
  },
  "message-box.7f332db5.css": {
    "file": "message-box.7f332db5.css",
    "resourceType": "style"
  },
  "_notification.9ed03ff1.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "notification.af5dcd65.css"
    ],
    "file": "notification.9ed03ff1.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "notification.af5dcd65.css": {
    "file": "notification.af5dcd65.css",
    "resourceType": "style"
  },
  "_nuxt-link.36cbee57.js": {
    "resourceType": "script",
    "module": true,
    "file": "nuxt-link.36cbee57.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "_overlay.3f60074c.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "overlay.6e0625dd.css"
    ],
    "file": "overlay.3f60074c.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js",
      "_scroll.62343251.js",
      "_vnode.98844ac6.js"
    ]
  },
  "overlay.6e0625dd.css": {
    "file": "overlay.6e0625dd.css",
    "resourceType": "style"
  },
  "_popper.0f963667.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "popper.0d433965.css"
    ],
    "file": "popper.0f963667.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js",
      "_focus-trap.1f18f3f6.js"
    ]
  },
  "popper.0d433965.css": {
    "file": "popper.0d433965.css",
    "resourceType": "style"
  },
  "_progress.512faf4a.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "progress.1f193c71.css"
    ],
    "file": "progress.512faf4a.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "progress.1f193c71.css": {
    "file": "progress.1f193c71.css",
    "resourceType": "style"
  },
  "_radio.147cff43.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "radio.2efacd0a.css"
    ],
    "file": "radio.147cff43.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "radio.2efacd0a.css": {
    "file": "radio.2efacd0a.css",
    "resourceType": "style"
  },
  "_rand.14326ce1.js": {
    "resourceType": "script",
    "module": true,
    "file": "rand.14326ce1.js"
  },
  "_rate.7211bbec.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "rate.22f46704.css"
    ],
    "file": "rate.7211bbec.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "rate.22f46704.css": {
    "file": "rate.22f46704.css",
    "resourceType": "style"
  },
  "_scroll.62343251.js": {
    "resourceType": "script",
    "module": true,
    "file": "scroll.62343251.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_scrollbar.17e94c66.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "scrollbar.77c43fec.css"
    ],
    "file": "scrollbar.17e94c66.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ]
  },
  "scrollbar.77c43fec.css": {
    "file": "scrollbar.77c43fec.css",
    "resourceType": "style"
  },
  "_select.7a9191d2.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "select.d289ec57.css"
    ],
    "file": "select.7a9191d2.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_popper.0f963667.js",
      "_scrollbar.17e94c66.js",
      "_tag.84276827.js",
      "_strings.1a075906.js",
      "_scroll.62343251.js",
      "_isEqual.4757671b.js",
      "_debounce.87d738e8.js",
      "_index.c7bd2e8b.js",
      "_validator.31f08995.js"
    ]
  },
  "select.d289ec57.css": {
    "file": "select.d289ec57.css",
    "resourceType": "style"
  },
  "_sku.c469120f.js": {
    "resourceType": "script",
    "module": true,
    "file": "sku.c469120f.js",
    "imports": [
      "_nuxt-link.36cbee57.js",
      "_useFetchUtil.21095a3e.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_strings.1a075906.js": {
    "resourceType": "script",
    "module": true,
    "file": "strings.1a075906.js",
    "imports": [
      "_swiper-vue.87e2a882.js"
    ]
  },
  "_swiper-vue.87e2a882.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "swiper-vue.9c2b2ee8.css"
    ],
    "file": "swiper-vue.87e2a882.js"
  },
  "swiper-vue.9c2b2ee8.css": {
    "file": "swiper-vue.9c2b2ee8.css",
    "resourceType": "style"
  },
  "_tabs.d7ee0cd7.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "tabs.ddb6c28f.css"
    ],
    "file": "tabs.d7ee0cd7.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_strings.1a075906.js",
      "_swiper-vue.87e2a882.js",
      "_index.1af78815.js"
    ]
  },
  "tabs.ddb6c28f.css": {
    "file": "tabs.ddb6c28f.css",
    "resourceType": "style"
  },
  "_tag.84276827.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "tag.da83e147.css"
    ],
    "file": "tag.84276827.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "tag.da83e147.css": {
    "file": "tag.da83e147.css",
    "resourceType": "style"
  },
  "_upload.4a1ce826.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "upload.40d65e69.css"
    ],
    "file": "upload.4a1ce826.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_progress.512faf4a.js",
      "_cloneDeep.34b86fbb.js",
      "_isEqual.4757671b.js"
    ]
  },
  "upload.40d65e69.css": {
    "file": "upload.40d65e69.css",
    "resourceType": "style"
  },
  "_useFetchUtil.21095a3e.js": {
    "resourceType": "script",
    "module": true,
    "file": "useFetchUtil.21095a3e.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_validator.31f08995.js": {
    "resourceType": "script",
    "module": true,
    "file": "validator.31f08995.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_vnode.98844ac6.js": {
    "resourceType": "script",
    "module": true,
    "file": "vnode.98844ac6.js",
    "imports": [
      "_swiper-vue.87e2a882.js"
    ]
  },
  "assets/images/icon/moon.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "moon.768cb03d.svg",
    "src": "assets/images/icon/moon.svg"
  },
  "assets/images/icon/success_cone.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "success_cone.ed630b5a.svg",
    "src": "assets/images/icon/success_cone.svg"
  },
  "assets/images/icon/sun.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "sun.bc0856fb.svg",
    "src": "assets/images/icon/sun.svg"
  },
  "assets/images/logo/kiwi_strong.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "kiwi_strong.d8d5a707.svg",
    "src": "assets/images/logo/kiwi_strong.svg"
  },
  "assets/images/logo/logo.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "logo.1479848c.png",
    "src": "assets/images/logo/logo.png"
  },
  "assets/images/logo/logo_txt.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "logo_txt.5037f97c.png",
    "src": "assets/images/logo/logo_txt.png"
  },
  "assets/images/other/index_bg.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "index_bg.496ee798.png",
    "src": "assets/images/other/index_bg.png"
  },
  "avatar.css": {
    "resourceType": "style",
    "file": "avatar.71943dab.css",
    "src": "avatar.css"
  },
  "checkbox-group.css": {
    "resourceType": "style",
    "file": "checkbox-group.987ef89c.css",
    "src": "checkbox-group.css"
  },
  "checkbox.css": {
    "resourceType": "style",
    "file": "checkbox.3d04fbdb.css",
    "src": "checkbox.css"
  },
  "dialog.css": {
    "resourceType": "style",
    "file": "dialog.c614b8ee.css",
    "src": "dialog.css"
  },
  "divider.css": {
    "resourceType": "style",
    "file": "divider.07810808.css",
    "src": "divider.css"
  },
  "image-viewer.css": {
    "resourceType": "style",
    "file": "image-viewer.bcc58336.css",
    "src": "image-viewer.css"
  },
  "input-number.css": {
    "resourceType": "style",
    "file": "input-number.706384ee.css",
    "src": "input-number.css"
  },
  "layouts/error.vue": {
    "resourceType": "script",
    "module": true,
    "file": "error.3984d339.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/error.vue"
  },
  "layouts/main.css": {
    "resourceType": "style",
    "file": "main.113e17a3.css",
    "src": "layouts/main.css"
  },
  "layouts/main.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "main.113e17a3.css",
      "tooltip.e3b0c442.css",
      "popover.1f4352fc.css",
      "checkbox-group.987ef89c.css"
    ],
    "file": "main.0353e876.js",
    "imports": [
      "_Footer.bf5ffdd0.js",
      "_image-viewer.1b5f3906.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_useFetchUtil.21095a3e.js",
      "_menu.09b8453d.js",
      "_swiper-vue.87e2a882.js",
      "_scrollbar.17e94c66.js",
      "_popper.0f963667.js",
      "_nuxt-link.36cbee57.js",
      "_RightButtons.7f8b2cd8.js",
      "_index.af0edcd3.js",
      "_Switch.21fd7df6.js",
      "_composables.c6d397b7.js",
      "_index.4b571e96.js",
      "_avatar.424fa936.js",
      "_upload.4a1ce826.js",
      "_progress.512faf4a.js",
      "_cloneDeep.34b86fbb.js",
      "_isEqual.4757671b.js",
      "_message-box.7331dc3d.js",
      "_overlay.3f60074c.js",
      "_scroll.62343251.js",
      "_vnode.98844ac6.js",
      "_focus-trap.1f18f3f6.js",
      "_validator.31f08995.js",
      "_debounce.87d738e8.js",
      "_index.9c5191e7.js",
      "_checkbox.1b4e4bd0.js",
      "_flatten.e7f84d99.js",
      "_ShopLine.7b9d806b.js",
      "_select.7a9191d2.js",
      "_tag.84276827.js",
      "_strings.1a075906.js",
      "_index.c7bd2e8b.js",
      "_input-number.b873307a.js",
      "_index.37a97259.js",
      "_sku.c469120f.js",
      "_index.f805e475.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/main.vue"
  },
  "main.113e17a3.css": {
    "file": "main.113e17a3.css",
    "resourceType": "style"
  },
  "layouts/second.css": {
    "resourceType": "style",
    "file": "second.c4a23853.css",
    "src": "layouts/second.css"
  },
  "layouts/second.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "second.c4a23853.css",
      "popover.1f4352fc.css",
      "checkbox-group.987ef89c.css",
      "tooltip.e3b0c442.css"
    ],
    "file": "second.72e39d2c.js",
    "imports": [
      "_Footer.bf5ffdd0.js",
      "_RightButtons.7f8b2cd8.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js",
      "_nuxt-link.36cbee57.js",
      "_Switch.21fd7df6.js",
      "_composables.c6d397b7.js",
      "_index.af0edcd3.js",
      "_index.4b571e96.js",
      "_popper.0f963667.js",
      "_focus-trap.1f18f3f6.js",
      "_avatar.424fa936.js",
      "_upload.4a1ce826.js",
      "_progress.512faf4a.js",
      "_cloneDeep.34b86fbb.js",
      "_isEqual.4757671b.js",
      "_message-box.7331dc3d.js",
      "_overlay.3f60074c.js",
      "_scroll.62343251.js",
      "_vnode.98844ac6.js",
      "_validator.31f08995.js",
      "_useFetchUtil.21095a3e.js",
      "_checkbox.1b4e4bd0.js",
      "_flatten.e7f84d99.js",
      "_ShopLine.7b9d806b.js",
      "_image-viewer.1b5f3906.js",
      "_debounce.87d738e8.js",
      "_select.7a9191d2.js",
      "_scrollbar.17e94c66.js",
      "_tag.84276827.js",
      "_strings.1a075906.js",
      "_index.c7bd2e8b.js",
      "_input-number.b873307a.js",
      "_index.37a97259.js",
      "_sku.c469120f.js",
      "_index.f805e475.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/second.vue"
  },
  "second.c4a23853.css": {
    "file": "second.c4a23853.css",
    "resourceType": "style"
  },
  "layouts/user.css": {
    "resourceType": "style",
    "file": "user.2f9261e3.css",
    "src": "layouts/user.css"
  },
  "layouts/user.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "user.2f9261e3.css",
      "popover.1f4352fc.css",
      "tooltip.e3b0c442.css",
      "checkbox-group.987ef89c.css"
    ],
    "file": "user.6d5a75e5.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.36cbee57.js",
      "_Switch.21fd7df6.js",
      "_index.4b571e96.js",
      "_popper.0f963667.js",
      "_message-box.7331dc3d.js",
      "_overlay.3f60074c.js",
      "_useFetchUtil.21095a3e.js",
      "_swiper-vue.87e2a882.js",
      "_RightButtons.7f8b2cd8.js",
      "_menu.09b8453d.js",
      "_index.af0edcd3.js",
      "_composables.c6d397b7.js",
      "_focus-trap.1f18f3f6.js",
      "_validator.31f08995.js",
      "_scroll.62343251.js",
      "_vnode.98844ac6.js",
      "_checkbox.1b4e4bd0.js",
      "_isEqual.4757671b.js",
      "_flatten.e7f84d99.js",
      "_ShopLine.7b9d806b.js",
      "_image-viewer.1b5f3906.js",
      "_debounce.87d738e8.js",
      "_select.7a9191d2.js",
      "_scrollbar.17e94c66.js",
      "_tag.84276827.js",
      "_strings.1a075906.js",
      "_index.c7bd2e8b.js",
      "_input-number.b873307a.js",
      "_index.37a97259.js",
      "_sku.c469120f.js",
      "_index.f805e475.js",
      "_index.9c5191e7.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/user.vue"
  },
  "user.2f9261e3.css": {
    "file": "user.2f9261e3.css",
    "resourceType": "style"
  },
  "menu.css": {
    "resourceType": "style",
    "file": "menu.d3c11cc9.css",
    "src": "menu.css"
  },
  "message-box.css": {
    "resourceType": "style",
    "file": "message-box.7f332db5.css",
    "src": "message-box.css"
  },
  "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/dialog/index.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "index.336bcfb7.js",
    "imports": [
      "_swiper-vue.87e2a882.js",
      "_overlay.3f60074c.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_focus-trap.1f18f3f6.js",
      "_scroll.62343251.js",
      "_vnode.98844ac6.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/dialog/index.mjs"
  },
  "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/text/index.css": {
    "resourceType": "style",
    "file": "index.779bf283.css",
    "src": "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/text/index.css"
  },
  "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/text/index.mjs": {
    "resourceType": "script",
    "module": true,
    "css": [
      "index.779bf283.css"
    ],
    "file": "index.6a1a4c57.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/text/index.mjs"
  },
  "index.779bf283.css": {
    "file": "index.779bf283.css",
    "resourceType": "style"
  },
  "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.b6cfc8bb.css",
    "src": "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "logo.1479848c.png"
    ],
    "css": [
      "entry.b6cfc8bb.css"
    ],
    "dynamicImports": [
      "layouts/error.vue",
      "layouts/main.vue",
      "layouts/second.vue",
      "layouts/user.vue",
      "node_modules/.pnpm/workbox-window@7.0.0/node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
    ],
    "file": "entry.7401566a.js",
    "imports": [
      "_swiper-vue.87e2a882.js"
    ],
    "isEntry": true,
    "src": "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js"
  },
  "entry.b6cfc8bb.css": {
    "file": "entry.b6cfc8bb.css",
    "resourceType": "style"
  },
  "logo.1479848c.png": {
    "file": "logo.1479848c.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "node_modules/.pnpm/workbox-window@7.0.0/node_modules/workbox-window/build/workbox-window.prod.es5.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "workbox-window.prod.es5.a7b12eab.js",
    "isDynamicEntry": true,
    "src": "node_modules/.pnpm/workbox-window@7.0.0/node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
  },
  "notification.css": {
    "resourceType": "style",
    "file": "notification.af5dcd65.css",
    "src": "notification.css"
  },
  "overlay.css": {
    "resourceType": "style",
    "file": "overlay.6e0625dd.css",
    "src": "overlay.css"
  },
  "pages/[...all].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_...all_.35581b85.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/[...all].vue"
  },
  "pages/category/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.f8dbeb47.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/category/index.vue"
  },
  "pages/community/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.faafd14c.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/index.vue"
  },
  "pages/event/detail.css": {
    "resourceType": "style",
    "file": "detail.9ceddf54.css",
    "src": "pages/event/detail.css"
  },
  "pages/event/detail.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "detail.9ceddf54.css"
    ],
    "file": "detail.42c2ac91.js",
    "imports": [
      "_image-viewer.1b5f3906.js",
      "_tag.84276827.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_useFetchUtil.21095a3e.js",
      "_swiper-vue.87e2a882.js",
      "_nuxt-link.36cbee57.js",
      "_index.f4aea1f7.js",
      "_index.62c91f75.js",
      "_debounce.87d738e8.js",
      "_scroll.62343251.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/event/detail.vue"
  },
  "detail.9ceddf54.css": {
    "file": "detail.9ceddf54.css",
    "resourceType": "style"
  },
  "pages/goods/comments/[id].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_id_.49577851.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/comments/[id].vue"
  },
  "pages/goods/detail/[id].css": {
    "resourceType": "style",
    "file": "_id_.04cbda88.css",
    "src": "pages/goods/detail/[id].css"
  },
  "pages/goods/detail/[id].vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "_id_.04cbda88.css",
      "popover.1f4352fc.css",
      "radio-group.3b9ac3ad.css",
      "dialog.c614b8ee.css"
    ],
    "file": "_id_.ecf7b5cf.js",
    "imports": [
      "_nuxt-link.36cbee57.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js",
      "_category.af8595fb.js",
      "_image-viewer.1b5f3906.js",
      "_index.1af78815.js",
      "_useFetchUtil.21095a3e.js",
      "_tag.84276827.js",
      "_popper.0f963667.js",
      "_collect.b4306b54.js",
      "_radio.147cff43.js",
      "_input-number.b873307a.js",
      "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/text/index.mjs",
      "_tabs.d7ee0cd7.js",
      "_rate.7211bbec.js",
      "_scrollbar.17e94c66.js",
      "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/dialog/index.mjs",
      "_overlay.3f60074c.js",
      "_index.f805e475.js",
      "_index.9c5191e7.js",
      "_rand.14326ce1.js",
      "_GoodsList.97e7a5ca.js",
      "_index.f4aea1f7.js",
      "_sku.c469120f.js",
      "_debounce.87d738e8.js",
      "_scroll.62343251.js",
      "_vnode.98844ac6.js",
      "_focus-trap.1f18f3f6.js",
      "_index.37a97259.js",
      "_strings.1a075906.js",
      "_AutoIncre.vue.6e76b6b5.js",
      "_index.af0edcd3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/detail/[id].vue"
  },
  "_id_.04cbda88.css": {
    "file": "_id_.04cbda88.css",
    "resourceType": "style"
  },
  "radio-group.3b9ac3ad.css": {
    "file": "radio-group.3b9ac3ad.css",
    "resourceType": "style"
  },
  "dialog.c614b8ee.css": {
    "file": "dialog.c614b8ee.css",
    "resourceType": "style"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.bcd2f6b6.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "index_bg.496ee798.png"
    ],
    "css": [
      "index.bcd2f6b6.css",
      "popover.1f4352fc.css"
    ],
    "file": "index.5e47d7e8.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_tag.84276827.js",
      "_image-viewer.1b5f3906.js",
      "_useFetchUtil.21095a3e.js",
      "_swiper-vue.87e2a882.js",
      "_divider.c3b952e6.js",
      "_nuxt-link.36cbee57.js",
      "_scrollbar.17e94c66.js",
      "_index.4b571e96.js",
      "_popper.0f963667.js",
      "_index.af0edcd3.js",
      "_GoodsList.97e7a5ca.js",
      "_index.62c91f75.js",
      "_AutoIncre.vue.6e76b6b5.js",
      "_category.af8595fb.js",
      "_tabs.d7ee0cd7.js",
      "_debounce.87d738e8.js",
      "_scroll.62343251.js",
      "_focus-trap.1f18f3f6.js",
      "_strings.1a075906.js",
      "_index.1af78815.js",
      "_vnode.98844ac6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.bcd2f6b6.css": {
    "file": "index.bcd2f6b6.css",
    "resourceType": "style"
  },
  "index_bg.496ee798.png": {
    "file": "index_bg.496ee798.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "pages/order/comment/[id].css": {
    "resourceType": "style",
    "file": "_id_.4730009e.css",
    "src": "pages/order/comment/[id].css"
  },
  "pages/order/comment/[id].vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "success_cone.ed630b5a.svg"
    ],
    "css": [
      "_id_.4730009e.css",
      "dialog.c614b8ee.css"
    ],
    "file": "_id_.a327ca38.js",
    "imports": [
      "_Switch.21fd7df6.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_progress.512faf4a.js",
      "_upload.4a1ce826.js",
      "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/dialog/index.mjs",
      "_overlay.3f60074c.js",
      "_message-box.7331dc3d.js",
      "_swiper-vue.87e2a882.js",
      "_image-viewer.1b5f3906.js",
      "_useFetchUtil.21095a3e.js",
      "_rate.7211bbec.js",
      "_checkbox.1b4e4bd0.js",
      "_index.af0edcd3.js",
      "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/text/index.mjs",
      "_notification.9ed03ff1.js",
      "_composables.c6d397b7.js",
      "_cloneDeep.34b86fbb.js",
      "_isEqual.4757671b.js",
      "_focus-trap.1f18f3f6.js",
      "_scroll.62343251.js",
      "_vnode.98844ac6.js",
      "_validator.31f08995.js",
      "_debounce.87d738e8.js",
      "_flatten.e7f84d99.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/comment/[id].vue"
  },
  "_id_.4730009e.css": {
    "file": "_id_.4730009e.css",
    "resourceType": "style"
  },
  "success_cone.ed630b5a.svg": {
    "file": "success_cone.ed630b5a.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "pages/order/detail.css": {
    "resourceType": "style",
    "file": "detail.69c9e824.css",
    "src": "pages/order/detail.css"
  },
  "pages/order/detail.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "detail.69c9e824.css",
      "radio-group.3b9ac3ad.css"
    ],
    "dynamicImports": [
      "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/text/index.mjs"
    ],
    "file": "detail.f8947236.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_image-viewer.1b5f3906.js",
      "_nuxt-link.36cbee57.js",
      "_divider.c3b952e6.js",
      "_DelayTimer.vue.0d42ed26.js",
      "_swiper-vue.87e2a882.js",
      "_Switch.21fd7df6.js",
      "_index.1af78815.js",
      "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/text/index.mjs",
      "_bills.9e062609.js",
      "_radio.147cff43.js",
      "_tag.84276827.js",
      "_scrollbar.17e94c66.js",
      "_select.7a9191d2.js",
      "_input-number.b873307a.js",
      "_popper.0f963667.js",
      "_useFetchUtil.21095a3e.js",
      "_sku.c469120f.js",
      "_notification.9ed03ff1.js",
      "_message-box.7331dc3d.js",
      "_overlay.3f60074c.js",
      "_debounce.87d738e8.js",
      "_scroll.62343251.js",
      "_composables.c6d397b7.js",
      "_index.af0edcd3.js",
      "_vnode.98844ac6.js",
      "_strings.1a075906.js",
      "_isEqual.4757671b.js",
      "_index.c7bd2e8b.js",
      "_validator.31f08995.js",
      "_index.37a97259.js",
      "_focus-trap.1f18f3f6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/detail.vue"
  },
  "detail.69c9e824.css": {
    "file": "detail.69c9e824.css",
    "resourceType": "style"
  },
  "pages/order/list.css": {
    "resourceType": "style",
    "file": "list.d32d3c8e.css",
    "src": "pages/order/list.css"
  },
  "pages/order/list.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "list.d32d3c8e.css"
    ],
    "file": "list.723a2175.js",
    "imports": [
      "_divider.c3b952e6.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_localeData.fe6ea330.js",
      "_swiper-vue.87e2a882.js",
      "_arrays.e667dc24.js",
      "_flatten.e7f84d99.js",
      "_popper.0f963667.js",
      "_scrollbar.17e94c66.js",
      "_index.37a97259.js",
      "_debounce.87d738e8.js",
      "_index.c7bd2e8b.js",
      "_isEqual.4757671b.js",
      "_DelayTimer.vue.0d42ed26.js",
      "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/text/index.mjs",
      "_image-viewer.1b5f3906.js",
      "_tag.84276827.js",
      "_useFetchUtil.21095a3e.js",
      "_AutoIncre.vue.6e76b6b5.js",
      "_message-box.7331dc3d.js",
      "_overlay.3f60074c.js",
      "_notification.9ed03ff1.js",
      "_tabs.d7ee0cd7.js",
      "_focus-trap.1f18f3f6.js",
      "_scroll.62343251.js",
      "_index.af0edcd3.js",
      "_validator.31f08995.js",
      "_vnode.98844ac6.js",
      "_strings.1a075906.js",
      "_index.1af78815.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/list.vue"
  },
  "list.d32d3c8e.css": {
    "file": "list.d32d3c8e.css",
    "resourceType": "style"
  },
  "pages/search/index.css": {
    "resourceType": "style",
    "file": "index.7a00cec5.css",
    "src": "pages/search/index.css"
  },
  "pages/search/index.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "index.7a00cec5.css"
    ],
    "file": "index.857eb77f.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_checkbox.1b4e4bd0.js",
      "_select.7a9191d2.js",
      "_tag.84276827.js",
      "_GoodsList.97e7a5ca.js",
      "_scrollbar.17e94c66.js",
      "_popper.0f963667.js",
      "_swiper-vue.87e2a882.js",
      "_index.af0edcd3.js",
      "_isEqual.4757671b.js",
      "_flatten.e7f84d99.js",
      "_strings.1a075906.js",
      "_scroll.62343251.js",
      "_debounce.87d738e8.js",
      "_index.c7bd2e8b.js",
      "_validator.31f08995.js",
      "_image-viewer.1b5f3906.js",
      "_useFetchUtil.21095a3e.js",
      "_nuxt-link.36cbee57.js",
      "_AutoIncre.vue.6e76b6b5.js",
      "_focus-trap.1f18f3f6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/search/index.vue"
  },
  "index.7a00cec5.css": {
    "file": "index.7a00cec5.css",
    "resourceType": "style"
  },
  "pages/user/address.css": {
    "resourceType": "style",
    "file": "address.63f003b2.css",
    "src": "pages/user/address.css"
  },
  "pages/user/address.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "address.63f003b2.css",
      "dialog.c614b8ee.css",
      "checkbox-group.987ef89c.css"
    ],
    "dynamicImports": [
      "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/dialog/index.mjs"
    ],
    "file": "address.ea46d4b8.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/text/index.mjs",
      "_swiper-vue.87e2a882.js",
      "_scrollbar.17e94c66.js",
      "_checkbox.1b4e4bd0.js",
      "_radio.147cff43.js",
      "_rand.14326ce1.js",
      "_strings.1a075906.js",
      "_isEqual.4757671b.js",
      "_message-box.7331dc3d.js",
      "_arrays.e667dc24.js",
      "_scroll.62343251.js",
      "_flatten.e7f84d99.js",
      "_cloneDeep.34b86fbb.js",
      "_popper.0f963667.js",
      "_tag.84276827.js",
      "_index.c7bd2e8b.js",
      "_debounce.87d738e8.js",
      "_divider.c3b952e6.js",
      "_overlay.3f60074c.js",
      "_focus-trap.1f18f3f6.js",
      "_validator.31f08995.js",
      "_vnode.98844ac6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/address.vue"
  },
  "address.63f003b2.css": {
    "file": "address.63f003b2.css",
    "resourceType": "style"
  },
  "pages/user/collect.css": {
    "resourceType": "style",
    "file": "collect.5310cb39.css",
    "src": "pages/user/collect.css"
  },
  "pages/user/collect.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "collect.5310cb39.css",
      "checkbox-group.987ef89c.css"
    ],
    "file": "collect.68a4b9d4.js",
    "imports": [
      "_divider.c3b952e6.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_checkbox.1b4e4bd0.js",
      "_image-viewer.1b5f3906.js",
      "_useFetchUtil.21095a3e.js",
      "_swiper-vue.87e2a882.js",
      "_scrollbar.17e94c66.js",
      "_message-box.7331dc3d.js",
      "_overlay.3f60074c.js",
      "_collect.b4306b54.js",
      "_tabs.d7ee0cd7.js",
      "_isEqual.4757671b.js",
      "_flatten.e7f84d99.js",
      "_debounce.87d738e8.js",
      "_scroll.62343251.js",
      "_focus-trap.1f18f3f6.js",
      "_validator.31f08995.js",
      "_vnode.98844ac6.js",
      "_strings.1a075906.js",
      "_index.1af78815.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/collect.vue"
  },
  "collect.5310cb39.css": {
    "file": "collect.5310cb39.css",
    "resourceType": "style"
  },
  "pages/user/info.css": {
    "resourceType": "style",
    "file": "info.e0008b9e.css",
    "src": "pages/user/info.css"
  },
  "pages/user/info.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "info.e0008b9e.css",
      "popover.1f4352fc.css",
      "tooltip.e3b0c442.css"
    ],
    "file": "info.1c201831.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_image-viewer.1b5f3906.js",
      "_index.4b571e96.js",
      "_popper.0f963667.js",
      "_useFetchUtil.21095a3e.js",
      "_index.af0edcd3.js",
      "_swiper-vue.87e2a882.js",
      "_upload.4a1ce826.js",
      "_select.7a9191d2.js",
      "_progress.512faf4a.js",
      "_tag.84276827.js",
      "_scrollbar.17e94c66.js",
      "_tabs.d7ee0cd7.js",
      "_debounce.87d738e8.js",
      "_scroll.62343251.js",
      "_focus-trap.1f18f3f6.js",
      "_cloneDeep.34b86fbb.js",
      "_isEqual.4757671b.js",
      "_strings.1a075906.js",
      "_index.c7bd2e8b.js",
      "_validator.31f08995.js",
      "_index.1af78815.js",
      "_vnode.98844ac6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/info.vue"
  },
  "info.e0008b9e.css": {
    "file": "info.e0008b9e.css",
    "resourceType": "style"
  },
  "pages/user/safe.css": {
    "resourceType": "style",
    "file": "safe.71c0a412.css",
    "src": "pages/user/safe.css"
  },
  "pages/user/safe.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "safe.71c0a412.css"
    ],
    "file": "safe.9a8ea5c3.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_tag.84276827.js",
      "_swiper-vue.87e2a882.js",
      "_scrollbar.17e94c66.js",
      "_message-box.7331dc3d.js",
      "_overlay.3f60074c.js",
      "_avatar.424fa936.js",
      "_divider.c3b952e6.js",
      "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/text/index.mjs",
      "_useFetchUtil.21095a3e.js",
      "_focus-trap.1f18f3f6.js",
      "_validator.31f08995.js",
      "_scroll.62343251.js",
      "_vnode.98844ac6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/safe.vue"
  },
  "safe.71c0a412.css": {
    "file": "safe.71c0a412.css",
    "resourceType": "style"
  },
  "pages/user/shopcart.css": {
    "resourceType": "style",
    "file": "shopcart.218c6743.css",
    "src": "pages/user/shopcart.css"
  },
  "pages/user/shopcart.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "shopcart.218c6743.css",
      "checkbox-group.987ef89c.css"
    ],
    "file": "shopcart.cded363a.js",
    "imports": [
      "_checkbox.1b4e4bd0.js",
      "_ShopLine.7b9d806b.js",
      "_AutoIncre.vue.6e76b6b5.js",
      "_scrollbar.17e94c66.js",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_message-box.7331dc3d.js",
      "_overlay.3f60074c.js",
      "_swiper-vue.87e2a882.js",
      "_isEqual.4757671b.js",
      "_flatten.e7f84d99.js",
      "_image-viewer.1b5f3906.js",
      "_debounce.87d738e8.js",
      "_scroll.62343251.js",
      "_nuxt-link.36cbee57.js",
      "_select.7a9191d2.js",
      "_popper.0f963667.js",
      "_focus-trap.1f18f3f6.js",
      "_tag.84276827.js",
      "_strings.1a075906.js",
      "_index.c7bd2e8b.js",
      "_validator.31f08995.js",
      "_input-number.b873307a.js",
      "_index.37a97259.js",
      "_useFetchUtil.21095a3e.js",
      "_sku.c469120f.js",
      "_index.af0edcd3.js",
      "_vnode.98844ac6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/shopcart.vue"
  },
  "shopcart.218c6743.css": {
    "file": "shopcart.218c6743.css",
    "resourceType": "style"
  },
  "pages/user/wallet.css": {
    "resourceType": "style",
    "file": "wallet.d34f34db.css",
    "src": "pages/user/wallet.css"
  },
  "pages/user/wallet.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "wallet.d34f34db.css",
      "popover.1f4352fc.css"
    ],
    "file": "wallet.2feb6eb2.js",
    "imports": [
      "node_modules/.pnpm/element-plus@2.3.8_vue@3.3.4/node_modules/element-plus/es/components/text/index.mjs",
      "node_modules/.pnpm/nuxt@3.6.5_@types+node@20.4.4_eslint@8.49.0_rollup@2.79.1_sass@1.64.1_typescript@5.1.6_vue-tsc@1.8.6/node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.87e2a882.js",
      "_progress.512faf4a.js",
      "_index.4b571e96.js",
      "_popper.0f963667.js",
      "_bills.9e062609.js",
      "_input-number.b873307a.js",
      "_message-box.7331dc3d.js",
      "_overlay.3f60074c.js",
      "_select.7a9191d2.js",
      "_tag.84276827.js",
      "_scrollbar.17e94c66.js",
      "_composables.c6d397b7.js",
      "_localeData.fe6ea330.js",
      "_divider.c3b952e6.js",
      "_focus-trap.1f18f3f6.js",
      "_index.37a97259.js",
      "_validator.31f08995.js",
      "_scroll.62343251.js",
      "_vnode.98844ac6.js",
      "_strings.1a075906.js",
      "_isEqual.4757671b.js",
      "_debounce.87d738e8.js",
      "_index.c7bd2e8b.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/wallet.vue"
  },
  "wallet.d34f34db.css": {
    "file": "wallet.d34f34db.css",
    "resourceType": "style"
  },
  "popover.css": {
    "resourceType": "style",
    "file": "popover.1f4352fc.css",
    "src": "popover.css"
  },
  "popper.css": {
    "resourceType": "style",
    "file": "popper.0d433965.css",
    "src": "popper.css"
  },
  "progress.css": {
    "resourceType": "style",
    "file": "progress.1f193c71.css",
    "src": "progress.css"
  },
  "radio-group.css": {
    "resourceType": "style",
    "file": "radio-group.3b9ac3ad.css",
    "src": "radio-group.css"
  },
  "radio.css": {
    "resourceType": "style",
    "file": "radio.2efacd0a.css",
    "src": "radio.css"
  },
  "rate.css": {
    "resourceType": "style",
    "file": "rate.22f46704.css",
    "src": "rate.css"
  },
  "scrollbar.css": {
    "resourceType": "style",
    "file": "scrollbar.77c43fec.css",
    "src": "scrollbar.css"
  },
  "select.css": {
    "resourceType": "style",
    "file": "select.d289ec57.css",
    "src": "select.css"
  },
  "swiper-vue.css": {
    "resourceType": "style",
    "file": "swiper-vue.9c2b2ee8.css",
    "src": "swiper-vue.css"
  },
  "tabs.css": {
    "resourceType": "style",
    "file": "tabs.ddb6c28f.css",
    "src": "tabs.css"
  },
  "tag.css": {
    "resourceType": "style",
    "file": "tag.da83e147.css",
    "src": "tag.css"
  },
  "tooltip.css": {
    "resourceType": "style",
    "file": "tooltip.e3b0c442.css",
    "src": "tooltip.css"
  },
  "upload.css": {
    "resourceType": "style",
    "file": "upload.40d65e69.css",
    "src": "upload.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
