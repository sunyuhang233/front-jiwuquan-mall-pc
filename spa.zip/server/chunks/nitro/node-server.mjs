globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import 'node-fetch-native/polyfill';
import { Server as Server$1 } from 'node:http';
import { Server } from 'node:https';
import destr from 'destr';
import { defineEventHandler, handleCacheHeaders, createEvent, eventHandler, setHeaders, sendRedirect, proxyRequest, getRequestHeader, setResponseStatus, setResponseHeader, getRequestHeaders, createError, createApp, createRouter as createRouter$1, toNodeListener, fetchWithEvent, lazyEventHandler } from 'h3';
import { createFetch as createFetch$1, Headers } from 'ofetch';
import { createCall, createFetch } from 'unenv/runtime/fetch/index';
import { createHooks } from 'hookable';
import { snakeCase } from 'scule';
import { klona } from 'klona';
import defu, { defuFn } from 'defu';
import { hash } from 'ohash';
import { parseURL, withoutBase, joinURL, getQuery, withQuery, withLeadingSlash, withoutTrailingSlash } from 'ufo';
import { createStorage, prefixStorage } from 'unstorage';
import { toRouteMatcher, createRouter } from 'radix3';
import { promises } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'pathe';
import gracefulShutdown from 'http-graceful-shutdown';

const inlineAppConfig = {};



const appConfig = defuFn(inlineAppConfig);

const _inlineRuntimeConfig = {
  "app": {
    "baseURL": "/",
    "buildAssetsDir": "/_nuxt/",
    "cdnURL": ""
  },
  "nitro": {
    "envPrefix": "NUXT_",
    "routeRules": {
      "/__nuxt_error": {
        "cache": false
      },
      "/sw.js": {
        "headers": {
          "Cache-Control": "public, max-age=0, must-revalidate"
        }
      },
      "/manifest.webmanifest": {
        "headers": {
          "Content-Type": "application/manifest+json",
          "Cache-Control": "public, max-age=0, must-revalidate"
        }
      },
      "/_nuxt/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      }
    }
  },
  "public": {
    "persistedState": {
      "storage": "localStorage",
      "debug": false,
      "cookieOptions": {}
    }
  }
};
const ENV_PREFIX = "NITRO_";
const ENV_PREFIX_ALT = _inlineRuntimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_";
const _sharedRuntimeConfig = _deepFreeze(
  _applyEnv(klona(_inlineRuntimeConfig))
);
function useRuntimeConfig(event) {
  if (!event) {
    return _sharedRuntimeConfig;
  }
  if (event.context.nitro.runtimeConfig) {
    return event.context.nitro.runtimeConfig;
  }
  const runtimeConfig = klona(_inlineRuntimeConfig);
  _applyEnv(runtimeConfig);
  event.context.nitro.runtimeConfig = runtimeConfig;
  return runtimeConfig;
}
_deepFreeze(klona(appConfig));
function _getEnv(key) {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process.env[ENV_PREFIX + envKey] ?? process.env[ENV_PREFIX_ALT + envKey]
  );
}
function _isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function _applyEnv(obj, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = _getEnv(subKey);
    if (_isObject(obj[key])) {
      if (_isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
      }
      _applyEnv(obj[key], subKey);
    } else {
      obj[key] = envValue ?? obj[key];
    }
  }
  return obj;
}
function _deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      _deepFreeze(value);
    }
  }
  return Object.freeze(object);
}
new Proxy(/* @__PURE__ */ Object.create(null), {
  get: (_, prop) => {
    console.warn(
      "Please use `useRuntimeConfig()` instead of accessing config directly."
    );
    const runtimeConfig = useRuntimeConfig();
    if (prop in runtimeConfig) {
      return runtimeConfig[prop];
    }
    return void 0;
  }
});

const _assets = {

};

function normalizeKey(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0].replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "");
}

const assets$1 = {
  getKeys() {
    return Promise.resolve(Object.keys(_assets))
  },
  hasItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(id in _assets)
  },
  getItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].import() : null)
  },
  getMeta (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].meta : {})
  }
};

const storage = createStorage({});

storage.mount('/assets', assets$1);

function useStorage(base = "") {
  return base ? prefixStorage(storage, base) : storage;
}

const defaultCacheOptions = {
  name: "_",
  base: "/cache",
  swr: true,
  maxAge: 1
};
function defineCachedFunction(fn, opts = {}) {
  opts = { ...defaultCacheOptions, ...opts };
  const pending = {};
  const group = opts.group || "nitro/functions";
  const name = opts.name || fn.name || "_";
  const integrity = hash([opts.integrity, fn, opts]);
  const validate = opts.validate || (() => true);
  async function get(key, resolver, shouldInvalidateCache) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    const entry = await useStorage().getItem(cacheKey) || {};
    const ttl = (opts.maxAge ?? opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || !validate(entry);
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry.value !== void 0 && (opts.staleMaxAge || 0) >= 0 && opts.swr === false) {
          entry.value = void 0;
          entry.integrity = void 0;
          entry.mtime = void 0;
          entry.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      try {
        entry.value = await pending[key];
      } catch (error) {
        if (!isPending) {
          delete pending[key];
        }
        throw error;
      }
      if (!isPending) {
        entry.mtime = Date.now();
        entry.integrity = integrity;
        delete pending[key];
        if (validate(entry)) {
          useStorage().setItem(cacheKey, entry).catch((error) => console.error("[nitro] [cache]", error));
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (opts.swr && entry.value) {
      _resolvePromise.catch(console.error);
      return entry;
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const shouldBypassCache = opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = opts.shouldInvalidateCache?.(...args);
    const entry = await get(key, () => fn(...args), shouldInvalidateCache);
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
const cachedFunction = defineCachedFunction;
function getKey(...args) {
  return args.length > 0 ? hash(args, {}) : "";
}
function escapeKey(key) {
  return key.replace(/[^\dA-Za-z]/g, "");
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions) {
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const key = await opts.getKey?.(event);
      if (key) {
        return escapeKey(key);
      }
      const url = event.node.req.originalUrl || event.node.req.url;
      const friendlyName = escapeKey(decodeURI(parseURL(url).pathname)).slice(
        0,
        16
      );
      const urlHash = hash(url);
      return `${friendlyName}.${urlHash}`;
    },
    validate: (entry) => {
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: [opts.integrity, handler]
  };
  const _cachedHandler = cachedFunction(
    async (incomingEvent) => {
      const reqProxy = cloneWithProxy(incomingEvent.node.req, { headers: {} });
      const resHeaders = {};
      let _resSendBody;
      const resProxy = cloneWithProxy(incomingEvent.node.res, {
        statusCode: 200,
        writableEnded: false,
        writableFinished: false,
        headersSent: false,
        closed: false,
        getHeader(name) {
          return resHeaders[name];
        },
        setHeader(name, value) {
          resHeaders[name] = value;
          return this;
        },
        getHeaderNames() {
          return Object.keys(resHeaders);
        },
        hasHeader(name) {
          return name in resHeaders;
        },
        removeHeader(name) {
          delete resHeaders[name];
        },
        getHeaders() {
          return resHeaders;
        },
        end(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        write(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        writeHead(statusCode, headers2) {
          this.statusCode = statusCode;
          if (headers2) {
            for (const header in headers2) {
              this.setHeader(header, headers2[header]);
            }
          }
          return this;
        }
      });
      const event = createEvent(reqProxy, resProxy);
      event.context = incomingEvent.context;
      const body = await handler(event) || _resSendBody;
      const headers = event.node.res.getHeaders();
      headers.etag = headers.Etag || headers.etag || `W/"${hash(body)}"`;
      headers["last-modified"] = headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString();
      const cacheControl = [];
      if (opts.swr) {
        if (opts.maxAge) {
          cacheControl.push(`s-maxage=${opts.maxAge}`);
        }
        if (opts.staleMaxAge) {
          cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
        } else {
          cacheControl.push("stale-while-revalidate");
        }
      } else if (opts.maxAge) {
        cacheControl.push(`max-age=${opts.maxAge}`);
      }
      if (cacheControl.length > 0) {
        headers["cache-control"] = cacheControl.join(", ");
      }
      const cacheEntry = {
        code: event.node.res.statusCode,
        headers,
        body
      };
      return cacheEntry;
    },
    _opts
  );
  return defineEventHandler(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    const response = await _cachedHandler(event);
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      event.node.res.setHeader(name, response.headers[name]);
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(
  createRouter({ routes: config.nitro.routeRules })
);
function createRouteRulesHandler() {
  return eventHandler((event) => {
    const routeRules = getRouteRules(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      return sendRedirect(
        event,
        routeRules.redirect.to,
        routeRules.redirect.statusCode
      );
    }
    if (routeRules.proxy) {
      let target = routeRules.proxy.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.proxy._proxyStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery(event.path);
        target = withQuery(target, query);
      }
      return proxyRequest(event, target, {
        fetch: $fetch.raw,
        ...routeRules.proxy
      });
    }
  });
}
function getRouteRules(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    const path = new URL(event.node.req.url, "http://localhost").pathname;
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(path, useRuntimeConfig().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

const script = "\"use strict\";(()=>{const a=window,e=document.documentElement,m=[\"dark\",\"light\"],c=window.localStorage.getItem(\"nuxt-color-mode\")||\"system\";let n=c===\"system\"?f():c;const l=e.getAttribute(\"data-color-mode-forced\");l&&(n=l),i(n),a[\"__NUXT_COLOR_MODE__\"]={preference:c,value:n,getColorScheme:f,addColorScheme:i,removeColorScheme:d};function i(o){const t=\"\"+o+\"\",s=\"\";e.classList?e.classList.add(t):e.className+=\" \"+t,s&&e.setAttribute(\"data-\"+s,o)}function d(o){const t=\"\"+o+\"\",s=\"\";e.classList?e.classList.remove(t):e.className=e.className.replace(new RegExp(t,\"g\"),\"\"),s&&e.removeAttribute(\"data-\"+s)}function r(o){return a.matchMedia(\"(prefers-color-scheme\"+o+\")\")}function f(){if(a.matchMedia&&r(\"\").media!==\"not all\"){for(const o of m)if(r(\":\"+o).matches)return o}return\"light\"}})();\n";

const _I1yZJKqTBB = (function(nitro) {
  nitro.hooks.hook("render:html", (htmlContext) => {
    htmlContext.head.push(`<script>${script}<\/script>`);
  });
});

const plugins = [
  _I1yZJKqTBB
];

function hasReqHeader(event, name, includes) {
  const value = getRequestHeader(event, name);
  return value && typeof value === "string" && value.toLowerCase().includes(includes);
}
function isJsonRequest(event) {
  return hasReqHeader(event, "accept", "application/json") || hasReqHeader(event, "user-agent", "curl/") || hasReqHeader(event, "user-agent", "httpie/") || hasReqHeader(event, "sec-fetch-mode", "cors") || event.path.startsWith("/api/") || event.path.endsWith(".json");
}
function normalizeError(error) {
  const cwd = typeof process.cwd === "function" ? process.cwd() : "/";
  const stack = (error.stack || "").split("\n").splice(1).filter((line) => line.includes("at ")).map((line) => {
    const text = line.replace(cwd + "/", "./").replace("webpack:/", "").replace("file://", "").trim();
    return {
      text,
      internal: line.includes("node_modules") && !line.includes(".cache") || line.includes("internal") || line.includes("new Promise")
    };
  });
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage ?? (statusCode === 404 ? "Not Found" : "");
  const message = error.message || error.toString();
  return {
    stack,
    statusCode,
    statusMessage,
    message
  };
}
function trapUnhandledNodeErrors() {
  {
    process.on(
      "unhandledRejection",
      (err) => console.error("[nitro] [unhandledRejection] " + err)
    );
    process.on(
      "uncaughtException",
      (err) => console.error("[nitro]  [uncaughtException] " + err)
    );
  }
}

const errorHandler = (async function errorhandler(error, event) {
  const { stack, statusCode, statusMessage, message } = normalizeError(error);
  const errorObject = {
    url: event.node.req.url,
    statusCode,
    statusMessage,
    message,
    stack: "",
    data: error.data
  };
  if (error.unhandled || error.fatal) {
    const tags = [
      "[nuxt]",
      "[request error]",
      error.unhandled && "[unhandled]",
      error.fatal && "[fatal]",
      Number(errorObject.statusCode) !== 200 && `[${errorObject.statusCode}]`
    ].filter(Boolean).join(" ");
    console.error(tags, errorObject.message + "\n" + stack.map((l) => "  " + l.text).join("  \n"));
  }
  if (event.handled) {
    return;
  }
  setResponseStatus(event, errorObject.statusCode !== 200 && errorObject.statusCode || 500, errorObject.statusMessage);
  if (isJsonRequest(event)) {
    setResponseHeader(event, "Content-Type", "application/json");
    event.node.res.end(JSON.stringify(errorObject));
    return;
  }
  const isErrorPage = event.node.req.url?.startsWith("/__nuxt_error");
  const res = !isErrorPage ? await useNitroApp().localFetch(withQuery(joinURL(useRuntimeConfig().app.baseURL, "/__nuxt_error"), errorObject), {
    headers: getRequestHeaders(event),
    redirect: "manual"
  }).catch(() => null) : null;
  if (!res) {
    const { template } = await import('../error-500.mjs');
    if (event.handled) {
      return;
    }
    setResponseHeader(event, "Content-Type", "text/html;charset=UTF-8");
    event.node.res.end(template(errorObject));
    return;
  }
  const html = await res.text();
  if (event.handled) {
    return;
  }
  for (const [header, value] of res.headers.entries()) {
    setResponseHeader(event, header, value);
  }
  setResponseStatus(event, res.status && res.status !== 200 ? res.status : void 0, res.statusText);
  event.node.res.end(html);
});

const assets = {
  "/logo.png": {
    "type": "image/png",
    "etag": "\"772d-ptUxZPJRJieGancMfmxdGMm0v2M\"",
    "mtime": "2023-07-23T20:56:47.653Z",
    "size": 30509,
    "path": "../public/logo.png"
  },
  "/logotxt.png": {
    "type": "image/png",
    "etag": "\"7ac4-l6OfG6OXVfulecbg0W9sLQhn4AI\"",
    "mtime": "2023-07-13T14:34:53.576Z",
    "size": 31428,
    "path": "../public/logotxt.png"
  },
  "/logo_title.png": {
    "type": "image/png",
    "etag": "\"55e7-8GETrVmRSWUIEJWWeDAJ91TvjEw\"",
    "mtime": "2023-07-29T16:30:50.561Z",
    "size": 21991,
    "path": "../public/logo_title.png"
  },
  "/manifest.webmanifest": {
    "type": "application/manifest+json",
    "etag": "\"1ff-/VFda0czIMwG1BO0UD+LZ1fgm1c\"",
    "mtime": "2023-09-18T18:51:04.338Z",
    "size": 511,
    "path": "../public/manifest.webmanifest"
  },
  "/sw.js": {
    "type": "application/javascript",
    "etag": "\"1e77-qiP2KML8sysaMU6SAiyyscUEMSc\"",
    "mtime": "2023-09-18T18:51:10.926Z",
    "size": 7799,
    "path": "../public/sw.js"
  },
  "/workbox-1bc7d4d5.js": {
    "type": "application/javascript",
    "etag": "\"5579-S+BFj0GC6okBz7fIKcxvZE/Rw28\"",
    "mtime": "2023-09-18T18:51:10.927Z",
    "size": 21881,
    "path": "../public/workbox-1bc7d4d5.js"
  },
  "/_nuxt/address.4d7fe403.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2306-B+7Vy8g2SwO4rjU8mKHOHcmUSes\"",
    "mtime": "2023-09-18T18:51:04.235Z",
    "size": 8966,
    "path": "../public/_nuxt/address.4d7fe403.css"
  },
  "/_nuxt/address.f29e5a89.js": {
    "type": "application/javascript",
    "etag": "\"37fca-ymt9iJrtD0+otmS6gJbpoXp30oM\"",
    "mtime": "2023-09-18T18:51:04.296Z",
    "size": 229322,
    "path": "../public/_nuxt/address.f29e5a89.js"
  },
  "/_nuxt/arrays.e667dc24.js": {
    "type": "application/javascript",
    "etag": "\"5b-o/7qLFCJN1jY/hhQpHxvTvqyRsc\"",
    "mtime": "2023-09-18T18:51:04.247Z",
    "size": 91,
    "path": "../public/_nuxt/arrays.e667dc24.js"
  },
  "/_nuxt/AutoIncre.vue.aa839dd8.js": {
    "type": "application/javascript",
    "etag": "\"25b-SSW+tgkdBqBuURaLNph/bIplRI0\"",
    "mtime": "2023-09-18T18:51:04.247Z",
    "size": 603,
    "path": "../public/_nuxt/AutoIncre.vue.aa839dd8.js"
  },
  "/_nuxt/avatar.504d33a6.js": {
    "type": "application/javascript",
    "etag": "\"558-nOXPVqKge8qIN17Q238pQv7h1wo\"",
    "mtime": "2023-09-18T18:51:04.276Z",
    "size": 1368,
    "path": "../public/_nuxt/avatar.504d33a6.js"
  },
  "/_nuxt/avatar.71943dab.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"360-ulkKmSnyawCQNXiI69b/MYXkh5s\"",
    "mtime": "2023-09-18T18:51:04.237Z",
    "size": 864,
    "path": "../public/_nuxt/avatar.71943dab.css"
  },
  "/_nuxt/bills.834030d1.js": {
    "type": "application/javascript",
    "etag": "\"237-0jdvRyBlgjy7tKjITmPe61E403Y\"",
    "mtime": "2023-09-18T18:51:04.257Z",
    "size": 567,
    "path": "../public/_nuxt/bills.834030d1.js"
  },
  "/_nuxt/category.f0a8bcdc.js": {
    "type": "application/javascript",
    "etag": "\"ed-rY4fgeiJzRo2GhesHzesThll7FI\"",
    "mtime": "2023-09-18T18:51:04.258Z",
    "size": 237,
    "path": "../public/_nuxt/category.f0a8bcdc.js"
  },
  "/_nuxt/checkbox-group.987ef89c.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2e-qFXfygmS4Yyh9gnvuRcvUT4T5X4\"",
    "mtime": "2023-09-18T18:51:04.244Z",
    "size": 46,
    "path": "../public/_nuxt/checkbox-group.987ef89c.css"
  },
  "/_nuxt/checkbox.27f8a384.js": {
    "type": "application/javascript",
    "etag": "\"28b9-at8D+bbdOZp4cafHI/Vr60marl8\"",
    "mtime": "2023-09-18T18:51:04.269Z",
    "size": 10425,
    "path": "../public/_nuxt/checkbox.27f8a384.js"
  },
  "/_nuxt/checkbox.3d04fbdb.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1941-93Y6ArbVKInfnV00dKN4y4Qt1xM\"",
    "mtime": "2023-09-18T18:51:04.246Z",
    "size": 6465,
    "path": "../public/_nuxt/checkbox.3d04fbdb.css"
  },
  "/_nuxt/cloneDeep.dcd05989.js": {
    "type": "application/javascript",
    "etag": "\"63-FJlk0khE09LCN47vA0oAE/NsSms\"",
    "mtime": "2023-09-18T18:51:04.247Z",
    "size": 99,
    "path": "../public/_nuxt/cloneDeep.dcd05989.js"
  },
  "/_nuxt/collect.00878209.js": {
    "type": "application/javascript",
    "etag": "\"1eb9-UJK3YhZpi17UmLjS8SZ9wFzJf2Q\"",
    "mtime": "2023-09-18T18:51:04.277Z",
    "size": 7865,
    "path": "../public/_nuxt/collect.00878209.js"
  },
  "/_nuxt/collect.d6cd5d85.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"fad-+jTrjGboAGK/f7Dr5JAvpe9vPew\"",
    "mtime": "2023-09-18T18:51:04.234Z",
    "size": 4013,
    "path": "../public/_nuxt/collect.d6cd5d85.css"
  },
  "/_nuxt/collect.fef0a0f2.js": {
    "type": "application/javascript",
    "etag": "\"1b8-iDxK1UaXYoZV5Hmd4wzD7o7D1UU\"",
    "mtime": "2023-09-18T18:51:04.246Z",
    "size": 440,
    "path": "../public/_nuxt/collect.fef0a0f2.js"
  },
  "/_nuxt/composables.3b53c41a.js": {
    "type": "application/javascript",
    "etag": "\"5b-MsZHAcV9T+Yg/b0hBBcUbvZrM9s\"",
    "mtime": "2023-09-18T18:51:04.258Z",
    "size": 91,
    "path": "../public/_nuxt/composables.3b53c41a.js"
  },
  "/_nuxt/debounce.3beb343f.js": {
    "type": "application/javascript",
    "etag": "\"5f1-l8qmDE/8gVFXrQJqIUcPLh+5UhI\"",
    "mtime": "2023-09-18T18:51:04.257Z",
    "size": 1521,
    "path": "../public/_nuxt/debounce.3beb343f.js"
  },
  "/_nuxt/DelayTimer.vue.fcf975ff.js": {
    "type": "application/javascript",
    "etag": "\"33d-2nF12br9rn1Ll86T3qnpqECJLy4\"",
    "mtime": "2023-09-18T18:51:04.256Z",
    "size": 829,
    "path": "../public/_nuxt/DelayTimer.vue.fcf975ff.js"
  },
  "/_nuxt/detail.075acde0.js": {
    "type": "application/javascript",
    "etag": "\"15e9-ifw22GXHHQ6ebWGRTsADEe8DfjE\"",
    "mtime": "2023-09-18T18:51:04.267Z",
    "size": 5609,
    "path": "../public/_nuxt/detail.075acde0.js"
  },
  "/_nuxt/detail.9ceddf54.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"19c-+anySSSnoOXnmjiNLGARLRH6MHM\"",
    "mtime": "2023-09-18T18:51:04.226Z",
    "size": 412,
    "path": "../public/_nuxt/detail.9ceddf54.css"
  },
  "/_nuxt/detail.a5f28f24.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2b1c-vqp4ScUCc9jRdR3xRTpAKnqq/a8\"",
    "mtime": "2023-09-18T18:51:04.226Z",
    "size": 11036,
    "path": "../public/_nuxt/detail.a5f28f24.css"
  },
  "/_nuxt/detail.adc82395.js": {
    "type": "application/javascript",
    "etag": "\"ac9a-6V+Paa720myLCBBBv6Ej4N/VLcg\"",
    "mtime": "2023-09-18T18:51:04.296Z",
    "size": 44186,
    "path": "../public/_nuxt/detail.adc82395.js"
  },
  "/_nuxt/dialog.c614b8ee.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"d76-1jDAcu5W2VHNi+wDh/lPUSzv7Sk\"",
    "mtime": "2023-09-18T18:51:04.235Z",
    "size": 3446,
    "path": "../public/_nuxt/dialog.c614b8ee.css"
  },
  "/_nuxt/divider.07810808.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2c2-aZTwdFAd2kjucv4FlePPXYHT5f4\"",
    "mtime": "2023-09-18T18:51:04.237Z",
    "size": 706,
    "path": "../public/_nuxt/divider.07810808.css"
  },
  "/_nuxt/divider.d4f2f936.js": {
    "type": "application/javascript",
    "etag": "\"394-9MF6VicprkCrVouTz2DW187LJAo\"",
    "mtime": "2023-09-18T18:51:04.268Z",
    "size": 916,
    "path": "../public/_nuxt/divider.d4f2f936.js"
  },
  "/_nuxt/entry.1d0ff192.js": {
    "type": "application/javascript",
    "etag": "\"233f40-k+SVTb8uP+vJngwrsscLzuCT6N8\"",
    "mtime": "2023-09-18T18:51:04.299Z",
    "size": 2309952,
    "path": "../public/_nuxt/entry.1d0ff192.js"
  },
  "/_nuxt/entry.9503c545.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"5d09d-tZ3+sx9DCUs1gXAt/UQPCGJpDJQ\"",
    "mtime": "2023-09-18T18:51:04.247Z",
    "size": 381085,
    "path": "../public/_nuxt/entry.9503c545.css"
  },
  "/_nuxt/error.b6a9be4b.js": {
    "type": "application/javascript",
    "etag": "\"117-AwmoZIlAokLTbY1lHG0R7gzD7sU\"",
    "mtime": "2023-09-18T18:51:04.256Z",
    "size": 279,
    "path": "../public/_nuxt/error.b6a9be4b.js"
  },
  "/_nuxt/flatten.0dbf6d4b.js": {
    "type": "application/javascript",
    "etag": "\"17a-pHCv9yQYfFtEJpPpdX0qEa2Nw2c\"",
    "mtime": "2023-09-18T18:51:04.266Z",
    "size": 378,
    "path": "../public/_nuxt/flatten.0dbf6d4b.js"
  },
  "/_nuxt/focus-trap.ef80684b.js": {
    "type": "application/javascript",
    "etag": "\"14cd-VUjcSwfmTifDNWjovq4Hbsfkth0\"",
    "mtime": "2023-09-18T18:51:04.267Z",
    "size": 5325,
    "path": "../public/_nuxt/focus-trap.ef80684b.js"
  },
  "/_nuxt/Footer.5833f65c.js": {
    "type": "application/javascript",
    "etag": "\"2c7c-JjXXnEi4qX7ugZ05vxehvX9g4xw\"",
    "mtime": "2023-09-18T18:51:04.277Z",
    "size": 11388,
    "path": "../public/_nuxt/Footer.5833f65c.js"
  },
  "/_nuxt/Footer.dca36282.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"f29-BUs4JKxcHBtEhL0/WTfyDAgIv9Q\"",
    "mtime": "2023-09-18T18:51:04.237Z",
    "size": 3881,
    "path": "../public/_nuxt/Footer.dca36282.css"
  },
  "/_nuxt/GoodsList.00ac3138.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"208-1XtOJp7KAUpeb1tuK8Atn5YiHXg\"",
    "mtime": "2023-09-18T18:51:04.227Z",
    "size": 520,
    "path": "../public/_nuxt/GoodsList.00ac3138.css"
  },
  "/_nuxt/GoodsList.4851e079.js": {
    "type": "application/javascript",
    "etag": "\"112b-lyQw/ErepAAmSgZe0Iy5/jGiH6o\"",
    "mtime": "2023-09-18T18:51:04.296Z",
    "size": 4395,
    "path": "../public/_nuxt/GoodsList.4851e079.js"
  },
  "/_nuxt/image-viewer.a57f8530.js": {
    "type": "application/javascript",
    "etag": "\"25fb-Sk4hw6jSJfLru/T0hhlndNrMAVs\"",
    "mtime": "2023-09-18T18:51:04.279Z",
    "size": 9723,
    "path": "../public/_nuxt/image-viewer.a57f8530.js"
  },
  "/_nuxt/image-viewer.bcc58336.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"9f3-RjdhLMtY9zEjcYP+HM3AfyThA2s\"",
    "mtime": "2023-09-18T18:51:04.246Z",
    "size": 2547,
    "path": "../public/_nuxt/image-viewer.bcc58336.css"
  },
  "/_nuxt/index.0d74788c.js": {
    "type": "application/javascript",
    "etag": "\"321-o9j6stux2h3hbscx6K4iq8injSs\"",
    "mtime": "2023-09-18T18:51:04.277Z",
    "size": 801,
    "path": "../public/_nuxt/index.0d74788c.js"
  },
  "/_nuxt/index.1af78815.js": {
    "type": "application/javascript",
    "etag": "\"1b0-1F2hQb4n5OCnY+PcyzBrdae10FA\"",
    "mtime": "2023-09-18T18:51:04.255Z",
    "size": 432,
    "path": "../public/_nuxt/index.1af78815.js"
  },
  "/_nuxt/index.1e34d4fc.js": {
    "type": "application/javascript",
    "etag": "\"3a0-tyn1SE8eycObLohJQFv3BD1VfjU\"",
    "mtime": "2023-09-18T18:51:04.257Z",
    "size": 928,
    "path": "../public/_nuxt/index.1e34d4fc.js"
  },
  "/_nuxt/index.3404649f.js": {
    "type": "application/javascript",
    "etag": "\"773-LUZhankoZynNhktzJpUQUVokS4M\"",
    "mtime": "2023-09-18T18:51:04.266Z",
    "size": 1907,
    "path": "../public/_nuxt/index.3404649f.js"
  },
  "/_nuxt/index.37a97259.js": {
    "type": "application/javascript",
    "etag": "\"1ab-Q3KyKOBexTqQkQvchf2Ci6ERA/8\"",
    "mtime": "2023-09-18T18:51:04.257Z",
    "size": 427,
    "path": "../public/_nuxt/index.37a97259.js"
  },
  "/_nuxt/index.44abc126.js": {
    "type": "application/javascript",
    "etag": "\"ea-Zh9NVLI4sAC3jR0sFnwayhvDD2M\"",
    "mtime": "2023-09-18T18:51:04.266Z",
    "size": 234,
    "path": "../public/_nuxt/index.44abc126.js"
  },
  "/_nuxt/index.721d6832.js": {
    "type": "application/javascript",
    "etag": "\"109-QJDw2238iHcQOT/TQh4523tj+Tc\"",
    "mtime": "2023-09-18T18:51:04.266Z",
    "size": 265,
    "path": "../public/_nuxt/index.721d6832.js"
  },
  "/_nuxt/index.779bf283.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3cc-2CTZnI6BN4eAFslkJsinUVcc9FI\"",
    "mtime": "2023-09-18T18:51:04.237Z",
    "size": 972,
    "path": "../public/_nuxt/index.779bf283.css"
  },
  "/_nuxt/index.7a00cec5.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"41-VBFyvBUMNtrMkXi3ywDaHp9Rm4k\"",
    "mtime": "2023-09-18T18:51:04.226Z",
    "size": 65,
    "path": "../public/_nuxt/index.7a00cec5.css"
  },
  "/_nuxt/index.7d1d95b8.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"820-Gd0+MXGcnhAImg4zEK+6i8uq9zo\"",
    "mtime": "2023-09-18T18:51:04.226Z",
    "size": 2080,
    "path": "../public/_nuxt/index.7d1d95b8.css"
  },
  "/_nuxt/index.7d8b4588.js": {
    "type": "application/javascript",
    "etag": "\"1399-vX/ZINx6+0UxDmaXhgFWaHEkgbI\"",
    "mtime": "2023-09-18T18:51:04.266Z",
    "size": 5017,
    "path": "../public/_nuxt/index.7d8b4588.js"
  },
  "/_nuxt/index.943ae561.js": {
    "type": "application/javascript",
    "etag": "\"3dc3-IIRii881zEC4LWet9lEG3/5EOYs\"",
    "mtime": "2023-09-18T18:51:04.279Z",
    "size": 15811,
    "path": "../public/_nuxt/index.943ae561.js"
  },
  "/_nuxt/index.9619c765.js": {
    "type": "application/javascript",
    "etag": "\"1d46-Spd2oJWFhoyE7OPEcloVfvfdUHY\"",
    "mtime": "2023-09-18T18:51:04.267Z",
    "size": 7494,
    "path": "../public/_nuxt/index.9619c765.js"
  },
  "/_nuxt/index.a21fd3fe.js": {
    "type": "application/javascript",
    "etag": "\"1b15-EsZD/2dhslrTobQdg8LspmKlD2c\"",
    "mtime": "2023-09-18T18:51:04.267Z",
    "size": 6933,
    "path": "../public/_nuxt/index.a21fd3fe.js"
  },
  "/_nuxt/index.b7cd6de3.js": {
    "type": "application/javascript",
    "etag": "\"153-UIQ7hPdvI/X5l90bienpHjhOWC0\"",
    "mtime": "2023-09-18T18:51:04.257Z",
    "size": 339,
    "path": "../public/_nuxt/index.b7cd6de3.js"
  },
  "/_nuxt/index.c8eed2e2.js": {
    "type": "application/javascript",
    "etag": "\"1641-x8U4/nPHGRx2xMuJC+1ZaBfdx90\"",
    "mtime": "2023-09-18T18:51:04.268Z",
    "size": 5697,
    "path": "../public/_nuxt/index.c8eed2e2.js"
  },
  "/_nuxt/index.f2acc437.js": {
    "type": "application/javascript",
    "etag": "\"68b-mSr132qg5ou8XynCegADA0GAGtQ\"",
    "mtime": "2023-09-18T18:51:04.247Z",
    "size": 1675,
    "path": "../public/_nuxt/index.f2acc437.js"
  },
  "/_nuxt/index.feddc1f9.js": {
    "type": "application/javascript",
    "etag": "\"153-RaaoqvBZ0/7HFlxPQdakxDgJk2k\"",
    "mtime": "2023-09-18T18:51:04.258Z",
    "size": 339,
    "path": "../public/_nuxt/index.feddc1f9.js"
  },
  "/_nuxt/index_bg.496ee798.png": {
    "type": "image/png",
    "etag": "\"3a467-ZmMh8dqqRmVFUx/fXDMFICJ/SO8\"",
    "mtime": "2023-09-18T18:51:04.226Z",
    "size": 238695,
    "path": "../public/_nuxt/index_bg.496ee798.png"
  },
  "/_nuxt/info.5f5b91a3.js": {
    "type": "application/javascript",
    "etag": "\"28e5-oOma0OIpnIkzBqIgv3NOEGEPp00\"",
    "mtime": "2023-09-18T18:51:04.278Z",
    "size": 10469,
    "path": "../public/_nuxt/info.5f5b91a3.js"
  },
  "/_nuxt/info.e0008b9e.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"30e-NOXPOIa9aodwlz4+UtjgaUyVXkQ\"",
    "mtime": "2023-09-18T18:51:04.236Z",
    "size": 782,
    "path": "../public/_nuxt/info.e0008b9e.css"
  },
  "/_nuxt/input-number.706384ee.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"f31-4K4TeynLXoChVbsPgfp4gipoDSk\"",
    "mtime": "2023-09-18T18:51:04.246Z",
    "size": 3889,
    "path": "../public/_nuxt/input-number.706384ee.css"
  },
  "/_nuxt/input-number.a0212393.js": {
    "type": "application/javascript",
    "etag": "\"1672-GK1LUaH/vGJqwEMhmHorgrYbA0g\"",
    "mtime": "2023-09-18T18:51:04.296Z",
    "size": 5746,
    "path": "../public/_nuxt/input-number.a0212393.js"
  },
  "/_nuxt/isEqual.fb3c55d2.js": {
    "type": "application/javascript",
    "etag": "\"d05-vm1qkItVbpOmRk0ubPV6RRRXwbY\"",
    "mtime": "2023-09-18T18:51:04.267Z",
    "size": 3333,
    "path": "../public/_nuxt/isEqual.fb3c55d2.js"
  },
  "/_nuxt/kiwi_strong.302ebbc3.svg": {
    "type": "image/svg+xml",
    "etag": "\"889-JaNvUKvjU6kSvuM9S7Bt3uT6+zU\"",
    "mtime": "2023-09-18T18:51:04.224Z",
    "size": 2185,
    "path": "../public/_nuxt/kiwi_strong.302ebbc3.svg"
  },
  "/_nuxt/list.5c9e3279.js": {
    "type": "application/javascript",
    "etag": "\"13ce5-AUupxeZ7twGdStGU4nVo1xx21is\"",
    "mtime": "2023-09-18T18:51:04.296Z",
    "size": 81125,
    "path": "../public/_nuxt/list.5c9e3279.js"
  },
  "/_nuxt/list.ae6b4ade.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"5f27-3Qb+DNpB4LArYbF2id+TCQemZGg\"",
    "mtime": "2023-09-18T18:51:04.226Z",
    "size": 24359,
    "path": "../public/_nuxt/list.ae6b4ade.css"
  },
  "/_nuxt/localeData.0b229474.js": {
    "type": "application/javascript",
    "etag": "\"2750-6oyaynx9anAjZhEK4IjwvGLBAZA\"",
    "mtime": "2023-09-18T18:51:04.267Z",
    "size": 10064,
    "path": "../public/_nuxt/localeData.0b229474.js"
  },
  "/_nuxt/logo.d378a10a.png": {
    "type": "image/png",
    "etag": "\"205f3-N9zqtvdxHFo9KNeGix+hSuRhMC0\"",
    "mtime": "2023-09-18T18:51:04.225Z",
    "size": 132595,
    "path": "../public/_nuxt/logo.d378a10a.png"
  },
  "/_nuxt/logo_dark.692df090.png": {
    "type": "image/png",
    "etag": "\"5bab-o4Ord234RMytKyVopADe5JaYMTI\"",
    "mtime": "2023-09-18T18:51:04.225Z",
    "size": 23467,
    "path": "../public/_nuxt/logo_dark.692df090.png"
  },
  "/_nuxt/logo_txt.318d9294.png": {
    "type": "image/png",
    "etag": "\"75d3-IOiNnXu6QwEmY0FexWGF1P+t1w4\"",
    "mtime": "2023-09-18T18:51:04.225Z",
    "size": 30163,
    "path": "../public/_nuxt/logo_txt.318d9294.png"
  },
  "/_nuxt/main.0a4540c2.js": {
    "type": "application/javascript",
    "etag": "\"17ef-iQ1czB4fI2haSHg5ip39mjQ7mBM\"",
    "mtime": "2023-09-18T18:51:04.276Z",
    "size": 6127,
    "path": "../public/_nuxt/main.0a4540c2.js"
  },
  "/_nuxt/main.8299cc0d.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"c2d-f+SO8l0kRBPGk+AUmRYjkrrWjHg\"",
    "mtime": "2023-09-18T18:51:04.237Z",
    "size": 3117,
    "path": "../public/_nuxt/main.8299cc0d.css"
  },
  "/_nuxt/menu.c0494e22.js": {
    "type": "application/javascript",
    "etag": "\"3a59-p1xwA4qzP05E42+RkdNwX7g+F8U\"",
    "mtime": "2023-09-18T18:51:04.296Z",
    "size": 14937,
    "path": "../public/_nuxt/menu.c0494e22.js"
  },
  "/_nuxt/menu.d3c11cc9.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"280c-by+MaAw61aOnnXOrpDRqGZJ6U0A\"",
    "mtime": "2023-09-18T18:51:04.237Z",
    "size": 10252,
    "path": "../public/_nuxt/menu.d3c11cc9.css"
  },
  "/_nuxt/message-box.1728334f.js": {
    "type": "application/javascript",
    "etag": "\"2e0a-ZKu5HoTRM1nipWPnnXha2DQBIc4\"",
    "mtime": "2023-09-18T18:51:04.277Z",
    "size": 11786,
    "path": "../public/_nuxt/message-box.1728334f.js"
  },
  "/_nuxt/message-box.7f332db5.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"144f-C2rgE7szpAgF1TXfJl3M0zoMHvc\"",
    "mtime": "2023-09-18T18:51:04.246Z",
    "size": 5199,
    "path": "../public/_nuxt/message-box.7f332db5.css"
  },
  "/_nuxt/moon.768cb03d.svg": {
    "type": "image/svg+xml",
    "etag": "\"8c1-+ebizzSqqhl84c+aEwkRUbIuazs\"",
    "mtime": "2023-09-18T18:51:04.225Z",
    "size": 2241,
    "path": "../public/_nuxt/moon.768cb03d.svg"
  },
  "/_nuxt/notification.5c26b3d0.js": {
    "type": "application/javascript",
    "etag": "\"1192-boDr+4Z8r0YESr8vKezfvdwtquk\"",
    "mtime": "2023-09-18T18:51:04.296Z",
    "size": 4498,
    "path": "../public/_nuxt/notification.5c26b3d0.js"
  },
  "/_nuxt/notification.af5dcd65.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"c32-V2j+lpCCv+x2y56lOX6YRZTnZkM\"",
    "mtime": "2023-09-18T18:51:04.227Z",
    "size": 3122,
    "path": "../public/_nuxt/notification.af5dcd65.css"
  },
  "/_nuxt/nuxt-link.076cd19c.js": {
    "type": "application/javascript",
    "etag": "\"1415-j98iu2Ft28ox/OBnA6bK9tbepMU\"",
    "mtime": "2023-09-18T18:51:04.267Z",
    "size": 5141,
    "path": "../public/_nuxt/nuxt-link.076cd19c.js"
  },
  "/_nuxt/overlay.6e0625dd.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"b8-76nQgG8l8UzzOEcfS6sooTMGznw\"",
    "mtime": "2023-09-18T18:51:04.246Z",
    "size": 184,
    "path": "../public/_nuxt/overlay.6e0625dd.css"
  },
  "/_nuxt/overlay.a57d50d1.js": {
    "type": "application/javascript",
    "etag": "\"ad1-Je8dqX71UAdAkZ6y5cL4gh6/Pxo\"",
    "mtime": "2023-09-18T18:51:04.275Z",
    "size": 2769,
    "path": "../public/_nuxt/overlay.a57d50d1.js"
  },
  "/_nuxt/popover.1f4352fc.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"563-tWYlqdJD+gJD+EisTiyLrsAh8do\"",
    "mtime": "2023-09-18T18:51:04.246Z",
    "size": 1379,
    "path": "../public/_nuxt/popover.1f4352fc.css"
  },
  "/_nuxt/popper.0d433965.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"8f2-FysLkU3QD/jqxgzw4iAd4avQW7M\"",
    "mtime": "2023-09-18T18:51:04.246Z",
    "size": 2290,
    "path": "../public/_nuxt/popper.0d433965.css"
  },
  "/_nuxt/popper.51715de2.js": {
    "type": "application/javascript",
    "etag": "\"9a2d-LtbR24iXPd4CuAF3yQ7LDQ5DRJI\"",
    "mtime": "2023-09-18T18:51:04.296Z",
    "size": 39469,
    "path": "../public/_nuxt/popper.51715de2.js"
  },
  "/_nuxt/progress.1f193c71.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"a25-QbSzVA2WpsmqMvaoNNRMxkWsi88\"",
    "mtime": "2023-09-18T18:51:04.237Z",
    "size": 2597,
    "path": "../public/_nuxt/progress.1f193c71.css"
  },
  "/_nuxt/progress.de31a7be.js": {
    "type": "application/javascript",
    "etag": "\"115f-IUrrYg5iH3S7V4Z+fzxn3ERZpNs\"",
    "mtime": "2023-09-18T18:51:04.296Z",
    "size": 4447,
    "path": "../public/_nuxt/progress.de31a7be.js"
  },
  "/_nuxt/radio-group.3b9ac3ad.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"53-QQtqnw/A9XQy1Q+tqPo+8MPK/mg\"",
    "mtime": "2023-09-18T18:51:04.227Z",
    "size": 83,
    "path": "../public/_nuxt/radio-group.3b9ac3ad.css"
  },
  "/_nuxt/radio.2efacd0a.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"10d9-mXPrP3xq8GEvgCKL+5t6OojiJxI\"",
    "mtime": "2023-09-18T18:51:04.235Z",
    "size": 4313,
    "path": "../public/_nuxt/radio.2efacd0a.css"
  },
  "/_nuxt/radio.f3092f9b.js": {
    "type": "application/javascript",
    "etag": "\"1257-uQQ9rncIOt8GmDYUtNrS4ifwrog\"",
    "mtime": "2023-09-18T18:51:04.269Z",
    "size": 4695,
    "path": "../public/_nuxt/radio.f3092f9b.js"
  },
  "/_nuxt/rand.14326ce1.js": {
    "type": "application/javascript",
    "etag": "\"3a-Dz2tPC6JZ3XaATIh12hWFBh6sNg\"",
    "mtime": "2023-09-18T18:51:04.256Z",
    "size": 58,
    "path": "../public/_nuxt/rand.14326ce1.js"
  },
  "/_nuxt/rate.22f46704.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"543-lAm7XXNnGddANwTXiG2S84xQarY\"",
    "mtime": "2023-09-18T18:51:04.226Z",
    "size": 1347,
    "path": "../public/_nuxt/rate.22f46704.css"
  },
  "/_nuxt/rate.2ee4464f.js": {
    "type": "application/javascript",
    "etag": "\"13ed-ff6ZIUjhVsUU0wa/7X23BF37ZMc\"",
    "mtime": "2023-09-18T18:51:04.275Z",
    "size": 5101,
    "path": "../public/_nuxt/rate.2ee4464f.js"
  },
  "/_nuxt/RightButtons.add1503b.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"819-dogIkhruRRqTMy9VZHY1f1e5Ldg\"",
    "mtime": "2023-09-18T18:51:04.237Z",
    "size": 2073,
    "path": "../public/_nuxt/RightButtons.add1503b.css"
  },
  "/_nuxt/RightButtons.f41c795a.js": {
    "type": "application/javascript",
    "etag": "\"2899-Fr4Gkwloo4yWihX/5+Z1IK/fybo\"",
    "mtime": "2023-09-18T18:51:04.296Z",
    "size": 10393,
    "path": "../public/_nuxt/RightButtons.f41c795a.js"
  },
  "/_nuxt/safe.2777a56e.js": {
    "type": "application/javascript",
    "etag": "\"45a2-HDOR32fJWPrYeujP0jj1eF4RP/k\"",
    "mtime": "2023-09-18T18:51:04.277Z",
    "size": 17826,
    "path": "../public/_nuxt/safe.2777a56e.js"
  },
  "/_nuxt/safe.71c0a412.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1326-h2ZgxjKRDlCozCxwO9oD9zbOMX0\"",
    "mtime": "2023-09-18T18:51:04.236Z",
    "size": 4902,
    "path": "../public/_nuxt/safe.71c0a412.css"
  },
  "/_nuxt/scroll.93faf99e.js": {
    "type": "application/javascript",
    "etag": "\"4a6-ugcv9+wkdqkhzKxw42GR2phuVCA\"",
    "mtime": "2023-09-18T18:51:04.256Z",
    "size": 1190,
    "path": "../public/_nuxt/scroll.93faf99e.js"
  },
  "/_nuxt/scrollbar.338d4a20.js": {
    "type": "application/javascript",
    "etag": "\"1938-AzbKaqAvQqZNY6dvfNfeTGvhkeU\"",
    "mtime": "2023-09-18T18:51:04.278Z",
    "size": 6456,
    "path": "../public/_nuxt/scrollbar.338d4a20.js"
  },
  "/_nuxt/scrollbar.77c43fec.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"545-ieaqVxO8Au5ZT/2tuBKp/FTfD78\"",
    "mtime": "2023-09-18T18:51:04.246Z",
    "size": 1349,
    "path": "../public/_nuxt/scrollbar.77c43fec.css"
  },
  "/_nuxt/second.c4a23853.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"cd-p2wdmjs5XyHDotvl6RFBuH9ybHc\"",
    "mtime": "2023-09-18T18:51:04.237Z",
    "size": 205,
    "path": "../public/_nuxt/second.c4a23853.css"
  },
  "/_nuxt/second.d9650c13.js": {
    "type": "application/javascript",
    "etag": "\"74f-I1QxOWqV5VlpohnWJDVwT4TpcHc\"",
    "mtime": "2023-09-18T18:51:04.268Z",
    "size": 1871,
    "path": "../public/_nuxt/second.d9650c13.js"
  },
  "/_nuxt/select.d289ec57.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2627-9H4AyNqK/6lywVspZPk1IcBlHjU\"",
    "mtime": "2023-09-18T18:51:04.246Z",
    "size": 9767,
    "path": "../public/_nuxt/select.d289ec57.css"
  },
  "/_nuxt/select.db777ad8.js": {
    "type": "application/javascript",
    "etag": "\"7aa8-uMrptTFNpdBirYL46YoZ2jp4xeg\"",
    "mtime": "2023-09-18T18:51:04.278Z",
    "size": 31400,
    "path": "../public/_nuxt/select.db777ad8.js"
  },
  "/_nuxt/shopcart.08d01407.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3f3-RCpXQtpQb2+0kVMXFInLNTd4m74\"",
    "mtime": "2023-09-18T18:51:04.237Z",
    "size": 1011,
    "path": "../public/_nuxt/shopcart.08d01407.css"
  },
  "/_nuxt/shopcart.62c1fab1.js": {
    "type": "application/javascript",
    "etag": "\"160a-Kn3i2/2beA8abuX/4QqxUtn+Wcg\"",
    "mtime": "2023-09-18T18:51:04.276Z",
    "size": 5642,
    "path": "../public/_nuxt/shopcart.62c1fab1.js"
  },
  "/_nuxt/ShopLine.9dae93ba.js": {
    "type": "application/javascript",
    "etag": "\"104e-y4L0cg7VlskFBm/++aX+QfpdciY\"",
    "mtime": "2023-09-18T18:51:04.276Z",
    "size": 4174,
    "path": "../public/_nuxt/ShopLine.9dae93ba.js"
  },
  "/_nuxt/ShopLine.bde401b7.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3f-MIjqY7dfJKnolLK/qEx3iFXt8gY\"",
    "mtime": "2023-09-18T18:51:04.245Z",
    "size": 63,
    "path": "../public/_nuxt/ShopLine.bde401b7.css"
  },
  "/_nuxt/sku.f9edecf6.js": {
    "type": "application/javascript",
    "etag": "\"110-SZ9TZjbipWEWT3IdMG5F6AZM+34\"",
    "mtime": "2023-09-18T18:51:04.256Z",
    "size": 272,
    "path": "../public/_nuxt/sku.f9edecf6.js"
  },
  "/_nuxt/strings.1a075906.js": {
    "type": "application/javascript",
    "etag": "\"9d-3N+75IrL+ucUPLJJZHVyI2Jge28\"",
    "mtime": "2023-09-18T18:51:04.256Z",
    "size": 157,
    "path": "../public/_nuxt/strings.1a075906.js"
  },
  "/_nuxt/success_cone.dbb5ad81.svg": {
    "type": "image/svg+xml",
    "etag": "\"189f-pF04EJgCNNEElgJeVi4tjuFj9Z8\"",
    "mtime": "2023-09-18T18:51:04.225Z",
    "size": 6303,
    "path": "../public/_nuxt/success_cone.dbb5ad81.svg"
  },
  "/_nuxt/sun.bc0856fb.svg": {
    "type": "image/svg+xml",
    "etag": "\"a2d-RdolZoo2ptZHIBj8RjYens9rpWw\"",
    "mtime": "2023-09-18T18:51:04.225Z",
    "size": 2605,
    "path": "../public/_nuxt/sun.bc0856fb.svg"
  },
  "/_nuxt/swiper-vue.87e2a882.js": {
    "type": "application/javascript",
    "etag": "\"2f92f-zcjfDIM93MIxZjgO8tumJ+tWtaQ\"",
    "mtime": "2023-09-18T18:51:04.267Z",
    "size": 194863,
    "path": "../public/_nuxt/swiper-vue.87e2a882.js"
  },
  "/_nuxt/swiper-vue.9c2b2ee8.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"45bf-SimSdJenb2efc9po2tnseSK3RBg\"",
    "mtime": "2023-09-18T18:51:04.225Z",
    "size": 17855,
    "path": "../public/_nuxt/swiper-vue.9c2b2ee8.css"
  },
  "/_nuxt/Switch.6e8449cf.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"e7-x8PvKoZSbJqwYLri0huNtKW7DyM\"",
    "mtime": "2023-09-18T18:51:04.244Z",
    "size": 231,
    "path": "../public/_nuxt/Switch.6e8449cf.css"
  },
  "/_nuxt/Switch.b372799a.js": {
    "type": "application/javascript",
    "etag": "\"5cf-rjS402IdXpH6jEzi2tFqY+YBRxQ\"",
    "mtime": "2023-09-18T18:51:04.276Z",
    "size": 1487,
    "path": "../public/_nuxt/Switch.b372799a.js"
  },
  "/_nuxt/tabs.79de4b2d.js": {
    "type": "application/javascript",
    "etag": "\"2290-LMQlm9J0YZSejhD0nt4pKv8M568\"",
    "mtime": "2023-09-18T18:51:04.275Z",
    "size": 8848,
    "path": "../public/_nuxt/tabs.79de4b2d.js"
  },
  "/_nuxt/tabs.ddb6c28f.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"4260-FjgMpy70OPptfu2MbjafO2UrmJo\"",
    "mtime": "2023-09-18T18:51:04.236Z",
    "size": 16992,
    "path": "../public/_nuxt/tabs.ddb6c28f.css"
  },
  "/_nuxt/tag.55f0b9b2.js": {
    "type": "application/javascript",
    "etag": "\"6e2-c2AApnEQQRVJHDaiq+2qXewOXPE\"",
    "mtime": "2023-09-18T18:51:04.275Z",
    "size": 1762,
    "path": "../public/_nuxt/tag.55f0b9b2.js"
  },
  "/_nuxt/tag.da83e147.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"179f-W2HFgeLTM+p/rPMBvoUKSi1Ifj0\"",
    "mtime": "2023-09-18T18:51:04.246Z",
    "size": 6047,
    "path": "../public/_nuxt/tag.da83e147.css"
  },
  "/_nuxt/tooltip.e3b0c442.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"0-2jmj7l5rSw0yVb/vlWAYkK/YBwk\"",
    "mtime": "2023-09-18T18:51:04.240Z",
    "size": 0,
    "path": "../public/_nuxt/tooltip.e3b0c442.css"
  },
  "/_nuxt/upload.40d65e69.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2a80-z+V26p5/MLUiBCF4xzYDosxqD1Q\"",
    "mtime": "2023-09-18T18:51:04.237Z",
    "size": 10880,
    "path": "../public/_nuxt/upload.40d65e69.css"
  },
  "/_nuxt/upload.879ac519.js": {
    "type": "application/javascript",
    "etag": "\"3407-rMphWGZAucfkeuNI6NY2eY2nTnQ\"",
    "mtime": "2023-09-18T18:51:04.296Z",
    "size": 13319,
    "path": "../public/_nuxt/upload.879ac519.js"
  },
  "/_nuxt/useFetchUtil.c815d1b7.js": {
    "type": "application/javascript",
    "etag": "\"6d-fMLlhz9gDMWgEuyGXrKhpadXuhs\"",
    "mtime": "2023-09-18T18:51:04.256Z",
    "size": 109,
    "path": "../public/_nuxt/useFetchUtil.c815d1b7.js"
  },
  "/_nuxt/user.2f9261e3.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"bc3-BWgnR/8rAuGqJJKOm/0N6hB5bGw\"",
    "mtime": "2023-09-18T18:51:04.237Z",
    "size": 3011,
    "path": "../public/_nuxt/user.2f9261e3.css"
  },
  "/_nuxt/user.677ba332.js": {
    "type": "application/javascript",
    "etag": "\"1a65-bb1O2CFErbYxutujilVkqxiZVy0\"",
    "mtime": "2023-09-18T18:51:04.277Z",
    "size": 6757,
    "path": "../public/_nuxt/user.677ba332.js"
  },
  "/_nuxt/validator.409c16d0.js": {
    "type": "application/javascript",
    "etag": "\"5a-KDS+8/OOW30aDdYJPWRmepPNRZ0\"",
    "mtime": "2023-09-18T18:51:04.256Z",
    "size": 90,
    "path": "../public/_nuxt/validator.409c16d0.js"
  },
  "/_nuxt/vnode.98844ac6.js": {
    "type": "application/javascript",
    "etag": "\"2d1-GAvkdq+YZ8HfHkcNmIM152ENMzg\"",
    "mtime": "2023-09-18T18:51:04.256Z",
    "size": 721,
    "path": "../public/_nuxt/vnode.98844ac6.js"
  },
  "/_nuxt/wallet.468a7c3f.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1bca-7wooireFR5O0/1pKEJIPj3ZT+7M\"",
    "mtime": "2023-09-18T18:51:04.237Z",
    "size": 7114,
    "path": "../public/_nuxt/wallet.468a7c3f.css"
  },
  "/_nuxt/wallet.c6fbd66c.js": {
    "type": "application/javascript",
    "etag": "\"6f2d6-4xVuJAls1+HXc9v3qEeBNZEZHl0\"",
    "mtime": "2023-09-18T18:51:04.297Z",
    "size": 455382,
    "path": "../public/_nuxt/wallet.c6fbd66c.js"
  },
  "/_nuxt/workbox-window.prod.es5.a7b12eab.js": {
    "type": "application/javascript",
    "etag": "\"14a9-PgD6LVq3AWVnktFTXJIaapz+xFw\"",
    "mtime": "2023-09-18T18:51:04.266Z",
    "size": 5289,
    "path": "../public/_nuxt/workbox-window.prod.es5.a7b12eab.js"
  },
  "/_nuxt/_...all_.a27f233e.js": {
    "type": "application/javascript",
    "etag": "\"13a-DXi+lA81O2B9Quh1fLXKLeiIXp4\"",
    "mtime": "2023-09-18T18:51:04.257Z",
    "size": 314,
    "path": "../public/_nuxt/_...all_.a27f233e.js"
  },
  "/_nuxt/_id_.1990dedd.js": {
    "type": "application/javascript",
    "etag": "\"f80e-411l877MFLeSaxsago7w74JenvA\"",
    "mtime": "2023-09-18T18:51:04.296Z",
    "size": 63502,
    "path": "../public/_nuxt/_id_.1990dedd.js"
  },
  "/_nuxt/_id_.2d175b3f.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3a57-nScgifgND2r2o18y0MNhJlGKq9w\"",
    "mtime": "2023-09-18T18:51:04.226Z",
    "size": 14935,
    "path": "../public/_nuxt/_id_.2d175b3f.css"
  },
  "/_nuxt/_id_.2ecfa979.js": {
    "type": "application/javascript",
    "etag": "\"a437-T8PjqHub/hlnpmEU8HMrstl5B0s\"",
    "mtime": "2023-09-18T18:51:04.268Z",
    "size": 42039,
    "path": "../public/_nuxt/_id_.2ecfa979.js"
  },
  "/_nuxt/_id_.b84d9efa.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"208-qTZy9z2nn7CEhx8WEOhEFrBQmhU\"",
    "mtime": "2023-09-18T18:51:04.226Z",
    "size": 520,
    "path": "../public/_nuxt/_id_.b84d9efa.css"
  },
  "/_nuxt/_id_.f2b5a7cb.js": {
    "type": "application/javascript",
    "etag": "\"190-+Ty0FdoQufcMLRLaJUYw35UbeE0\"",
    "mtime": "2023-09-18T18:51:04.257Z",
    "size": 400,
    "path": "../public/_nuxt/_id_.f2b5a7cb.js"
  }
};

function readAsset (id) {
  const serverDir = dirname(fileURLToPath(globalThis._importMeta_.url));
  return promises.readFile(resolve(serverDir, assets[id].path))
}

const publicAssetBases = {"/_nuxt":{"maxAge":31536000}};

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return true
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = { gzip: ".gz", br: ".br" };
const _f4b49z = eventHandler((event) => {
  if (event.node.req.method && !METHODS.has(event.node.req.method)) {
    return;
  }
  let id = decodeURIComponent(
    withLeadingSlash(
      withoutTrailingSlash(parseURL(event.node.req.url).pathname)
    )
  );
  let asset;
  const encodingHeader = String(
    event.node.req.headers["accept-encoding"] || ""
  );
  const encodings = [
    ...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(),
    ""
  ];
  if (encodings.length > 1) {
    event.node.res.setHeader("Vary", "Accept-Encoding");
  }
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      event.node.res.removeHeader("cache-control");
      throw createError({
        statusMessage: "Cannot find static asset " + id,
        statusCode: 404
      });
    }
    return;
  }
  const ifNotMatch = event.node.req.headers["if-none-match"] === asset.etag;
  if (ifNotMatch) {
    if (!event.handled) {
      event.node.res.statusCode = 304;
      event.node.res.end();
    }
    return;
  }
  const ifModifiedSinceH = event.node.req.headers["if-modified-since"];
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    if (!event.handled) {
      event.node.res.statusCode = 304;
      event.node.res.end();
    }
    return;
  }
  if (asset.type && !event.node.res.getHeader("Content-Type")) {
    event.node.res.setHeader("Content-Type", asset.type);
  }
  if (asset.etag && !event.node.res.getHeader("ETag")) {
    event.node.res.setHeader("ETag", asset.etag);
  }
  if (asset.mtime && !event.node.res.getHeader("Last-Modified")) {
    event.node.res.setHeader("Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !event.node.res.getHeader("Content-Encoding")) {
    event.node.res.setHeader("Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !event.node.res.getHeader("Content-Length")) {
    event.node.res.setHeader("Content-Length", asset.size);
  }
  return readAsset(id);
});

const _lazy_nDA7lS = () => import('../handlers/renderer.mjs');

const handlers = [
  { route: '', handler: _f4b49z, lazy: false, middleware: true, method: undefined },
  { route: '/__nuxt_error', handler: _lazy_nDA7lS, lazy: true, middleware: false, method: undefined },
  { route: '/**', handler: _lazy_nDA7lS, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const h3App = createApp({
    debug: destr(false),
    onError: errorHandler
  });
  const router = createRouter$1();
  h3App.use(createRouteRulesHandler());
  const localCall = createCall(toNodeListener(h3App));
  const localFetch = createFetch(localCall, globalThis.fetch);
  const $fetch = createFetch$1({
    fetch: localFetch,
    Headers,
    defaults: { baseURL: config.app.baseURL }
  });
  globalThis.$fetch = $fetch;
  h3App.use(
    eventHandler((event) => {
      event.context.nitro = event.context.nitro || {};
      const envContext = event.node.req.__unenv__;
      if (envContext) {
        Object.assign(event.context, envContext);
      }
      event.fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent(event, req, init, {
        fetch: $fetch
      });
    })
  );
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(
        h.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router.handler);
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch
  };
  for (const plugin of plugins) {
    plugin(app);
  }
  return app;
}
const nitroApp = createNitroApp();
const useNitroApp = () => nitroApp;

function getGracefulShutdownConfig() {
  return {
    disabled: !!process.env.NITRO_SHUTDOWN_DISABLED,
    signals: (process.env.NITRO_SHUTDOWN_SIGNALS || "SIGTERM SIGINT").split(" ").map((s) => s.trim()),
    timeout: Number.parseInt(process.env.NITRO_SHUTDOWN_TIMEOUT, 10) || 3e4,
    forceExit: !process.env.NITRO_SHUTDOWN_NO_FORCE_EXIT
  };
}
function setupGracefulShutdown(listener, nitroApp) {
  const shutdownConfig = getGracefulShutdownConfig();
  if (shutdownConfig.disabled) {
    return;
  }
  gracefulShutdown(listener, {
    signals: shutdownConfig.signals.join(" "),
    timeout: shutdownConfig.timeout,
    forceExit: shutdownConfig.forceExit,
    onShutdown: async () => {
      await new Promise((resolve) => {
        const timeout = setTimeout(() => {
          console.warn("Graceful shutdown timeout, force exiting...");
          resolve();
        }, shutdownConfig.timeout);
        nitroApp.hooks.callHook("close").catch((err) => {
          console.error(err);
        }).finally(() => {
          clearTimeout(timeout);
          resolve();
        });
      });
    }
  });
}

const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const server = cert && key ? new Server({ key, cert }, toNodeListener(nitroApp.h3App)) : new Server$1(toNodeListener(nitroApp.h3App));
const port = destr(process.env.NITRO_PORT || process.env.PORT) || 3e3;
const host = process.env.NITRO_HOST || process.env.HOST;
const listener = server.listen(port, host, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  const protocol = cert && key ? "https" : "http";
  const addressInfo = listener.address();
  const baseURL = (useRuntimeConfig().app.baseURL || "").replace(/\/$/, "");
  const url = `${protocol}://${addressInfo.family === "IPv6" ? `[${addressInfo.address}]` : addressInfo.address}:${addressInfo.port}${baseURL}`;
  console.log(`Listening ${url}`);
});
trapUnhandledNodeErrors();
setupGracefulShutdown(listener, nitroApp);
const nodeServer = {};

export { useRuntimeConfig as a, getRouteRules as g, nodeServer as n, useNitroApp as u };
//# sourceMappingURL=node-server.mjs.map
