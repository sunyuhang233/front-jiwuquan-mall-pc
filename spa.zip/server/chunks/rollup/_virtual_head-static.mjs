const _virtual__headStatic = {"headTags":"<meta charset=\"utf-8\">\n<title>极物圈 - 开启你的购物社区之旅 ✨</title>\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<meta name=\"description\" content=\"极物圈是一个商城、社交平台，用户可以在这里钱包充值、查看、下单商品（虚拟），发布自己的帖子，评论别人的帖子。\">\n<meta name=\"apple-mobile-web-app-status-bar-style\" content=\"black-translucent\">\n<link rel=\"icon\" href=\"/logo.png\" sizes=\"any\">\n<link rel=\"apple-touch-icon\" href=\"/logo.png\">","bodyTags":"","bodyTagsOpen":"","htmlAttrs":"","bodyAttrs":""};

export { _virtual__headStatic as default };
//# sourceMappingURL=_virtual_head-static.mjs.map
