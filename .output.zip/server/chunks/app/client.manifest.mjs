const client_manifest = {
  "_index.a0c75657.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "index.98701813.css"
    ],
    "file": "index.a0c75657.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "index.98701813.css": {
    "file": "index.98701813.css",
    "resourceType": "style"
  },
  "_layout.1b28922a.js": {
    "resourceType": "script",
    "module": true,
    "file": "layout.1b28922a.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_nuxt-link.0ff02016.js": {
    "resourceType": "script",
    "module": true,
    "file": "nuxt-link.0ff02016.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "assets/images/logo/logo.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "logo.f2f3cfb9.png",
    "src": "assets/images/logo/logo.png"
  },
  "assets/images/logo/logo_dark.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "logo_dark.692df090.png",
    "src": "assets/images/logo/logo_dark.png"
  },
  "assets/images/logo/logo_txt.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "logo_txt.318d9294.png",
    "src": "assets/images/logo/logo_txt.png"
  },
  "index.css": {
    "resourceType": "style",
    "file": "index.98701813.css",
    "src": "index.css"
  },
  "layouts/default.css": {
    "resourceType": "style",
    "file": "default.a565d30c.css",
    "src": "layouts/default.css"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "logo.f2f3cfb9.png",
      "logo_dark.692df090.png"
    ],
    "css": [
      "default.a565d30c.css"
    ],
    "file": "default.42d572e3.js",
    "imports": [
      "_nuxt-link.0ff02016.js",
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js",
      "_index.a0c75657.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "default.a565d30c.css": {
    "file": "default.a565d30c.css",
    "resourceType": "style"
  },
  "logo.f2f3cfb9.png": {
    "file": "logo.f2f3cfb9.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "logo_dark.692df090.png": {
    "file": "logo_dark.692df090.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "middleware/router.ts": {
    "resourceType": "script",
    "module": true,
    "file": "router.539cb7cc.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/router.ts"
  },
  "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.dd29d79a.css",
    "src": "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "error-404.dd29d79a.css"
    ],
    "file": "error-404.295c5468.js",
    "imports": [
      "_nuxt-link.0ff02016.js",
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.dd29d79a.css": {
    "file": "error-404.dd29d79a.css",
    "resourceType": "style"
  },
  "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.26873dcc.css",
    "src": "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "error-500.26873dcc.css"
    ],
    "file": "error-500.bdff6379.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.26873dcc.css": {
    "file": "error-500.26873dcc.css",
    "resourceType": "style"
  },
  "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.4f27bab3.css",
    "src": "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "entry.4f27bab3.css"
    ],
    "dynamicImports": [
      "middleware/router.ts",
      "layouts/default.vue",
      "node_modules/.pnpm/workbox-window@6.6.0/node_modules/workbox-window/build/workbox-window.prod.es5.mjs",
      "virtual:nuxt:C:/Users/13296/Desktop/front_jiwuquan_pc/.nuxt/error-component.mjs"
    ],
    "file": "entry.1e2e194c.js",
    "isEntry": true,
    "src": "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
  },
  "entry.4f27bab3.css": {
    "file": "entry.4f27bab3.css",
    "resourceType": "style"
  },
  "node_modules/.pnpm/workbox-window@6.6.0/node_modules/workbox-window/build/workbox-window.prod.es5.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "workbox-window.prod.es5.08b2315b.js",
    "isDynamicEntry": true,
    "src": "node_modules/.pnpm/workbox-window@6.6.0/node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
  },
  "pages/[...all].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_...all_.ce9973ad.js",
    "imports": [
      "_nuxt-link.0ff02016.js",
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js",
      "_layout.1b28922a.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/[...all].vue"
  },
  "pages/community/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.72730df8.js",
    "imports": [
      "_layout.1b28922a.js",
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/index.vue"
  },
  "pages/event/detail.vue": {
    "resourceType": "script",
    "module": true,
    "file": "detail.cb6bb99e.js",
    "imports": [
      "_layout.1b28922a.js",
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/event/detail.vue"
  },
  "pages/goods/detail.vue": {
    "resourceType": "script",
    "module": true,
    "file": "detail.d4951d69.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/detail.vue"
  },
  "pages/goods/detail/[id].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_id_.667851a6.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/detail/[id].vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.1e0ef009.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "logo_txt.318d9294.png"
    ],
    "css": [
      "index.1e0ef009.css"
    ],
    "file": "index.151370d4.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js",
      "_index.a0c75657.js",
      "_nuxt-link.0ff02016.js",
      "_layout.1b28922a.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.1e0ef009.css": {
    "file": "index.1e0ef009.css",
    "resourceType": "style"
  },
  "logo_txt.318d9294.png": {
    "file": "logo_txt.318d9294.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "pages/my/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.63cb465b.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/my/index.vue"
  },
  "pages/my/info.vue": {
    "resourceType": "script",
    "module": true,
    "file": "info.5effc902.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/my/info.vue"
  },
  "pages/my/wallet.vue": {
    "resourceType": "script",
    "module": true,
    "file": "wallet.68a3bced.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/my/wallet.vue"
  },
  "pages/search/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.e89739a4.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/search/index.vue"
  },
  "virtual:nuxt:C:/Users/13296/Desktop/front_jiwuquan_pc/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "dynamicImports": [
      "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "error-component.d9df125e.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "virtual:nuxt:C:/Users/13296/Desktop/front_jiwuquan_pc/.nuxt/error-component.mjs"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
