const client_manifest = {
  "GoodsList.css": {
    "resourceType": "style",
    "file": "GoodsList.611c95b0.css",
    "src": "GoodsList.css"
  },
  "HeaderMenu.css": {
    "resourceType": "style",
    "file": "HeaderMenu.b54b77da.css",
    "src": "HeaderMenu.css"
  },
  "RightButtons.css": {
    "resourceType": "style",
    "file": "RightButtons.53f02f7e.css",
    "src": "RightButtons.css"
  },
  "ShopLine.css": {
    "resourceType": "style",
    "file": "ShopLine.a4e8b080.css",
    "src": "ShopLine.css"
  },
  "_Footer.332ce15a.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "kiwi_strong.cd9c4b1a.svg"
    ],
    "file": "Footer.332ce15a.js",
    "imports": [
      "_nuxt-link.3ab3094e.js",
      "_logo_txt.55cad505.js",
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "kiwi_strong.cd9c4b1a.svg": {
    "file": "kiwi_strong.cd9c4b1a.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "_GoodsList.bc6c182d.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "GoodsList.611c95b0.css",
      "image-viewer.bcc58336.css"
    ],
    "file": "GoodsList.bc6c182d.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_index.ae6339c5.js",
      "_useFetchUtil.5e101358.js",
      "_fetch.28613827.js",
      "_index.e746bb40.js"
    ]
  },
  "GoodsList.611c95b0.css": {
    "file": "GoodsList.611c95b0.css",
    "resourceType": "style"
  },
  "image-viewer.bcc58336.css": {
    "file": "image-viewer.bcc58336.css",
    "resourceType": "style"
  },
  "_HeaderMenu.09bf6b6f.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "HeaderMenu.b54b77da.css",
      "popover.1f4352fc.css"
    ],
    "file": "HeaderMenu.09bf6b6f.js",
    "imports": [
      "_nuxt-link.3ab3094e.js",
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_logo_dark.dc6c499e.js",
      "_progress.0647e4ab.js",
      "_card.03b4eb1f.js",
      "_index.db3a35b0.js",
      "_popper.62a55c63.js",
      "_overlay.efa6f5bb.js",
      "_useFetchUtil.5e101358.js"
    ]
  },
  "HeaderMenu.b54b77da.css": {
    "file": "HeaderMenu.b54b77da.css",
    "resourceType": "style"
  },
  "popover.1f4352fc.css": {
    "file": "popover.1f4352fc.css",
    "resourceType": "style"
  },
  "_RightButtons.4b2ee714.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "RightButtons.53f02f7e.css",
      "checkbox-group.987ef89c.css",
      "popover.1f4352fc.css"
    ],
    "file": "RightButtons.4b2ee714.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_checkbox.cc8670de.js",
      "_ShopLine.c0f49f20.js",
      "_scrollbar.92e36c75.js",
      "_index.db3a35b0.js",
      "_popper.62a55c63.js",
      "_overlay.efa6f5bb.js",
      "_currency.es.247f0395.js",
      "_index.e746bb40.js"
    ]
  },
  "RightButtons.53f02f7e.css": {
    "file": "RightButtons.53f02f7e.css",
    "resourceType": "style"
  },
  "checkbox-group.987ef89c.css": {
    "file": "checkbox-group.987ef89c.css",
    "resourceType": "style"
  },
  "_ShopLine.c0f49f20.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "ShopLine.a4e8b080.css",
      "image-viewer.bcc58336.css"
    ],
    "file": "ShopLine.c0f49f20.js",
    "imports": [
      "_index.ae6339c5.js",
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_select.269b1344.js",
      "_currency.es.247f0395.js",
      "_tag.fdc9c14d.js",
      "_scrollbar.92e36c75.js",
      "_popper.62a55c63.js",
      "_overlay.efa6f5bb.js",
      "_useFetchUtil.5e101358.js",
      "_sku.2e1f98ca.js"
    ]
  },
  "ShopLine.a4e8b080.css": {
    "file": "ShopLine.a4e8b080.css",
    "resourceType": "style"
  },
  "_card.03b4eb1f.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "card.55fdb7f4.css"
    ],
    "file": "card.03b4eb1f.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "card.55fdb7f4.css": {
    "file": "card.55fdb7f4.css",
    "resourceType": "style"
  },
  "_checkbox.cc8670de.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "checkbox.56c0bd3a.css"
    ],
    "file": "checkbox.cc8670de.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_isEqual.be958611.js"
    ]
  },
  "checkbox.56c0bd3a.css": {
    "file": "checkbox.56c0bd3a.css",
    "resourceType": "style"
  },
  "_cloneDeep.8f979bcf.js": {
    "resourceType": "script",
    "module": true,
    "file": "cloneDeep.8f979bcf.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_currency.es.247f0395.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "currency.f210222b.css"
    ],
    "file": "currency.es.247f0395.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "currency.f210222b.css": {
    "file": "currency.f210222b.css",
    "resourceType": "style"
  },
  "_debounce.11aa97dc.js": {
    "resourceType": "script",
    "module": true,
    "file": "debounce.11aa97dc.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_empty.cf228f48.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "empty.34c4f633.css"
    ],
    "file": "empty.cf228f48.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "empty.34c4f633.css": {
    "file": "empty.34c4f633.css",
    "resourceType": "style"
  },
  "_fetch.28613827.js": {
    "resourceType": "script",
    "module": true,
    "file": "fetch.28613827.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.6ee8a3dc.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.6ee8a3dc.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.779a86ea.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.779a86ea.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.8a7f6f6e.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.8a7f6f6e.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.ae6339c5.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.ae6339c5.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_debounce.11aa97dc.js",
      "_scroll.c6a222db.js"
    ],
    "isDynamicEntry": true
  },
  "_index.db3a35b0.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.db3a35b0.js",
    "imports": [
      "_popper.62a55c63.js",
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.e746bb40.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.e746bb40.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_index.ae6339c5.js",
      "_scroll.c6a222db.js"
    ]
  },
  "_isEqual.be958611.js": {
    "resourceType": "script",
    "module": true,
    "file": "isEqual.be958611.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_layout.61b59ca9.js": {
    "resourceType": "script",
    "module": true,
    "file": "layout.61b59ca9.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_logo_dark.dc6c499e.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "sun.bc0856fb.svg",
      "moon.768cb03d.svg",
      "logo.f2f3cfb9.png",
      "logo_dark.692df090.png"
    ],
    "css": [
      "logo_dark.beac4271.css",
      "popover.1f4352fc.css"
    ],
    "file": "logo_dark.dc6c499e.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_index.db3a35b0.js",
      "_popper.62a55c63.js"
    ]
  },
  "logo_dark.beac4271.css": {
    "file": "logo_dark.beac4271.css",
    "resourceType": "style"
  },
  "sun.bc0856fb.svg": {
    "file": "sun.bc0856fb.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "moon.768cb03d.svg": {
    "file": "moon.768cb03d.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "logo.f2f3cfb9.png": {
    "file": "logo.f2f3cfb9.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "logo_dark.692df090.png": {
    "file": "logo_dark.692df090.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "_logo_txt.55cad505.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "logo_txt.318d9294.png"
    ],
    "file": "logo_txt.55cad505.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "logo_txt.318d9294.png": {
    "file": "logo_txt.318d9294.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "_menu.cf435c62.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "menu.d3c11cc9.css"
    ],
    "file": "menu.cf435c62.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_overlay.efa6f5bb.js",
      "_index.779a86ea.js",
      "_popper.62a55c63.js",
      "_vnode.be46e981.js"
    ]
  },
  "menu.d3c11cc9.css": {
    "file": "menu.d3c11cc9.css",
    "resourceType": "style"
  },
  "_nuxt-link.3ab3094e.js": {
    "resourceType": "script",
    "module": true,
    "file": "nuxt-link.3ab3094e.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_overlay.efa6f5bb.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "overlay.7cc78350.css"
    ],
    "file": "overlay.efa6f5bb.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_vnode.be46e981.js",
      "_popper.62a55c63.js",
      "_validator.83171786.js",
      "_scroll.c6a222db.js"
    ]
  },
  "overlay.7cc78350.css": {
    "file": "overlay.7cc78350.css",
    "resourceType": "style"
  },
  "_popper.62a55c63.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "popper.0d433965.css"
    ],
    "file": "popper.62a55c63.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "popper.0d433965.css": {
    "file": "popper.0d433965.css",
    "resourceType": "style"
  },
  "_progress.0647e4ab.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "progress.115faf35.css"
    ],
    "file": "progress.0647e4ab.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_cloneDeep.8f979bcf.js",
      "_isEqual.be958611.js"
    ]
  },
  "progress.115faf35.css": {
    "file": "progress.115faf35.css",
    "resourceType": "style"
  },
  "_radio.bf92d297.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "radio.6aaf5789.css"
    ],
    "file": "radio.bf92d297.js",
    "imports": [
      "_tag.fdc9c14d.js",
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "radio.6aaf5789.css": {
    "file": "radio.6aaf5789.css",
    "resourceType": "style"
  },
  "_scroll.c6a222db.js": {
    "resourceType": "script",
    "module": true,
    "file": "scroll.c6a222db.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_scrollbar.92e36c75.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "scrollbar.77c43fec.css"
    ],
    "file": "scrollbar.92e36c75.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "scrollbar.77c43fec.css": {
    "file": "scrollbar.77c43fec.css",
    "resourceType": "style"
  },
  "_select.269b1344.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "select.d289ec57.css"
    ],
    "file": "select.269b1344.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_popper.62a55c63.js",
      "_scrollbar.92e36c75.js",
      "_tag.fdc9c14d.js",
      "_scroll.c6a222db.js",
      "_isEqual.be958611.js",
      "_debounce.11aa97dc.js",
      "_checkbox.cc8670de.js",
      "_validator.83171786.js"
    ]
  },
  "select.d289ec57.css": {
    "file": "select.d289ec57.css",
    "resourceType": "style"
  },
  "_sku.2e1f98ca.js": {
    "resourceType": "script",
    "module": true,
    "file": "sku.2e1f98ca.js",
    "imports": [
      "_fetch.28613827.js",
      "_useFetchUtil.5e101358.js",
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_tabs.2d301454.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "tabs.32104d62.css"
    ],
    "file": "tabs.2d301454.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_index.ae6339c5.js",
      "_scrollbar.92e36c75.js",
      "_vnode.be46e981.js",
      "_fetch.28613827.js",
      "_useFetchUtil.5e101358.js"
    ]
  },
  "tabs.32104d62.css": {
    "file": "tabs.32104d62.css",
    "resourceType": "style"
  },
  "_tag.fdc9c14d.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "tag.14763aef.css"
    ],
    "file": "tag.fdc9c14d.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "tag.14763aef.css": {
    "file": "tag.14763aef.css",
    "resourceType": "style"
  },
  "_text.166bed49.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "text.779bf283.css"
    ],
    "file": "text.166bed49.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "text.779bf283.css": {
    "file": "text.779bf283.css",
    "resourceType": "style"
  },
  "_useFetchUtil.5e101358.js": {
    "resourceType": "script",
    "module": true,
    "file": "useFetchUtil.5e101358.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_validator.83171786.js": {
    "resourceType": "script",
    "module": true,
    "file": "validator.83171786.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_vnode.be46e981.js": {
    "resourceType": "script",
    "module": true,
    "file": "vnode.be46e981.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "assets/images/icon/moon.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "moon.768cb03d.svg",
    "src": "assets/images/icon/moon.svg"
  },
  "assets/images/icon/sun.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "sun.bc0856fb.svg",
    "src": "assets/images/icon/sun.svg"
  },
  "assets/images/logo/kiwi_strong.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "kiwi_strong.cd9c4b1a.svg",
    "src": "assets/images/logo/kiwi_strong.svg"
  },
  "assets/images/logo/logo.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "logo.f2f3cfb9.png",
    "src": "assets/images/logo/logo.png"
  },
  "assets/images/logo/logo_dark.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "logo_dark.692df090.png",
    "src": "assets/images/logo/logo_dark.png"
  },
  "assets/images/logo/logo_txt.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "logo_txt.318d9294.png",
    "src": "assets/images/logo/logo_txt.png"
  },
  "card.css": {
    "resourceType": "style",
    "file": "card.55fdb7f4.css",
    "src": "card.css"
  },
  "checkbox-group.css": {
    "resourceType": "style",
    "file": "checkbox-group.987ef89c.css",
    "src": "checkbox-group.css"
  },
  "checkbox.css": {
    "resourceType": "style",
    "file": "checkbox.56c0bd3a.css",
    "src": "checkbox.css"
  },
  "currency.css": {
    "resourceType": "style",
    "file": "currency.f210222b.css",
    "src": "currency.css"
  },
  "empty.css": {
    "resourceType": "style",
    "file": "empty.34c4f633.css",
    "src": "empty.css"
  },
  "image-viewer.css": {
    "resourceType": "style",
    "file": "image-viewer.bcc58336.css",
    "src": "image-viewer.css"
  },
  "layouts/default.css": {
    "resourceType": "style",
    "file": "default.508a94cb.css",
    "src": "layouts/default.css"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "default.508a94cb.css",
      "tooltip.e3b0c442.css",
      "popover.1f4352fc.css",
      "swiper-vue.0990f71a.css",
      "image-viewer.bcc58336.css",
      "checkbox-group.987ef89c.css"
    ],
    "file": "default.2e64365b.js",
    "imports": [
      "_HeaderMenu.09bf6b6f.js",
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_menu.cf435c62.js",
      "_popper.62a55c63.js",
      "_index.6ee8a3dc.js",
      "_RightButtons.4b2ee714.js",
      "_Footer.332ce15a.js",
      "_nuxt-link.3ab3094e.js",
      "_logo_dark.dc6c499e.js",
      "_index.db3a35b0.js",
      "_progress.0647e4ab.js",
      "_cloneDeep.8f979bcf.js",
      "_isEqual.be958611.js",
      "_card.03b4eb1f.js",
      "_overlay.efa6f5bb.js",
      "_vnode.be46e981.js",
      "_validator.83171786.js",
      "_scroll.c6a222db.js",
      "_useFetchUtil.5e101358.js",
      "_index.779a86ea.js",
      "_checkbox.cc8670de.js",
      "_ShopLine.c0f49f20.js",
      "_index.ae6339c5.js",
      "_debounce.11aa97dc.js",
      "_select.269b1344.js",
      "_scrollbar.92e36c75.js",
      "_tag.fdc9c14d.js",
      "_currency.es.247f0395.js",
      "_sku.2e1f98ca.js",
      "_fetch.28613827.js",
      "_index.e746bb40.js",
      "_logo_txt.55cad505.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "default.508a94cb.css": {
    "file": "default.508a94cb.css",
    "resourceType": "style"
  },
  "tooltip.e3b0c442.css": {
    "file": "tooltip.e3b0c442.css",
    "resourceType": "style"
  },
  "swiper-vue.0990f71a.css": {
    "file": "swiper-vue.0990f71a.css",
    "resourceType": "style"
  },
  "layouts/error.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "swiper-vue.0990f71a.css"
    ],
    "file": "error.83bf4097.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_empty.cf228f48.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/error.vue"
  },
  "layouts/second.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "popover.1f4352fc.css",
      "image-viewer.bcc58336.css",
      "checkbox-group.987ef89c.css",
      "swiper-vue.0990f71a.css"
    ],
    "file": "second.a819f4ef.js",
    "imports": [
      "_HeaderMenu.09bf6b6f.js",
      "_RightButtons.4b2ee714.js",
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_Footer.332ce15a.js",
      "_nuxt-link.3ab3094e.js",
      "_logo_dark.dc6c499e.js",
      "_index.db3a35b0.js",
      "_popper.62a55c63.js",
      "_progress.0647e4ab.js",
      "_cloneDeep.8f979bcf.js",
      "_isEqual.be958611.js",
      "_card.03b4eb1f.js",
      "_overlay.efa6f5bb.js",
      "_vnode.be46e981.js",
      "_validator.83171786.js",
      "_scroll.c6a222db.js",
      "_useFetchUtil.5e101358.js",
      "_checkbox.cc8670de.js",
      "_ShopLine.c0f49f20.js",
      "_index.ae6339c5.js",
      "_debounce.11aa97dc.js",
      "_select.269b1344.js",
      "_scrollbar.92e36c75.js",
      "_tag.fdc9c14d.js",
      "_currency.es.247f0395.js",
      "_sku.2e1f98ca.js",
      "_fetch.28613827.js",
      "_index.e746bb40.js",
      "_logo_txt.55cad505.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/second.vue"
  },
  "layouts/user.css": {
    "resourceType": "style",
    "file": "user.dc14ee66.css",
    "src": "layouts/user.css"
  },
  "layouts/user.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "user.dc14ee66.css",
      "tooltip.e3b0c442.css",
      "popover.1f4352fc.css",
      "swiper-vue.0990f71a.css",
      "image-viewer.bcc58336.css",
      "checkbox-group.987ef89c.css"
    ],
    "file": "user.ab6c6d93.js",
    "imports": [
      "_nuxt-link.3ab3094e.js",
      "_logo_dark.dc6c499e.js",
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_menu.cf435c62.js",
      "_popper.62a55c63.js",
      "_index.6ee8a3dc.js",
      "_RightButtons.4b2ee714.js",
      "_index.db3a35b0.js",
      "_overlay.efa6f5bb.js",
      "_vnode.be46e981.js",
      "_validator.83171786.js",
      "_scroll.c6a222db.js",
      "_index.779a86ea.js",
      "_checkbox.cc8670de.js",
      "_isEqual.be958611.js",
      "_ShopLine.c0f49f20.js",
      "_index.ae6339c5.js",
      "_debounce.11aa97dc.js",
      "_select.269b1344.js",
      "_scrollbar.92e36c75.js",
      "_tag.fdc9c14d.js",
      "_currency.es.247f0395.js",
      "_useFetchUtil.5e101358.js",
      "_sku.2e1f98ca.js",
      "_fetch.28613827.js",
      "_index.e746bb40.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/user.vue"
  },
  "user.dc14ee66.css": {
    "file": "user.dc14ee66.css",
    "resourceType": "style"
  },
  "logo_dark.css": {
    "resourceType": "style",
    "file": "logo_dark.beac4271.css",
    "src": "logo_dark.css"
  },
  "menu.css": {
    "resourceType": "style",
    "file": "menu.d3c11cc9.css",
    "src": "menu.css"
  },
  "middleware/auth.ts": {
    "resourceType": "script",
    "module": true,
    "css": [
      "swiper-vue.0990f71a.css"
    ],
    "file": "auth.305dc0b4.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/auth.ts"
  },
  "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.dd29d79a.css",
    "src": "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "error-404.dd29d79a.css",
      "swiper-vue.0990f71a.css"
    ],
    "file": "error-404.4f720845.js",
    "imports": [
      "_nuxt-link.3ab3094e.js",
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.dd29d79a.css": {
    "file": "error-404.dd29d79a.css",
    "resourceType": "style"
  },
  "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.26873dcc.css",
    "src": "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "error-500.26873dcc.css",
      "swiper-vue.0990f71a.css"
    ],
    "file": "error-500.2eccdced.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.26873dcc.css": {
    "file": "error-500.26873dcc.css",
    "resourceType": "style"
  },
  "node_modules/.pnpm/element-plus@2.3.6_vue@3.3.4/node_modules/element-plus/es/components/dialog/index.mjs": {
    "resourceType": "script",
    "module": true,
    "css": [
      "swiper-vue.0990f71a.css"
    ],
    "file": "index.a3dd2e58.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_overlay.efa6f5bb.js",
      "_popper.62a55c63.js",
      "_vnode.be46e981.js",
      "_validator.83171786.js",
      "_scroll.c6a222db.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/.pnpm/element-plus@2.3.6_vue@3.3.4/node_modules/element-plus/es/components/dialog/index.mjs"
  },
  "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.8ab7011f.css",
    "src": "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "entry.8ab7011f.css",
      "swiper-vue.0990f71a.css"
    ],
    "dynamicImports": [
      "middleware/auth.ts",
      "layouts/default.vue",
      "layouts/error.vue",
      "layouts/second.vue",
      "layouts/user.vue",
      "node_modules/.pnpm/workbox-window@6.6.0/node_modules/workbox-window/build/workbox-window.prod.es5.mjs",
      "virtual:nuxt:C:/Users/13296/Desktop/front_jiwuquan_pc/.nuxt/error-component.mjs"
    ],
    "file": "entry.90c9e699.js",
    "isEntry": true,
    "src": "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
  },
  "entry.8ab7011f.css": {
    "file": "entry.8ab7011f.css",
    "resourceType": "style"
  },
  "node_modules/.pnpm/workbox-window@6.6.0/node_modules/workbox-window/build/workbox-window.prod.es5.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "workbox-window.prod.es5.08b2315b.js",
    "isDynamicEntry": true,
    "src": "node_modules/.pnpm/workbox-window@6.6.0/node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
  },
  "overlay.css": {
    "resourceType": "style",
    "file": "overlay.7cc78350.css",
    "src": "overlay.css"
  },
  "pages/[...all].vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "popover.1f4352fc.css",
      "swiper-vue.0990f71a.css"
    ],
    "file": "_...all_.ea105af0.js",
    "imports": [
      "_HeaderMenu.09bf6b6f.js",
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_empty.cf228f48.js",
      "_nuxt-link.3ab3094e.js",
      "_logo_dark.dc6c499e.js",
      "_index.db3a35b0.js",
      "_popper.62a55c63.js",
      "_progress.0647e4ab.js",
      "_cloneDeep.8f979bcf.js",
      "_isEqual.be958611.js",
      "_card.03b4eb1f.js",
      "_overlay.efa6f5bb.js",
      "_vnode.be46e981.js",
      "_validator.83171786.js",
      "_scroll.c6a222db.js",
      "_useFetchUtil.5e101358.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/[...all].vue"
  },
  "pages/community/index.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "swiper-vue.0990f71a.css"
    ],
    "file": "index.da675ac4.js",
    "imports": [
      "_layout.61b59ca9.js",
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/index.vue"
  },
  "pages/event/detail.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "swiper-vue.0990f71a.css"
    ],
    "file": "detail.249fd119.js",
    "imports": [
      "_layout.61b59ca9.js",
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/event/detail.vue"
  },
  "pages/goods/comments/[id].vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "swiper-vue.0990f71a.css"
    ],
    "file": "_id_.ce719140.js",
    "imports": [
      "_layout.61b59ca9.js",
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/comments/[id].vue"
  },
  "pages/goods/detail/[id].css": {
    "resourceType": "style",
    "file": "_id_.778b6cc3.css",
    "src": "pages/goods/detail/[id].css"
  },
  "pages/goods/detail/[id].vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "_id_.778b6cc3.css",
      "image-viewer.bcc58336.css",
      "popover.1f4352fc.css",
      "radio-group.3b9ac3ad.css",
      "swiper-vue.0990f71a.css"
    ],
    "file": "_id_.8d9daa74.js",
    "imports": [
      "_nuxt-link.3ab3094e.js",
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_tabs.2d301454.js",
      "_index.ae6339c5.js",
      "_useFetchUtil.5e101358.js",
      "_tag.fdc9c14d.js",
      "_popper.62a55c63.js",
      "_index.8a7f6f6e.js",
      "_currency.es.247f0395.js",
      "_card.03b4eb1f.js",
      "_text.166bed49.js",
      "_scrollbar.92e36c75.js",
      "_fetch.28613827.js",
      "_index.779a86ea.js",
      "_GoodsList.bc6c182d.js",
      "_layout.61b59ca9.js",
      "_sku.2e1f98ca.js",
      "_vnode.be46e981.js",
      "_debounce.11aa97dc.js",
      "_scroll.c6a222db.js",
      "_index.e746bb40.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/detail/[id].vue"
  },
  "_id_.778b6cc3.css": {
    "file": "_id_.778b6cc3.css",
    "resourceType": "style"
  },
  "radio-group.3b9ac3ad.css": {
    "file": "radio-group.3b9ac3ad.css",
    "resourceType": "style"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.79e258c8.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "index.79e258c8.css",
      "image-viewer.bcc58336.css",
      "popover.1f4352fc.css",
      "swiper-vue.0990f71a.css"
    ],
    "file": "index.578b28d1.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_tag.fdc9c14d.js",
      "_index.ae6339c5.js",
      "_useFetchUtil.5e101358.js",
      "_nuxt-link.3ab3094e.js",
      "_empty.cf228f48.js",
      "_scrollbar.92e36c75.js",
      "_index.db3a35b0.js",
      "_popper.62a55c63.js",
      "_index.6ee8a3dc.js",
      "_GoodsList.bc6c182d.js",
      "_logo_txt.55cad505.js",
      "_tabs.2d301454.js",
      "_fetch.28613827.js",
      "_layout.61b59ca9.js",
      "_debounce.11aa97dc.js",
      "_scroll.c6a222db.js",
      "_index.e746bb40.js",
      "_vnode.be46e981.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.79e258c8.css": {
    "file": "index.79e258c8.css",
    "resourceType": "style"
  },
  "pages/order/list.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "swiper-vue.0990f71a.css"
    ],
    "file": "list.9a2f4bce.js",
    "imports": [
      "_layout.61b59ca9.js",
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_sku.2e1f98ca.js",
      "_fetch.28613827.js",
      "_useFetchUtil.5e101358.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/list.vue"
  },
  "pages/order/pay.css": {
    "resourceType": "style",
    "file": "pay.24ef82b4.css",
    "src": "pages/order/pay.css"
  },
  "pages/order/pay.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "pay.24ef82b4.css",
      "radio-group.3b9ac3ad.css",
      "swiper-vue.0990f71a.css"
    ],
    "file": "pay.3729552f.js",
    "imports": [
      "_index.8a7f6f6e.js",
      "_radio.bf92d297.js",
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_layout.61b59ca9.js",
      "_sku.2e1f98ca.js",
      "_tag.fdc9c14d.js",
      "_fetch.28613827.js",
      "_useFetchUtil.5e101358.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/pay.vue"
  },
  "pay.24ef82b4.css": {
    "file": "pay.24ef82b4.css",
    "resourceType": "style"
  },
  "pages/search/index.css": {
    "resourceType": "style",
    "file": "index.668a4412.css",
    "src": "pages/search/index.css"
  },
  "pages/search/index.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "index.668a4412.css",
      "swiper-vue.0990f71a.css",
      "image-viewer.bcc58336.css"
    ],
    "file": "index.a786e174.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_checkbox.cc8670de.js",
      "_select.269b1344.js",
      "_GoodsList.bc6c182d.js",
      "_layout.61b59ca9.js",
      "_tag.fdc9c14d.js",
      "_scrollbar.92e36c75.js",
      "_popper.62a55c63.js",
      "_isEqual.be958611.js",
      "_scroll.c6a222db.js",
      "_debounce.11aa97dc.js",
      "_validator.83171786.js",
      "_index.ae6339c5.js",
      "_useFetchUtil.5e101358.js",
      "_fetch.28613827.js",
      "_index.e746bb40.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/search/index.vue"
  },
  "index.668a4412.css": {
    "file": "index.668a4412.css",
    "resourceType": "style"
  },
  "pages/shopcart/index.css": {
    "resourceType": "style",
    "file": "index.3b7d61aa.css",
    "src": "pages/shopcart/index.css"
  },
  "pages/shopcart/index.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "index.3b7d61aa.css",
      "checkbox-group.987ef89c.css",
      "image-viewer.bcc58336.css",
      "swiper-vue.0990f71a.css"
    ],
    "file": "index.474719b3.js",
    "imports": [
      "_checkbox.cc8670de.js",
      "_ShopLine.c0f49f20.js",
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_layout.61b59ca9.js",
      "_overlay.efa6f5bb.js",
      "_currency.es.247f0395.js",
      "_index.e746bb40.js",
      "_isEqual.be958611.js",
      "_index.ae6339c5.js",
      "_debounce.11aa97dc.js",
      "_scroll.c6a222db.js",
      "_select.269b1344.js",
      "_popper.62a55c63.js",
      "_scrollbar.92e36c75.js",
      "_tag.fdc9c14d.js",
      "_validator.83171786.js",
      "_useFetchUtil.5e101358.js",
      "_sku.2e1f98ca.js",
      "_fetch.28613827.js",
      "_vnode.be46e981.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/shopcart/index.vue"
  },
  "index.3b7d61aa.css": {
    "file": "index.3b7d61aa.css",
    "resourceType": "style"
  },
  "pages/user/address.css": {
    "resourceType": "style",
    "file": "address.41fe1ebc.css",
    "src": "pages/user/address.css"
  },
  "pages/user/address.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "address.41fe1ebc.css",
      "checkbox-group.987ef89c.css",
      "swiper-vue.0990f71a.css"
    ],
    "dynamicImports": [
      "node_modules/.pnpm/element-plus@2.3.6_vue@3.3.4/node_modules/element-plus/es/components/dialog/index.mjs"
    ],
    "file": "address.9eee68e7.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_scrollbar.92e36c75.js",
      "_checkbox.cc8670de.js",
      "_index.8a7f6f6e.js",
      "_text.166bed49.js",
      "_isEqual.be958611.js",
      "_overlay.efa6f5bb.js",
      "_scroll.c6a222db.js",
      "_cloneDeep.8f979bcf.js",
      "_popper.62a55c63.js",
      "_tag.fdc9c14d.js",
      "_debounce.11aa97dc.js",
      "_radio.bf92d297.js",
      "_layout.61b59ca9.js",
      "_vnode.be46e981.js",
      "_validator.83171786.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/address.vue"
  },
  "address.41fe1ebc.css": {
    "file": "address.41fe1ebc.css",
    "resourceType": "style"
  },
  "pages/user/info.css": {
    "resourceType": "style",
    "file": "info.865a1c46.css",
    "src": "pages/user/info.css"
  },
  "pages/user/info.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "info.865a1c46.css",
      "image-viewer.bcc58336.css",
      "tooltip.e3b0c442.css",
      "swiper-vue.0990f71a.css"
    ],
    "dynamicImports": [
      "_index.ae6339c5.js"
    ],
    "file": "info.b21221a6.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js",
      "_useFetchUtil.5e101358.js",
      "_index.6ee8a3dc.js",
      "_progress.0647e4ab.js",
      "_popper.62a55c63.js",
      "_layout.61b59ca9.js",
      "_cloneDeep.8f979bcf.js",
      "_isEqual.be958611.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/info.vue"
  },
  "info.865a1c46.css": {
    "file": "info.865a1c46.css",
    "resourceType": "style"
  },
  "pages/user/safe.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "swiper-vue.0990f71a.css"
    ],
    "file": "safe.9cc8157d.js",
    "imports": [
      "_layout.61b59ca9.js",
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/safe.vue"
  },
  "pages/user/wallet.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "swiper-vue.0990f71a.css"
    ],
    "file": "wallet.48002095.js",
    "imports": [
      "_layout.61b59ca9.js",
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/wallet.vue"
  },
  "popover.css": {
    "resourceType": "style",
    "file": "popover.1f4352fc.css",
    "src": "popover.css"
  },
  "popper.css": {
    "resourceType": "style",
    "file": "popper.0d433965.css",
    "src": "popper.css"
  },
  "progress.css": {
    "resourceType": "style",
    "file": "progress.115faf35.css",
    "src": "progress.css"
  },
  "radio-group.css": {
    "resourceType": "style",
    "file": "radio-group.3b9ac3ad.css",
    "src": "radio-group.css"
  },
  "radio.css": {
    "resourceType": "style",
    "file": "radio.6aaf5789.css",
    "src": "radio.css"
  },
  "scrollbar.css": {
    "resourceType": "style",
    "file": "scrollbar.77c43fec.css",
    "src": "scrollbar.css"
  },
  "select.css": {
    "resourceType": "style",
    "file": "select.d289ec57.css",
    "src": "select.css"
  },
  "swiper-vue.css": {
    "resourceType": "style",
    "file": "swiper-vue.0990f71a.css",
    "src": "swiper-vue.css"
  },
  "tabs.css": {
    "resourceType": "style",
    "file": "tabs.32104d62.css",
    "src": "tabs.css"
  },
  "tag.css": {
    "resourceType": "style",
    "file": "tag.14763aef.css",
    "src": "tag.css"
  },
  "text.css": {
    "resourceType": "style",
    "file": "text.779bf283.css",
    "src": "text.css"
  },
  "tooltip.css": {
    "resourceType": "style",
    "file": "tooltip.e3b0c442.css",
    "src": "tooltip.css"
  },
  "virtual:nuxt:C:/Users/13296/Desktop/front_jiwuquan_pc/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "css": [
      "swiper-vue.0990f71a.css"
    ],
    "dynamicImports": [
      "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "error-component.588cf47e.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.3_@types+node@20.3.1_eslint@8.43.0_rollup@2.79.1_sass@1.63.4_typescript@5.1.3_vue-tsc@1.8.1/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "virtual:nuxt:C:/Users/13296/Desktop/front_jiwuquan_pc/.nuxt/error-component.mjs"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
