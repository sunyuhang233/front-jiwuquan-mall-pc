const client_manifest = {
  "_index.9b5fbbbf.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "index.0d433965.css"
    ],
    "file": "index.9b5fbbbf.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "index.0d433965.css": {
    "file": "index.0d433965.css",
    "resourceType": "style"
  },
  "_layout.8e31c658.js": {
    "resourceType": "script",
    "module": true,
    "file": "layout.8e31c658.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_nuxt-link.aa2957db.js": {
    "resourceType": "script",
    "module": true,
    "file": "nuxt-link.aa2957db.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "assets/images/logo/logo.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "logo.f2f3cfb9.png",
    "src": "assets/images/logo/logo.png"
  },
  "assets/images/logo/logo_dark.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "logo_dark.692df090.png",
    "src": "assets/images/logo/logo_dark.png"
  },
  "assets/images/logo/logo_txt.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "logo_txt.318d9294.png",
    "src": "assets/images/logo/logo_txt.png"
  },
  "index.css": {
    "resourceType": "style",
    "file": "index.0d433965.css",
    "src": "index.css"
  },
  "layouts/default.css": {
    "resourceType": "style",
    "file": "default.a7d1d879.css",
    "src": "layouts/default.css"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "logo.f2f3cfb9.png",
      "logo_dark.692df090.png"
    ],
    "css": [
      "default.a7d1d879.css"
    ],
    "file": "default.338c15fa.js",
    "imports": [
      "_nuxt-link.aa2957db.js",
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js",
      "_index.9b5fbbbf.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "default.a7d1d879.css": {
    "file": "default.a7d1d879.css",
    "resourceType": "style"
  },
  "logo.f2f3cfb9.png": {
    "file": "logo.f2f3cfb9.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "logo_dark.692df090.png": {
    "file": "logo_dark.692df090.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "middleware/router.ts": {
    "resourceType": "script",
    "module": true,
    "file": "router.1f9d8c6f.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/router.ts"
  },
  "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.dd29d79a.css",
    "src": "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "error-404.dd29d79a.css"
    ],
    "file": "error-404.e411fffd.js",
    "imports": [
      "_nuxt-link.aa2957db.js",
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.dd29d79a.css": {
    "file": "error-404.dd29d79a.css",
    "resourceType": "style"
  },
  "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.26873dcc.css",
    "src": "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "error-500.26873dcc.css"
    ],
    "file": "error-500.348a0492.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.26873dcc.css": {
    "file": "error-500.26873dcc.css",
    "resourceType": "style"
  },
  "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.2698c6f5.css",
    "src": "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "entry.2698c6f5.css"
    ],
    "dynamicImports": [
      "middleware/router.ts",
      "layouts/default.vue",
      "node_modules/.pnpm/workbox-window@6.6.0/node_modules/workbox-window/build/workbox-window.prod.es5.mjs",
      "virtual:nuxt:C:/Users/13296/Desktop/front_jiwuquan_pc/.nuxt/error-component.mjs"
    ],
    "file": "entry.556ed651.js",
    "isEntry": true,
    "src": "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
  },
  "entry.2698c6f5.css": {
    "file": "entry.2698c6f5.css",
    "resourceType": "style"
  },
  "node_modules/.pnpm/workbox-window@6.6.0/node_modules/workbox-window/build/workbox-window.prod.es5.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "workbox-window.prod.es5.08b2315b.js",
    "isDynamicEntry": true,
    "src": "node_modules/.pnpm/workbox-window@6.6.0/node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
  },
  "pages/[...all].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_...all_.a99b928e.js",
    "imports": [
      "_nuxt-link.aa2957db.js",
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js",
      "_layout.8e31c658.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/[...all].vue"
  },
  "pages/community/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.68820ab8.js",
    "imports": [
      "_layout.8e31c658.js",
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/index.vue"
  },
  "pages/goods/detail.vue": {
    "resourceType": "script",
    "module": true,
    "file": "detail.38b7b77e.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/detail.vue"
  },
  "pages/goods/detail/[id].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_id_.8641afd8.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/detail/[id].vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.4032eb7d.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "logo_txt.318d9294.png"
    ],
    "css": [
      "index.4032eb7d.css"
    ],
    "file": "index.57d13358.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js",
      "_index.9b5fbbbf.js",
      "_nuxt-link.aa2957db.js",
      "_layout.8e31c658.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.4032eb7d.css": {
    "file": "index.4032eb7d.css",
    "resourceType": "style"
  },
  "logo_txt.318d9294.png": {
    "file": "logo_txt.318d9294.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "pages/search.vue/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.b2505f87.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/search.vue/index.vue"
  },
  "virtual:nuxt:C:/Users/13296/Desktop/front_jiwuquan_pc/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "dynamicImports": [
      "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "error-component.22d02402.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.5.0_@types+node@20.3.1_eslint@8.41.0_rollup@2.79.1_sass@1.62.1_typescript@5.0.4_vue-tsc@1.6.5/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "virtual:nuxt:C:/Users/13296/Desktop/front_jiwuquan_pc/.nuxt/error-component.mjs"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
