import { _ as __nuxt_component_0 } from './HeaderMenu-a788779c.mjs';
import { E as ElEmpty } from './index-a3ed7626.mjs';
import { _ as _export_sfc, u as useRouter, E as ElButton } from '../server.mjs';
import { mergeProps, withCtx, unref, createTextVNode, createVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import './nuxt-link-1d0a99ed.mjs';
import 'ufo';
import './logo_dark-b7cf3e36.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import './index-5453207f.mjs';
import 'lodash-unified';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@vue/shared';
import 'cookie-es';
import 'pinia-plugin-persistedstate';
import 'gsap';
import 'nprogress';
import '@kangc/v-md-editor';
import 'async-validator';
import '@ctrl/tinycolor';

const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_MenuHeaderMenu = __nuxt_component_0;
  const _component_ElEmpty = ElEmpty;
  const _component_ElButton = ElButton;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "error-page" }, _attrs))}>`);
  _push(ssrRenderComponent(_component_MenuHeaderMenu, null, null, _parent));
  _push(`<div flex-row-c-c mx-a>`);
  _push(ssrRenderComponent(_component_ElEmpty, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<div flex-row-c-c flex-col${_scopeId}><h3 mb-5${_scopeId}>404, \u9875\u9762\u627E\u4E0D\u5230</h3>`);
        _push2(ssrRenderComponent(_component_ElButton, {
          onClick: ($event) => ("useRouter" in _ctx ? _ctx.useRouter : unref(useRouter))().back(),
          plain: "",
          type: "primary"
        }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(` \u8FD4\u56DE `);
            } else {
              return [
                createTextVNode(" \u8FD4\u56DE ")
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(`</div>`);
      } else {
        return [
          createVNode("div", {
            "flex-row-c-c": "",
            "flex-col": ""
          }, [
            createVNode("h3", { "mb-5": "" }, "404, \u9875\u9762\u627E\u4E0D\u5230"),
            createVNode(_component_ElButton, {
              onClick: ($event) => ("useRouter" in _ctx ? _ctx.useRouter : unref(useRouter))().back(),
              plain: "",
              type: "primary"
            }, {
              default: withCtx(() => [
                createTextVNode(" \u8FD4\u56DE ")
              ]),
              _: 1
            }, 8, ["onClick"])
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/[...all].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const ____all_ = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { ____all_ as default };
//# sourceMappingURL=_...all_-851f299c.mjs.map
