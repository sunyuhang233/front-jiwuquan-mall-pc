import { _ as __nuxt_component_0 } from './layout-9cd450dc.mjs';
import { d as buildProps, f as useNamespace, H as picture_filled_default, w as withInstall, k as withNoopInstall, b as useHead, g as _export_sfc$1, I as useNuxtApp, B as useUserStore, S as StatusCode, J as isTrue, u as useRouter, x as __nuxt_component_1$2, y as picture_default, E as ElButton, _ as _export_sfc } from '../server.mjs';
import { defineComponent, openBlock, createElementBlock, normalizeClass, unref, createBlock, createCommentVNode, toRef, mergeProps, Fragment, renderList, renderSlot, createVNode, normalizeProps, useSSRContext, withCtx, ref, watch, reactive, computed, withAsyncContext, createTextVNode, toDisplayString, isRef } from 'vue';
import { u as useStorage } from './index-e2921ef2.mjs';
import { ssrRenderComponent, ssrRenderAttrs, ssrRenderStyle, ssrRenderAttr, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import { B as BaseUrlImg, b as BaseUrl } from './useFetchUtil-5309feca.mjs';
import { _ as _imports_0 } from './logo_txt-7733b5d1.mjs';
import { d as getGoodsCategoryList, E as ElCarousel, a as ElCarouselItem, b as ElTabs, c as ElTabPane } from './tab-pane-26e79501.mjs';
import { ElImage } from './index-5245db1b.mjs';
import { u as useFetch } from './fetch-da5935af.mjs';
import { b as getGoodsListByPage, _ as __nuxt_component_6 } from './GoodsList-c08a2c38.mjs';
import { E as ElScrollbar } from './index-8520e97d.mjs';
import 'vue-router';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'destr';
import 'h3';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'ufo';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import 'pinia-plugin-persistedstate';
import 'gsap';
import 'lodash-unified';
import 'nprogress';
import '@kangc/v-md-editor';
import 'async-validator';
import '@ctrl/tinycolor';
import 'defu';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'klona';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import './index-968ae5e9.mjs';
import './vnode-f2ede823.mjs';
import './index-5453207f.mjs';

const useThrottleRender = (loading, throttle = 0) => {
  if (throttle === 0)
    return loading;
  const throttled = ref(false);
  let timeoutHandle = 0;
  const dispatchThrottling = () => {
    if (timeoutHandle) {
      clearTimeout(timeoutHandle);
    }
    timeoutHandle = window.setTimeout(() => {
      throttled.value = loading.value;
    }, throttle);
  };
  watch(() => loading.value, (val) => {
    if (val) {
      dispatchThrottling();
    } else {
      throttled.value = val;
    }
  });
  return throttled;
};
const skeletonProps = buildProps({
  animated: {
    type: Boolean,
    default: false
  },
  count: {
    type: Number,
    default: 1
  },
  rows: {
    type: Number,
    default: 3
  },
  loading: {
    type: Boolean,
    default: true
  },
  throttle: {
    type: Number
  }
});
const skeletonItemProps = buildProps({
  variant: {
    type: String,
    values: [
      "circle",
      "rect",
      "h1",
      "h3",
      "text",
      "caption",
      "p",
      "image",
      "button"
    ],
    default: "text"
  }
});
const __default__$1 = /* @__PURE__ */ defineComponent({
  name: "ElSkeletonItem"
});
const _sfc_main$8 = /* @__PURE__ */ defineComponent({
  ...__default__$1,
  props: skeletonItemProps,
  setup(__props) {
    const ns = useNamespace("skeleton");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass([unref(ns).e("item"), unref(ns).e(_ctx.variant)])
      }, [
        _ctx.variant === "image" ? (openBlock(), createBlock(unref(picture_filled_default), { key: 0 })) : createCommentVNode("v-if", true)
      ], 2);
    };
  }
});
var SkeletonItem = /* @__PURE__ */ _export_sfc$1(_sfc_main$8, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/skeleton/src/skeleton-item.vue"]]);
const __default__ = /* @__PURE__ */ defineComponent({
  name: "ElSkeleton"
});
const _sfc_main$7 = /* @__PURE__ */ defineComponent({
  ...__default__,
  props: skeletonProps,
  setup(__props, { expose }) {
    const props = __props;
    const ns = useNamespace("skeleton");
    const uiLoading = useThrottleRender(toRef(props, "loading"), props.throttle);
    expose({
      uiLoading
    });
    return (_ctx, _cache) => {
      return unref(uiLoading) ? (openBlock(), createElementBlock("div", mergeProps({
        key: 0,
        class: [unref(ns).b(), unref(ns).is("animated", _ctx.animated)]
      }, _ctx.$attrs), [
        (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.count, (i) => {
          return openBlock(), createElementBlock(Fragment, { key: i }, [
            _ctx.loading ? renderSlot(_ctx.$slots, "template", { key: i }, () => [
              createVNode(SkeletonItem, {
                class: normalizeClass(unref(ns).is("first")),
                variant: "p"
              }, null, 8, ["class"]),
              (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.rows, (item) => {
                return openBlock(), createBlock(SkeletonItem, {
                  key: item,
                  class: normalizeClass([
                    unref(ns).e("paragraph"),
                    unref(ns).is("last", item === _ctx.rows && _ctx.rows > 1)
                  ]),
                  variant: "p"
                }, null, 8, ["class"]);
              }), 128))
            ]) : createCommentVNode("v-if", true)
          ], 64);
        }), 128))
      ], 16)) : renderSlot(_ctx.$slots, "default", normalizeProps(mergeProps({ key: 1 }, _ctx.$attrs)));
    };
  }
});
var Skeleton = /* @__PURE__ */ _export_sfc$1(_sfc_main$7, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/skeleton/src/skeleton.vue"]]);
const ElSkeleton = withInstall(Skeleton, {
  SkeletonItem
});
const ElSkeletonItem = withNoopInstall(SkeletonItem);
const _sfc_main$6 = /* @__PURE__ */ defineComponent({
  __name: "Search",
  __ssrInlineRender: true,
  setup(__props) {
    ref("");
    ref(false);
    ref(false);
    let searchPage = reactive({
      records: [],
      total: 0,
      pages: 0,
      size: 0,
      current: 0
    });
    const searchPageList = reactive([]);
    ref(false);
    ref(1);
    ref(6);
    computed(() => searchPage.total > 0 && searchPageList.length === searchPage.total);
    useStorage("jiwu_index_search", []);
    const app = useNuxtApp();
    app.hook("app:mounted", () => {
      ref("searchInpRef");
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ClientOnly = __nuxt_component_1$2;
      _push(ssrRenderComponent(_component_ClientOnly, _attrs, {}, _parent));
    };
  }
});
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Index/Search.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["__scopeId", "data-v-0c950c78"]]);
const _sfc_main$5 = /* @__PURE__ */ defineComponent({
  __name: "TopMenu",
  __ssrInlineRender: true,
  setup(__props) {
    useUserStore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ClientOnly = __nuxt_component_1$2;
      const _component_IndexSearch = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "top",
        "overflow-hidden": "",
        "flex-row-bt-c": "",
        "flex-col": "",
        "md:flex-row": ""
      }, _attrs))}><img absolute bg-color-indigo-6 z-0 flex-2 select-none style="${ssrRenderStyle({ "user-select": "none" })}"${ssrRenderAttr("src", _imports_0)} filter-blur-30 w-240px alt="\u6781\u7269\u5708 logo"><div ml-10 px-5 class="title animate__animated animate__fadeInDown" mt-3 mb-8><p text-lg py-2 tracking-1 opacity-80>`);
      _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
      _push(`</p><h2 text-2xl tracking-1>\u6B22\u8FCE\u6765\u5230<span class="mark3 animate"> \u6781\u7269\u5708\u793E\u533A </span>\u{1F389}</h2></div><div class="animate__animated animate__pulse" animate-delay-500 p-2>`);
      _push(ssrRenderComponent(_component_IndexSearch, null, null, _parent));
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Index/TopMenu.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
function getEventsLists() {
  return useFetch(() => BaseUrl + "/event/list", "$xvkmTfuJqN");
}
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "Swiper",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const eventList = reactive([]);
    const isLoading = ref(true);
    const { data, refresh } = ([__temp, __restore] = withAsyncContext(() => getEventsLists()), __temp = await __temp, __restore(), __temp);
    if (data.value && data.value.code === StatusCode.SUCCESS) {
      const res = data.value.data.sort((a, b) => b.status - a.status);
      res.forEach((p) => {
        eventList.push(p);
      });
      if (eventList.length === data.value.data.length) {
        setTimeout(() => {
          isLoading.value = false;
        }, 30);
      }
    } else {
      setTimeout(() => {
        refresh();
      }, 30);
    }
    const toEventDetailView = (eid) => {
      useRouter().push({
        path: "/event/detail",
        query: {
          eid
        }
      });
    };
    const getEndDay = computed(() => {
      return (a, b) => {
        let newDate = (/* @__PURE__ */ new Date()).getTime();
        let start = Date.parse(a);
        let end = Date.parse(b);
        if (start > newDate) {
          return 0;
        }
        if (end < newDate) {
          return -1;
        }
        return +((end - newDate) / (1 * 24 * 60 * 60 * 1e3)).toFixed(0);
      };
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_el_carousel = ElCarousel;
      const _component_el_skeleton = ElSkeleton;
      const _component_el_skeleton_item = ElSkeletonItem;
      const _component_el_carousel_item = ElCarouselItem;
      const _component_ClientOnly = __nuxt_component_1$2;
      const _component_el_image = ElImage;
      const _component_ElIconPicture = picture_default;
      const _component_el_button = ElButton;
      _push(ssrRenderComponent(_component_el_carousel, mergeProps({
        "rounded-6px": "",
        "cursor-pointer": "",
        interval: 6e3,
        arrow: "hover",
        "my-4": "",
        "md:my-0": "",
        "mx-auto": "",
        "md:mx-none": "",
        "w-250px": "",
        "md:w": "620px",
        "h-280px": "",
        "md:h": "420px",
        height: "100%",
        class: "w-4/5 swpier",
        trigger: "click"
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_el_skeleton, {
              animated: "",
              loading: unref(isLoading),
              class: "ske"
            }, {
              template: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_el_skeleton_item, {
                    "p-4": "",
                    variant: "image",
                    class: "sk-imgs",
                    "p-2": ""
                  }, null, _parent3, _scopeId2));
                  _push3(`<div p-4 flex-col style="${ssrRenderStyle({ "height": "100%" })}" justify-around data-v-1d8e9e43${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_el_skeleton_item, {
                    variant: "p",
                    "mb-1": "",
                    style: { "width": "70%" }
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_el_skeleton_item, {
                    variant: "p",
                    "mb-1": "",
                    style: { "width": "100%" }
                  }, null, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode(_component_el_skeleton_item, {
                      "p-4": "",
                      variant: "image",
                      class: "sk-imgs",
                      "p-2": ""
                    }),
                    createVNode("div", {
                      "p-4": "",
                      "flex-col": "",
                      style: { "height": "100%" },
                      "justify-around": ""
                    }, [
                      createVNode(_component_el_skeleton_item, {
                        variant: "p",
                        "mb-1": "",
                        style: { "width": "70%" }
                      }),
                      createVNode(_component_el_skeleton_item, {
                        variant: "p",
                        "mb-1": "",
                        style: { "width": "100%" }
                      })
                    ])
                  ];
                }
              }),
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<!--[-->`);
                  ssrRenderList(unref(eventList), (p) => {
                    _push3(ssrRenderComponent(_component_el_carousel_item, {
                      onClick: ($event) => toEventDetailView(p.id),
                      key: p.id,
                      class: "swiper-item"
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(ssrRenderComponent(_component_ClientOnly, null, {}, _parent4, _scopeId3));
                          _push4(`<section class="tip" px-5 py-3 tracking-0.2em text-xs line-height-none md:text-1em md:line-height-normal flex flex-col justify-around data-v-1d8e9e43${_scopeId3}><h3 class="title" data-v-1d8e9e43${_scopeId3}>${ssrInterpolate(p.title)}</h3>`);
                          if (unref(getEndDay)(p.startTime, p.endTime) < 0) {
                            _push4(`<p opacity-80 style="${ssrRenderStyle({ "text-decoration": "line-through" })}" data-v-1d8e9e43${_scopeId3}> \u6D3B\u52A8\u5DF2\u7ECF\u7ED3\u675F </p>`);
                          } else {
                            _push4(`<!---->`);
                          }
                          if (unref(getEndDay)(p.startTime, p.endTime) === 0) {
                            _push4(`<p opacity-80 style="${ssrRenderStyle({ "color": "var(--el-color-success)" })}" data-v-1d8e9e43${_scopeId3}> \u6D3B\u52A8\u5373\u5C06\u5F00\u59CB </p>`);
                          } else if (unref(getEndDay)(p.startTime, p.endTime) > 0) {
                            _push4(`<p opacity-80 data-v-1d8e9e43${_scopeId3}> \u8DDD\u79BB\u7ED3\u675F\u8FD8\u6709\uFF1A<strong text-lg style="${ssrRenderStyle({ "color": "var(--el-color-error)" })}" data-v-1d8e9e43${_scopeId3}>${ssrInterpolate(unref(getEndDay)(p.startTime, p.endTime))}</strong> \u5929 `);
                            _push4(ssrRenderComponent(_component_el_button, {
                              plain: "",
                              "cursor-pointer": "",
                              "float-right": "",
                              "opacity-60": ""
                            }, {
                              default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                                if (_push5) {
                                  _push5(`\u66F4\u591A`);
                                } else {
                                  return [
                                    createTextVNode("\u66F4\u591A")
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent4, _scopeId3));
                            _push4(`</p>`);
                          } else {
                            _push4(`<!---->`);
                          }
                          _push4(`</section>`);
                        } else {
                          return [
                            createVNode(_component_ClientOnly, null, {
                              default: withCtx(() => [
                                createVNode(_component_el_image, {
                                  class: [!unref(isLoading) ? " animate__blurIn" : "", "e-img"],
                                  src: unref(BaseUrlImg) + p.images,
                                  alt: p.details,
                                  style: { "width": "100%", "height": "100%" },
                                  fit: "fill"
                                }, {
                                  error: withCtx(() => [
                                    createVNode("div", {
                                      class: "image-slot",
                                      "flex-row-c-c": ""
                                    }, [
                                      createVNode(_component_ElIconPicture, {
                                        "w-sm": "",
                                        "p-30": "",
                                        "pt-20": "",
                                        "opacity-80": "",
                                        "flex-row-c-c": ""
                                      })
                                    ])
                                  ]),
                                  _: 2
                                }, 1032, ["class", "src", "alt"])
                              ]),
                              _: 2
                            }, 1024),
                            createVNode("section", {
                              class: "tip",
                              "px-5": "",
                              "py-3": "",
                              "tracking-0.2em": "",
                              "text-xs": "",
                              "line-height-none": "",
                              "md:text-1em": "",
                              "md:line-height-normal": "",
                              flex: "",
                              "flex-col": "",
                              "justify-around": ""
                            }, [
                              createVNode("h3", { class: "title" }, toDisplayString(p.title), 1),
                              unref(getEndDay)(p.startTime, p.endTime) < 0 ? (openBlock(), createBlock("p", {
                                key: 0,
                                "opacity-80": "",
                                style: { "text-decoration": "line-through" }
                              }, " \u6D3B\u52A8\u5DF2\u7ECF\u7ED3\u675F ")) : createCommentVNode("", true),
                              unref(getEndDay)(p.startTime, p.endTime) === 0 ? (openBlock(), createBlock("p", {
                                key: 1,
                                "opacity-80": "",
                                style: { "color": "var(--el-color-success)" }
                              }, " \u6D3B\u52A8\u5373\u5C06\u5F00\u59CB ")) : unref(getEndDay)(p.startTime, p.endTime) > 0 ? (openBlock(), createBlock("p", {
                                key: 2,
                                "opacity-80": ""
                              }, [
                                createTextVNode(" \u8DDD\u79BB\u7ED3\u675F\u8FD8\u6709\uFF1A"),
                                createVNode("strong", {
                                  "text-lg": "",
                                  style: { "color": "var(--el-color-error)" }
                                }, toDisplayString(unref(getEndDay)(p.startTime, p.endTime)), 1),
                                createTextVNode(" \u5929 "),
                                createVNode(_component_el_button, {
                                  plain: "",
                                  "cursor-pointer": "",
                                  "float-right": "",
                                  "opacity-60": ""
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("\u66F4\u591A")
                                  ]),
                                  _: 1
                                })
                              ])) : createCommentVNode("", true)
                            ])
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    (openBlock(true), createBlock(Fragment, null, renderList(unref(eventList), (p) => {
                      return openBlock(), createBlock(_component_el_carousel_item, {
                        onClick: ($event) => toEventDetailView(p.id),
                        key: p.id,
                        class: "swiper-item"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_ClientOnly, null, {
                            default: withCtx(() => [
                              createVNode(_component_el_image, {
                                class: [!unref(isLoading) ? " animate__blurIn" : "", "e-img"],
                                src: unref(BaseUrlImg) + p.images,
                                alt: p.details,
                                style: { "width": "100%", "height": "100%" },
                                fit: "fill"
                              }, {
                                error: withCtx(() => [
                                  createVNode("div", {
                                    class: "image-slot",
                                    "flex-row-c-c": ""
                                  }, [
                                    createVNode(_component_ElIconPicture, {
                                      "w-sm": "",
                                      "p-30": "",
                                      "pt-20": "",
                                      "opacity-80": "",
                                      "flex-row-c-c": ""
                                    })
                                  ])
                                ]),
                                _: 2
                              }, 1032, ["class", "src", "alt"])
                            ]),
                            _: 2
                          }, 1024),
                          createVNode("section", {
                            class: "tip",
                            "px-5": "",
                            "py-3": "",
                            "tracking-0.2em": "",
                            "text-xs": "",
                            "line-height-none": "",
                            "md:text-1em": "",
                            "md:line-height-normal": "",
                            flex: "",
                            "flex-col": "",
                            "justify-around": ""
                          }, [
                            createVNode("h3", { class: "title" }, toDisplayString(p.title), 1),
                            unref(getEndDay)(p.startTime, p.endTime) < 0 ? (openBlock(), createBlock("p", {
                              key: 0,
                              "opacity-80": "",
                              style: { "text-decoration": "line-through" }
                            }, " \u6D3B\u52A8\u5DF2\u7ECF\u7ED3\u675F ")) : createCommentVNode("", true),
                            unref(getEndDay)(p.startTime, p.endTime) === 0 ? (openBlock(), createBlock("p", {
                              key: 1,
                              "opacity-80": "",
                              style: { "color": "var(--el-color-success)" }
                            }, " \u6D3B\u52A8\u5373\u5C06\u5F00\u59CB ")) : unref(getEndDay)(p.startTime, p.endTime) > 0 ? (openBlock(), createBlock("p", {
                              key: 2,
                              "opacity-80": ""
                            }, [
                              createTextVNode(" \u8DDD\u79BB\u7ED3\u675F\u8FD8\u6709\uFF1A"),
                              createVNode("strong", {
                                "text-lg": "",
                                style: { "color": "var(--el-color-error)" }
                              }, toDisplayString(unref(getEndDay)(p.startTime, p.endTime)), 1),
                              createTextVNode(" \u5929 "),
                              createVNode(_component_el_button, {
                                plain: "",
                                "cursor-pointer": "",
                                "float-right": "",
                                "opacity-60": ""
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("\u66F4\u591A")
                                ]),
                                _: 1
                              })
                            ])) : createCommentVNode("", true)
                          ])
                        ]),
                        _: 2
                      }, 1032, ["onClick"]);
                    }), 128))
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_el_skeleton, {
                animated: "",
                loading: unref(isLoading),
                class: "ske"
              }, {
                template: withCtx(() => [
                  createVNode(_component_el_skeleton_item, {
                    "p-4": "",
                    variant: "image",
                    class: "sk-imgs",
                    "p-2": ""
                  }),
                  createVNode("div", {
                    "p-4": "",
                    "flex-col": "",
                    style: { "height": "100%" },
                    "justify-around": ""
                  }, [
                    createVNode(_component_el_skeleton_item, {
                      variant: "p",
                      "mb-1": "",
                      style: { "width": "70%" }
                    }),
                    createVNode(_component_el_skeleton_item, {
                      variant: "p",
                      "mb-1": "",
                      style: { "width": "100%" }
                    })
                  ])
                ]),
                default: withCtx(() => [
                  (openBlock(true), createBlock(Fragment, null, renderList(unref(eventList), (p) => {
                    return openBlock(), createBlock(_component_el_carousel_item, {
                      onClick: ($event) => toEventDetailView(p.id),
                      key: p.id,
                      class: "swiper-item"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_ClientOnly, null, {
                          default: withCtx(() => [
                            createVNode(_component_el_image, {
                              class: [!unref(isLoading) ? " animate__blurIn" : "", "e-img"],
                              src: unref(BaseUrlImg) + p.images,
                              alt: p.details,
                              style: { "width": "100%", "height": "100%" },
                              fit: "fill"
                            }, {
                              error: withCtx(() => [
                                createVNode("div", {
                                  class: "image-slot",
                                  "flex-row-c-c": ""
                                }, [
                                  createVNode(_component_ElIconPicture, {
                                    "w-sm": "",
                                    "p-30": "",
                                    "pt-20": "",
                                    "opacity-80": "",
                                    "flex-row-c-c": ""
                                  })
                                ])
                              ]),
                              _: 2
                            }, 1032, ["class", "src", "alt"])
                          ]),
                          _: 2
                        }, 1024),
                        createVNode("section", {
                          class: "tip",
                          "px-5": "",
                          "py-3": "",
                          "tracking-0.2em": "",
                          "text-xs": "",
                          "line-height-none": "",
                          "md:text-1em": "",
                          "md:line-height-normal": "",
                          flex: "",
                          "flex-col": "",
                          "justify-around": ""
                        }, [
                          createVNode("h3", { class: "title" }, toDisplayString(p.title), 1),
                          unref(getEndDay)(p.startTime, p.endTime) < 0 ? (openBlock(), createBlock("p", {
                            key: 0,
                            "opacity-80": "",
                            style: { "text-decoration": "line-through" }
                          }, " \u6D3B\u52A8\u5DF2\u7ECF\u7ED3\u675F ")) : createCommentVNode("", true),
                          unref(getEndDay)(p.startTime, p.endTime) === 0 ? (openBlock(), createBlock("p", {
                            key: 1,
                            "opacity-80": "",
                            style: { "color": "var(--el-color-success)" }
                          }, " \u6D3B\u52A8\u5373\u5C06\u5F00\u59CB ")) : unref(getEndDay)(p.startTime, p.endTime) > 0 ? (openBlock(), createBlock("p", {
                            key: 2,
                            "opacity-80": ""
                          }, [
                            createTextVNode(" \u8DDD\u79BB\u7ED3\u675F\u8FD8\u6709\uFF1A"),
                            createVNode("strong", {
                              "text-lg": "",
                              style: { "color": "var(--el-color-error)" }
                            }, toDisplayString(unref(getEndDay)(p.startTime, p.endTime)), 1),
                            createTextVNode(" \u5929 "),
                            createVNode(_component_el_button, {
                              plain: "",
                              "cursor-pointer": "",
                              "float-right": "",
                              "opacity-60": ""
                            }, {
                              default: withCtx(() => [
                                createTextVNode("\u66F4\u591A")
                              ]),
                              _: 1
                            })
                          ])) : createCommentVNode("", true)
                        ])
                      ]),
                      _: 2
                    }, 1032, ["onClick"]);
                  }), 128))
                ]),
                _: 1
              }, 8, ["loading"])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Index/Swiper.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-1d8e9e43"]]);
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "HotGoodsList",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const page = ref(1);
    const size = ref(6);
    const isLoading = ref(true);
    const { data } = ([__temp, __restore] = withAsyncContext(() => getGoodsListByPage(page.value, size.value, {
      viewsSort: isTrue.TRUE,
      saleSort: isTrue.TRUE
    })), __temp = await __temp, __restore(), __temp);
    reactive(
      data || {
        records: [{}],
        total: 0,
        pages: 0,
        size: 0,
        current: 0
      }
    );
    const hotGoodsList = ref([]);
    data == null ? void 0 : data.records.forEach((p) => {
      p.images = typeof p.images === "string" ? p.images.split(",") : [];
      hotGoodsList.value.push(p);
    });
    isLoading.value = false;
    return (_ctx, _push, _parent, _attrs) => {
      const _component_el_skeleton = ElSkeleton;
      const _component_el_skeleton_item = ElSkeletonItem;
      const _component_ClientOnly = __nuxt_component_1$2;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "hot-list",
        "min-h-420px": "",
        "h-420px": "",
        "p-4": "",
        "mx-a": "",
        "md:ma-0": "",
        "rounded-4px": "",
        "min-w-420px": "",
        border: "1px solid gray-200",
        "dark:border": "1px solid dark-200"
      }, _attrs))} data-v-a668c44b><h3 px-1 pb-4 data-v-a668c44b> \u70ED\u95E8\u5546\u54C1 <span p-3 bg-red-6 mx-2 i-solar:fire-bold data-v-a668c44b></span></h3>`);
      _push(ssrRenderComponent(_component_el_skeleton, {
        animated: "",
        loading: unref(isLoading),
        throttle: 300,
        class: "ske"
      }, {
        template: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div flex p-2 opacity-80 data-v-a668c44b${_scopeId}>`);
            _push2(ssrRenderComponent(_component_el_skeleton_item, {
              style: { "width": "5.6em", "height": "5.6em", "border-radius": "2px" },
              variant: "image"
            }, null, _parent2, _scopeId));
            _push2(`<div flex-1 px-2 flex flex-col justify-around data-v-a668c44b${_scopeId}>`);
            _push2(ssrRenderComponent(_component_el_skeleton_item, {
              style: { "opacity": "0.8" },
              variant: "p"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_el_skeleton_item, {
              style: { "width": "50%" },
              variant: "text"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_el_skeleton_item, {
              style: { "width": "60%" },
              variant: "text"
            }, null, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", {
                flex: "",
                "p-2": "",
                "opacity-80": ""
              }, [
                createVNode(_component_el_skeleton_item, {
                  style: { "width": "5.6em", "height": "5.6em", "border-radius": "2px" },
                  variant: "image"
                }),
                createVNode("div", {
                  "flex-1": "",
                  "px-2": "",
                  flex: "",
                  "flex-col": "",
                  "justify-around": ""
                }, [
                  createVNode(_component_el_skeleton_item, {
                    style: { "opacity": "0.8" },
                    variant: "p"
                  }),
                  createVNode(_component_el_skeleton_item, {
                    style: { "width": "50%" },
                    variant: "text"
                  }),
                  createVNode(_component_el_skeleton_item, {
                    style: { "width": "60%" },
                    variant: "text"
                  })
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Index/HotGoodsList.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-a668c44b"]]);
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "CategoryLine",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a;
    let __temp, __restore;
    const { data } = ([__temp, __restore] = withAsyncContext(() => getGoodsCategoryList()), __temp = await __temp, __restore(), __temp);
    const categoryList = ((_a = data.value) == null ? void 0 : _a.data) || [];
    const router = useRouter();
    const toView = (item) => {
      router.push({
        path: "/search",
        query: {
          cname: item.name,
          cid: item.id
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ElScrollbar = ElScrollbar;
      const _component_el_button = ElButton;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "category-list" }, _attrs))}><h3 class="title" dark:text-amber-4 pl-1> \u70ED\u95E8\u5206\u7C7B <i i-solar:adhesive-plaster-bold-duotone ml-4 p-3 bg-yellow-4></i></h3>`);
      _push(ssrRenderComponent(_component_ElScrollbar, {
        "min-size": 30,
        "overflow-x-scroll": "",
        "tracking-0.1em": "",
        class: "category animate-delay-100 animate__animated animate__fadeIn",
        style: { "width": "100%" }
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="scroll flex flex-nowrap"${_scopeId}><!--[-->`);
            ssrRenderList(unref(categoryList), (p) => {
              _push2(`<div flex-row-c-c mr-2 my-4 relative${_scopeId}>`);
              _push2(ssrRenderComponent(_component_el_button, {
                size: "large",
                class: "first",
                onClick: ($event) => toView(p),
                "inline-block": "",
                "mr-2": "",
                style: { "position": "relative", "display": "inline-block", "width": "9em", "height": "4.6em", "line-height": "100%" },
                "flex-row-c-c": ""
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<img${ssrRenderAttr("src", unref(BaseUrlImg) + p.icon)}${ssrRenderAttr("alt", p.name)} opacity-85 rounded-4px style="${ssrRenderStyle({ "width": "9em", "height": "4.6em", "object-fit": "cover" })}" absolute top-0 left-0 z-0${_scopeId2}><h3 z-1 text-light${_scopeId2}>${ssrInterpolate(p.name)}</h3>`);
                  } else {
                    return [
                      createVNode("img", {
                        src: unref(BaseUrlImg) + p.icon,
                        alt: p.name,
                        "opacity-85": "",
                        "rounded-4px": "",
                        style: { "width": "9em", "height": "4.6em", "object-fit": "cover" },
                        absolute: "",
                        "top-0": "",
                        "left-0": "",
                        "z-0": ""
                      }, null, 8, ["src", "alt"]),
                      createVNode("h3", {
                        "z-1": "",
                        "text-light": ""
                      }, toDisplayString(p.name), 1)
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`<!--[-->`);
              ssrRenderList(p == null ? void 0 : p.children, (k) => {
                _push2(ssrRenderComponent(_component_el_button, {
                  onClick: ($event) => toView(k),
                  type: "primary",
                  plain: "",
                  key: k.id,
                  style: { "position": "relative", "width": "9em", "height": "4.6em", "line-height": "100%" },
                  "my-2": "",
                  "mx-0": "",
                  "flex-row-c-c": ""
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`<img${ssrRenderAttr("src", unref(BaseUrlImg) + k.icon)}${ssrRenderAttr("alt", k.name)} opacity-85 rounded-4px style="${ssrRenderStyle({ "width": "100%", "height": "100%", "object-fit": "cover" })}" absolute top-0 left-0 z-0${_scopeId2}><h3 z-1 text-light${_scopeId2}>${ssrInterpolate(k.name)}</h3>`);
                    } else {
                      return [
                        createVNode("img", {
                          src: unref(BaseUrlImg) + k.icon,
                          alt: k.name,
                          "opacity-85": "",
                          "rounded-4px": "",
                          style: { "width": "100%", "height": "100%", "object-fit": "cover" },
                          absolute: "",
                          "top-0": "",
                          "left-0": "",
                          "z-0": ""
                        }, null, 8, ["src", "alt"]),
                        createVNode("h3", {
                          "z-1": "",
                          "text-light": ""
                        }, toDisplayString(k.name), 1)
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              });
              _push2(`<!--]--></div>`);
            });
            _push2(`<!--]--></div>`);
          } else {
            return [
              createVNode("div", { class: "scroll flex flex-nowrap" }, [
                (openBlock(true), createBlock(Fragment, null, renderList(unref(categoryList), (p) => {
                  return openBlock(), createBlock("div", {
                    "flex-row-c-c": "",
                    "mr-2": "",
                    "my-4": "",
                    key: p.id,
                    relative: ""
                  }, [
                    createVNode(_component_el_button, {
                      size: "large",
                      class: "first",
                      onClick: ($event) => toView(p),
                      "inline-block": "",
                      "mr-2": "",
                      style: { "position": "relative", "display": "inline-block", "width": "9em", "height": "4.6em", "line-height": "100%" },
                      "flex-row-c-c": ""
                    }, {
                      default: withCtx(() => [
                        createVNode("img", {
                          src: unref(BaseUrlImg) + p.icon,
                          alt: p.name,
                          "opacity-85": "",
                          "rounded-4px": "",
                          style: { "width": "9em", "height": "4.6em", "object-fit": "cover" },
                          absolute: "",
                          "top-0": "",
                          "left-0": "",
                          "z-0": ""
                        }, null, 8, ["src", "alt"]),
                        createVNode("h3", {
                          "z-1": "",
                          "text-light": ""
                        }, toDisplayString(p.name), 1)
                      ]),
                      _: 2
                    }, 1032, ["onClick"]),
                    (openBlock(true), createBlock(Fragment, null, renderList(p == null ? void 0 : p.children, (k) => {
                      return openBlock(), createBlock(_component_el_button, {
                        onClick: ($event) => toView(k),
                        type: "primary",
                        plain: "",
                        key: k.id,
                        style: { "position": "relative", "width": "9em", "height": "4.6em", "line-height": "100%" },
                        "my-2": "",
                        "mx-0": "",
                        "flex-row-c-c": ""
                      }, {
                        default: withCtx(() => [
                          createVNode("img", {
                            src: unref(BaseUrlImg) + k.icon,
                            alt: k.name,
                            "opacity-85": "",
                            "rounded-4px": "",
                            style: { "width": "100%", "height": "100%", "object-fit": "cover" },
                            absolute: "",
                            "top-0": "",
                            "left-0": "",
                            "z-0": ""
                          }, null, 8, ["src", "alt"]),
                          createVNode("h3", {
                            "z-1": "",
                            "text-light": ""
                          }, toDisplayString(k.name), 1)
                        ]),
                        _: 2
                      }, 1032, ["onClick"]);
                    }), 128))
                  ]);
                }), 128))
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Index/CategoryLine.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "GoodsTabs",
  __ssrInlineRender: true,
  setup(__props) {
    const activeMenu = ref("isHot");
    return (_ctx, _push, _parent, _attrs) => {
      const _component_el_tabs = ElTabs;
      const _component_el_tab_pane = ElTabPane;
      const _component_ListGoodsList = __nuxt_component_6;
      _push(ssrRenderComponent(_component_el_tabs, mergeProps({
        class: "goods-tabs min-h-50vh",
        "tab-position": "top",
        modelValue: unref(activeMenu),
        "onUpdate:modelValue": ($event) => isRef(activeMenu) ? activeMenu.value = $event : null
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_el_tab_pane, {
              name: "isHot",
              class: "animate__animated animate__fadeIn",
              label: "\u70ED\u5356\u597D\u7269"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_ListGoodsList, {
                    dto: { saleSort: ("isTrue" in _ctx ? _ctx.isTrue : unref(isTrue)).TRUE }
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_ListGoodsList, {
                      dto: { saleSort: ("isTrue" in _ctx ? _ctx.isTrue : unref(isTrue)).TRUE }
                    }, null, 8, ["dto"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_el_tab_pane, {
              name: "isNew",
              class: "animate__animated animate__fadeIn",
              lazy: true,
              label: "\u65B0\u54C1\u4E0A\u67B6"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_ListGoodsList, {
                    dto: { isNew: ("isTrue" in _ctx ? _ctx.isTrue : unref(isTrue)).TRUE }
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_ListGoodsList, {
                      dto: { isNew: ("isTrue" in _ctx ? _ctx.isTrue : unref(isTrue)).TRUE }
                    }, null, 8, ["dto"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_el_tab_pane, {
              name: "isViews",
              class: "animate__animated animate__fadeIn",
              lazy: true,
              label: "\u4EBA\u6C14\u5546\u54C1"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_ListGoodsList, {
                    dto: { viewsSort: ("isTrue" in _ctx ? _ctx.isTrue : unref(isTrue)).TRUE }
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_ListGoodsList, {
                      dto: { viewsSort: ("isTrue" in _ctx ? _ctx.isTrue : unref(isTrue)).TRUE }
                    }, null, 8, ["dto"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_el_tab_pane, {
                name: "isHot",
                class: "animate__animated animate__fadeIn",
                label: "\u70ED\u5356\u597D\u7269"
              }, {
                default: withCtx(() => [
                  createVNode(_component_ListGoodsList, {
                    dto: { saleSort: ("isTrue" in _ctx ? _ctx.isTrue : unref(isTrue)).TRUE }
                  }, null, 8, ["dto"])
                ]),
                _: 1
              }),
              createVNode(_component_el_tab_pane, {
                name: "isNew",
                class: "animate__animated animate__fadeIn",
                lazy: true,
                label: "\u65B0\u54C1\u4E0A\u67B6"
              }, {
                default: withCtx(() => [
                  createVNode(_component_ListGoodsList, {
                    dto: { isNew: ("isTrue" in _ctx ? _ctx.isTrue : unref(isTrue)).TRUE }
                  }, null, 8, ["dto"])
                ]),
                _: 1
              }),
              createVNode(_component_el_tab_pane, {
                name: "isViews",
                class: "animate__animated animate__fadeIn",
                lazy: true,
                label: "\u4EBA\u6C14\u5546\u54C1"
              }, {
                default: withCtx(() => [
                  createVNode(_component_ListGoodsList, {
                    dto: { viewsSort: ("isTrue" in _ctx ? _ctx.isTrue : unref(isTrue)).TRUE }
                  }, null, 8, ["dto"])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Index/GoodsTabs.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_5 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-2bd65559"]]);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "\u6781\u7269\u5708",
      meta: [
        {
          name: "description",
          content: "\u6781\u7269\u5708-\u4E3B\u9875 \u5F00\u542F\u4F60\u7684\u6781\u7269\u4E4B\u65C5\uFF01"
        }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLayout = __nuxt_component_0;
      const _component_IndexTopMenu = _sfc_main$5;
      const _component_IndexSwiper = __nuxt_component_2;
      const _component_IndexHotGoodsList = __nuxt_component_3;
      const _component_IndexCategoryLine = _sfc_main$2;
      const _component_IndexGoodsTabs = __nuxt_component_5;
      _push(ssrRenderComponent(_component_NuxtLayout, mergeProps({ name: "default" }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="index w-1/1" flex flex-col items-center${_scopeId}><div overflow-x-hidden layout-default${_scopeId}>`);
            _push2(ssrRenderComponent(_component_IndexTopMenu, { "min-h-160px": "" }, null, _parent2, _scopeId));
            _push2(`<div flex pt-4${_scopeId}><div class="flex-1" flex-row-c-c${_scopeId}>`);
            _push2(ssrRenderComponent(_component_IndexSwiper, { class: "mx-auto" }, null, _parent2, _scopeId));
            _push2(`</div><div ml-3 class="flex-3"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_IndexHotGoodsList, null, null, _parent2, _scopeId));
            _push2(`</div></div></div><div class="bottom" overflowx-hidden${_scopeId}><div mt-6 layout-default${_scopeId}>`);
            _push2(ssrRenderComponent(_component_IndexCategoryLine, null, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_IndexGoodsTabs, { class: "mt-6" }, null, _parent2, _scopeId));
            _push2(`</div></div></div>`);
          } else {
            return [
              createVNode("div", {
                class: "index w-1/1",
                flex: "",
                "flex-col": "",
                "items-center": ""
              }, [
                createVNode("div", {
                  "overflow-x-hidden": "",
                  "layout-default": ""
                }, [
                  createVNode(_component_IndexTopMenu, { "min-h-160px": "" }),
                  createVNode("div", {
                    flex: "",
                    "pt-4": ""
                  }, [
                    createVNode("div", {
                      class: "flex-1",
                      "flex-row-c-c": ""
                    }, [
                      createVNode(_component_IndexSwiper, { class: "mx-auto" })
                    ]),
                    createVNode("div", {
                      "ml-3": "",
                      class: "flex-3"
                    }, [
                      createVNode(_component_IndexHotGoodsList)
                    ])
                  ])
                ]),
                createVNode("div", {
                  class: "bottom",
                  "overflowx-hidden": ""
                }, [
                  createVNode("div", {
                    "mt-6": "",
                    "layout-default": ""
                  }, [
                    createVNode(_component_IndexCategoryLine),
                    createVNode(_component_IndexGoodsTabs, { class: "mt-6" })
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-462817a6.mjs.map
