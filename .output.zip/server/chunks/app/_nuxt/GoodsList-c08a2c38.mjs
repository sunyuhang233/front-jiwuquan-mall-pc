import { $ as useHttp, u as useRouter, ab as toReactive, _ as _export_sfc, x as __nuxt_component_1$2, aa as vLoading } from '../server.mjs';
import { useSSRContext, defineComponent, ref, reactive, computed, watch, mergeProps, unref } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderStyle, ssrGetDirectiveProps } from 'vue/server-renderer';
import { u as useFetch } from './fetch-da5935af.mjs';
import { b as BaseUrl } from './useFetchUtil-5309feca.mjs';

function getGoodsListByPage(page, size, dto) {
  return useHttp.post(
    `/goods/list/${page}/${size}`,
    { ...dto }
  );
}
function getGoodsInfoById(gid) {
  return useFetch(BaseUrl + `/goods/item/${gid}`, "$VYsWCMxwaG");
}
function addGoodsViewsById(gid, token) {
  return useHttp.put(`/goods/views/${gid}`, {}, {
    headers: {
      "Authorization": token
    }
  });
}
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "GoodsList",
  __ssrInlineRender: true,
  props: {
    dto: {},
    limit: {},
    load: { type: Boolean }
  },
  setup(__props, { expose: __expose }) {
    const props = __props;
    const isLoading = ref(false);
    const goodsList = ref([]);
    const page = ref(0);
    const size = ref(props.limit || 10);
    let pageInfo = reactive({
      records: [],
      total: -1,
      pages: -1,
      size: -1,
      current: -1
    });
    const isNot = ref(false);
    const isNoMore = computed({
      get() {
        return goodsList.value.length === (pageInfo == null ? void 0 : pageInfo.total);
      },
      set(val) {
      }
    });
    const loadGoodsPage = async () => {
      if (isLoading.value)
        return;
      isLoading.value = true;
      page.value++;
      const { data } = await getGoodsListByPage(page.value, size.value, props.dto);
      if (isNoMore.value || (data == null ? void 0 : data.total) === -1) {
        return isLoading.value = false;
      }
      pageInfo = toReactive({ ...data });
      let timer;
      if (!(data == null ? void 0 : data.records) || (data == null ? void 0 : data.records.length) === 0) {
        isNot.value = true;
        return isLoading.value = false;
      } else {
        isNot.value = false;
      }
      for await (const p of data.records) {
        await new Promise((resolve) => {
          timer = setTimeout(() => {
            p.images = typeof p.images === "string" ? p.images.split(",") : [];
            goodsList.value.push(p);
            clearTimeout(timer ?? void 0);
            timer = null;
            isLoading.value = false;
            return resolve(true);
          }, 50);
        });
      }
    };
    loadGoodsPage();
    const clearResult = () => {
      goodsList.value.splice(0);
      pageInfo = reactive({
        records: [],
        total: -1,
        pages: -1,
        size: -1,
        current: -1
      });
    };
    useRouter();
    const dto = toReactive(props.dto);
    watch(
      dto,
      () => {
        clearResult();
        loadGoodsPage();
      },
      { deep: true, immediate: true }
    );
    __expose({
      clearResult,
      // 清除
      loadGoodsPage,
      goodsList,
      pageInfo
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ClientOnly = __nuxt_component_1$2;
      const _directive_loading = vLoading;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "goods-list min-h-80vh",
        style: { "overflow": "auto" }
      }, _attrs))} data-v-364423c5>`);
      _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
      _push(`<p class="w-1/1 pt-2" text-blueGray tracking-1 text-center style="${ssrRenderStyle(unref(isNoMore) ? null : { display: "none" })}" data-v-364423c5> \u6682\u65E0\u66F4\u591A\u5546\u54C1 </p><p class="w-1/1 pt-2" text-blueGray tracking-1 text-center style="${ssrRenderStyle(unref(isNot) ? null : { display: "none" })}" data-v-364423c5>\u6682\u65E0\u5546\u54C1</p><div${ssrRenderAttrs(mergeProps({
        class: "loading w-1/1",
        "p-5em": ""
      }, ssrGetDirectiveProps(_ctx, _directive_loading, unref(isLoading))))} data-v-364423c5></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/list/GoodsList.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_6 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-364423c5"]]);

export { __nuxt_component_6 as _, addGoodsViewsById as a, getGoodsListByPage as b, getGoodsInfoById as g };
//# sourceMappingURL=GoodsList-c08a2c38.mjs.map
