import { b as buildAssetsURL } from '../../handlers/renderer.mjs';

const _imports_0 = "" + buildAssetsURL("logo_txt.318d9294.png");

export { _imports_0 as _ };
//# sourceMappingURL=logo_txt-7733b5d1.mjs.map
