import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_0 } from './HeaderMenu-a788779c.mjs';
import { x as __nuxt_component_1$2, _ as _export_sfc } from '../server.mjs';
import { _ as __nuxt_component_0$1 } from './nuxt-link-1d0a99ed.mjs';
import { defineComponent, mergeProps, useSSRContext, withCtx, createVNode } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderSlot, ssrRenderAttr } from 'vue/server-renderer';
import { _ as _imports_0 } from './logo_txt-7733b5d1.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import './logo_dark-b7cf3e36.mjs';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@vue/shared';
import 'cookie-es';
import 'pinia-plugin-persistedstate';
import 'gsap';
import 'lodash-unified';
import 'nprogress';
import '@kangc/v-md-editor';
import 'async-validator';
import '@ctrl/tinycolor';

const _imports_1 = "" + buildAssetsURL("kiwi_strong.cd9c4b1a.svg");
const _sfc_main$1 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_NuxtLink = __nuxt_component_0$1;
  _push(`<footer${ssrRenderAttrs(mergeProps({
    class: "w-1/1 min-h-180px animate__animated animate__fadeIn",
    "border-t": "1px solid gray-200",
    "dark:border-t-dark-3": "",
    "shadow-md": "",
    "dark:bg-dark-9": ""
  }, _attrs))}><div class="content layout-default" dark:opacity-80 flex-row-c-c flex-col><img${ssrRenderAttr("src", _imports_0)} w-180px alt="Design By: Kiwi2333"><h4 pt-1em opacity-70> Design By: `);
  _push(ssrRenderComponent(_component_NuxtLink, {
    class: "mark2 animate__animated",
    target: "_blank",
    to: "https://github.com/KiWi233333"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<img${ssrRenderAttr("src", _imports_1)} class="mx-4 w-100px" dark:filter-invert-100${_scopeId}>`);
      } else {
        return [
          createVNode("img", {
            src: _imports_1,
            class: "mx-4 w-100px",
            "dark:filter-invert-100": ""
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</h4></div></footer>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/menu/Footer.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "second",
  __ssrInlineRender: true,
  props: {
    footer: {
      type: Boolean,
      default: true,
      required: false
    },
    menu: {
      default: ["shopcart", "back"],
      required: false
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_MenuHeaderMenu = __nuxt_component_0;
      const _component_ClientOnly = __nuxt_component_1$2;
      const _component_MenuFooter = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "second",
        "min-h-100vh": "",
        flex: "",
        "flex-col": "",
        "justify-between": ""
      }, _attrs))}>`);
      _push(ssrRenderComponent(_component_MenuHeaderMenu, null, null, _parent));
      _push(`<div flex-1>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div>`);
      _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
      if (__props.footer) {
        _push(ssrRenderComponent(_component_MenuFooter, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/second.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=second-d1ba3d24.mjs.map
