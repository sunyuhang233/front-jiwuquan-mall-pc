import { _ as __nuxt_component_0 } from './layout-ae7ff3e5.mjs';
import { _ as _export_sfc, E as ElButton } from '../server.mjs';
import { _ as __nuxt_component_0$1 } from './nuxt-link-31805786.mjs';
import { withCtx, createVNode, useSSRContext } from 'vue';
import { ssrRenderComponent } from 'vue/server-renderer';
import 'vue-router';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'destr';
import 'h3';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'ufo';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import 'pinia-plugin-persistedstate';
import 'nprogress';
import 'lodash-unified';
import 'async-validator';
import '@ctrl/tinycolor';
import 'axios';
import 'lodash';
import 'defu';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'klona';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_NuxtLayout = __nuxt_component_0;
  const _component_ElButton = ElButton;
  const _component_NuxtLink = __nuxt_component_0$1;
  _push(ssrRenderComponent(_component_NuxtLayout, _attrs, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<div class="index" p="y-2 x-4" flex-row-c-c${_scopeId}>`);
        _push2(ssrRenderComponent(_component_ElButton, null, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(`<span text-black font-700${_scopeId3}>\u8FD4\u56DE\u4E3B\u9875</span>`);
                  } else {
                    return [
                      createVNode("span", {
                        "text-black": "",
                        "font-700": ""
                      }, "\u8FD4\u56DE\u4E3B\u9875")
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_NuxtLink, { to: "/" }, {
                  default: withCtx(() => [
                    createVNode("span", {
                      "text-black": "",
                      "font-700": ""
                    }, "\u8FD4\u56DE\u4E3B\u9875")
                  ]),
                  _: 1
                })
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(`</div>`);
      } else {
        return [
          createVNode("div", {
            class: "index",
            p: "y-2 x-4",
            "flex-row-c-c": ""
          }, [
            createVNode(_component_ElButton, null, {
              default: withCtx(() => [
                createVNode(_component_NuxtLink, { to: "/" }, {
                  default: withCtx(() => [
                    createVNode("span", {
                      "text-black": "",
                      "font-700": ""
                    }, "\u8FD4\u56DE\u4E3B\u9875")
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/[...all].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const ____all_ = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { ____all_ as default };
//# sourceMappingURL=_...all_-74a7d5d4.mjs.map
