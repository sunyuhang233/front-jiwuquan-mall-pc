import { E as ElEmpty } from './index-a3ed7626.mjs';
import { _ as _export_sfc, u as useRouter, E as ElButton } from '../server.mjs';
import { mergeProps, withCtx, unref, createTextVNode, createVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import './index-5453207f.mjs';
import 'lodash-unified';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'destr';
import 'h3';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'ufo';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import 'pinia-plugin-persistedstate';
import 'gsap';
import 'nprogress';
import '@kangc/v-md-editor';
import 'async-validator';
import '@ctrl/tinycolor';
import 'defu';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'klona';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_ElEmpty = ElEmpty;
  const _component_ElButton = ElButton;
  _push(`<div${ssrRenderAttrs(mergeProps({ "flex-row-c-c": "" }, _attrs))}>`);
  _push(ssrRenderComponent(_component_ElEmpty, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<div flex-row-c-c${_scopeId}><h3 mb-5${_scopeId}>404 \u9875\u9762\u627E\u4E0D\u5230\uFF01</h3>`);
        _push2(ssrRenderComponent(_component_ElButton, {
          onClick: ($event) => ("useRouter" in _ctx ? _ctx.useRouter : unref(useRouter))().back(),
          plain: "",
          type: "primary"
        }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(` \u8FD4\u56DE `);
            } else {
              return [
                createTextVNode(" \u8FD4\u56DE ")
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(`</div>`);
      } else {
        return [
          createVNode("div", { "flex-row-c-c": "" }, [
            createVNode("h3", { "mb-5": "" }, "404 \u9875\u9762\u627E\u4E0D\u5230\uFF01"),
            createVNode(_component_ElButton, {
              onClick: ($event) => ("useRouter" in _ctx ? _ctx.useRouter : unref(useRouter))().back(),
              plain: "",
              type: "primary"
            }, {
              default: withCtx(() => [
                createTextVNode(" \u8FD4\u56DE ")
              ]),
              _: 1
            }, 8, ["onClick"])
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/error.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const error = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { error as default };
//# sourceMappingURL=error-30f14533.mjs.map
