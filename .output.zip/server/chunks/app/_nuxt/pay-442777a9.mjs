import { _ as __nuxt_component_0 } from './layout-9cd450dc.mjs';
import { _ as _export_sfc, b as useHead, X as appName, Y as useOrderStore, Z as useAddresStore, B as useUserStore, u as useRouter, S as StatusCode, x as __nuxt_component_1$2 } from '../server.mjs';
import { E as ElRadioGroup, _ as _sfc_main$1, a as ElRadio } from './radio-255b993d.mjs';
import { useSSRContext, defineComponent, ref, withAsyncContext, mergeProps, withCtx, createVNode, unref, isRef, openBlock, createBlock, Fragment, renderList } from 'vue';
import { ssrRenderComponent } from 'vue/server-renderer';
import { a as getGoodsSkuByIds } from './sku-fbef5eec.mjs';
import 'vue-router';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'destr';
import 'h3';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'ufo';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import 'pinia-plugin-persistedstate';
import 'gsap';
import 'lodash-unified';
import 'nprogress';
import '@kangc/v-md-editor';
import 'async-validator';
import '@ctrl/tinycolor';
import 'defu';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'klona';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import './index-d9c790e5.mjs';
import './fetch-da5935af.mjs';
import './useFetchUtil-5309feca.mjs';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "pay",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a, _b;
    let __temp, __restore;
    useHead({
      title: appName + " - \u8BA2\u5355",
      meta: [
        {
          name: "description",
          content: "\u6781\u7269\u5708-\u6211\u7684\u8BA2\u5355"
        }
      ]
    });
    const order = useOrderStore();
    const address = useAddresStore();
    const user = useUserStore();
    useRouter();
    const skuIdList = [];
    (_a = order.pushOrderItems) == null ? void 0 : _a.forEach((p) => {
      skuIdList.push(p.skuId);
    });
    address.resetRequestList(user.getToken);
    const skuList = ref([]);
    const { data, code } = ([__temp, __restore] = withAsyncContext(() => getGoodsSkuByIds(skuIdList)), __temp = await __temp, __restore(), __temp);
    if (code === StatusCode.SUCCESS) {
      skuList.value.push(...data);
    }
    const selectAddressId = ref("");
    selectAddressId.value = (_b = address.addressList[0]) == null ? void 0 : _b.id;
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLayout = __nuxt_component_0;
      const _component_ClientOnly = __nuxt_component_1$2;
      const _component_el_radio_group = ElRadioGroup;
      const _component_CardAddressBox = _sfc_main$1;
      const _component_el_radio = ElRadio;
      _push(ssrRenderComponent(_component_NuxtLayout, mergeProps({
        "left-menu": false,
        menu: ["shopcart", "back"]
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div layout-default w-700px data-v-a93f8659${_scopeId}><div class="top" border-default border-0 border-b="2px" data-v-a93f8659${_scopeId}><h3 mb-4 data-v-a93f8659${_scopeId}>\u63D0\u4EA4\u8BA2\u5355</h3></div>`);
            _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", {
                "layout-default": "",
                "w-700px": ""
              }, [
                createVNode("div", {
                  class: "top",
                  "border-default": "",
                  "border-0": "",
                  "border-b": "2px"
                }, [
                  createVNode("h3", { "mb-4": "" }, "\u63D0\u4EA4\u8BA2\u5355")
                ]),
                createVNode(_component_ClientOnly, null, {
                  default: withCtx(() => [
                    createVNode("div", { "my-2": "" }, [
                      createVNode("label", { "my-4": "" }, "\u6536\u8D27\u5730\u5740\uFF1A"),
                      createVNode("div", { class: "address w-1/1 flex flex-wrap p-0" }, [
                        createVNode(_component_el_radio_group, {
                          modelValue: unref(selectAddressId),
                          "onUpdate:modelValue": ($event) => isRef(selectAddressId) ? selectAddressId.value = $event : null
                        }, {
                          default: withCtx(() => [
                            (openBlock(true), createBlock(Fragment, null, renderList(unref(address).addressList, (p, i) => {
                              return openBlock(), createBlock(_component_CardAddressBox, {
                                address: p,
                                key: p.id
                              }, {
                                btns: withCtx(() => [
                                  createVNode(_component_el_radio, {
                                    label: p.id
                                  }, null, 8, ["label"])
                                ]),
                                _: 2
                              }, 1032, ["address"]);
                            }), 128))
                          ]),
                          _: 1
                        }, 8, ["modelValue", "onUpdate:modelValue"])
                      ])
                    ])
                  ]),
                  _: 1
                })
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/order/pay.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const pay = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-a93f8659"]]);

export { pay as default };
//# sourceMappingURL=pay-442777a9.mjs.map
