import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { defineComponent, shallowRef, ref, computed, watch, watchEffect, openBlock, createElementBlock, normalizeClass, unref, normalizeStyle, createElementVNode, renderSlot, useSSRContext, getCurrentInstance, mergeProps, isRef, withCtx, createVNode, toDisplayString, createTextVNode, createBlock } from 'vue';
import { b as buildProps, k as definePropType, a as useNamespace, O as useWindowSize, P as useElementBounding, Q as addUnit, q as useEventListener, w as withInstall, _ as _export_sfc, i as isNumber, M as isBoolean, N as CHANGE_EVENT, h as _export_sfc$1, R as useRouter, T as search_default, C as useUserStore, u as useRoute, U as ElInput, V as useState, E as ElButton, B as __nuxt_component_0$2 } from '../server.mjs';
import { _ as __nuxt_component_0$1 } from './nuxt-link-31805786.mjs';
import { ssrRenderComponent, ssrRenderAttrs, ssrRenderAttr, ssrRenderStyle, ssrRenderSlot } from 'vue/server-renderer';
import { u as useStorage } from './index-5d11cade.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@vue/shared';
import 'cookie-es';
import 'pinia-plugin-persistedstate';
import 'nprogress';
import 'lodash-unified';
import 'async-validator';
import '@ctrl/tinycolor';
import 'axios';
import 'lodash';

const affixProps = buildProps({
  zIndex: {
    type: definePropType([Number, String]),
    default: 100
  },
  target: {
    type: String,
    default: ""
  },
  offset: {
    type: Number,
    default: 0
  },
  position: {
    type: String,
    values: ["top", "bottom"],
    default: "top"
  }
});
const affixEmits = {
  scroll: ({ scrollTop, fixed }) => isNumber(scrollTop) && isBoolean(fixed),
  [CHANGE_EVENT]: (fixed) => isBoolean(fixed)
};
const COMPONENT_NAME = "ElAffix";
const __default__ = /* @__PURE__ */ defineComponent({
  name: COMPONENT_NAME
});
const _sfc_main$6 = /* @__PURE__ */ defineComponent({
  ...__default__,
  props: affixProps,
  emits: affixEmits,
  setup(__props, { expose, emit }) {
    const props = __props;
    const ns = useNamespace("affix");
    const target = shallowRef();
    const root = shallowRef();
    const scrollContainer = shallowRef();
    const { height: windowHeight } = useWindowSize();
    const {
      height: rootHeight,
      width: rootWidth,
      top: rootTop,
      bottom: rootBottom,
      update: updateRoot
    } = useElementBounding(root, { windowScroll: false });
    const targetRect = useElementBounding(target);
    const fixed = ref(false);
    const scrollTop = ref(0);
    const transform = ref(0);
    const rootStyle = computed(() => {
      return {
        height: fixed.value ? `${rootHeight.value}px` : "",
        width: fixed.value ? `${rootWidth.value}px` : ""
      };
    });
    const affixStyle = computed(() => {
      if (!fixed.value)
        return {};
      const offset = props.offset ? addUnit(props.offset) : 0;
      return {
        height: `${rootHeight.value}px`,
        width: `${rootWidth.value}px`,
        top: props.position === "top" ? offset : "",
        bottom: props.position === "bottom" ? offset : "",
        transform: transform.value ? `translateY(${transform.value}px)` : "",
        zIndex: props.zIndex
      };
    });
    const update = () => {
      if (!scrollContainer.value)
        return;
      scrollTop.value = scrollContainer.value instanceof Window ? document.documentElement.scrollTop : scrollContainer.value.scrollTop || 0;
      if (props.position === "top") {
        if (props.target) {
          const difference = targetRect.bottom.value - props.offset - rootHeight.value;
          fixed.value = props.offset > rootTop.value && targetRect.bottom.value > 0;
          transform.value = difference < 0 ? difference : 0;
        } else {
          fixed.value = props.offset > rootTop.value;
        }
      } else if (props.target) {
        const difference = windowHeight.value - targetRect.top.value - props.offset - rootHeight.value;
        fixed.value = windowHeight.value - props.offset < rootBottom.value && windowHeight.value > targetRect.top.value;
        transform.value = difference < 0 ? -difference : 0;
      } else {
        fixed.value = windowHeight.value - props.offset < rootBottom.value;
      }
    };
    const handleScroll = () => {
      updateRoot();
      emit("scroll", {
        scrollTop: scrollTop.value,
        fixed: fixed.value
      });
    };
    watch(fixed, (val) => emit("change", val));
    useEventListener(scrollContainer, "scroll", handleScroll);
    watchEffect(update);
    expose({
      update,
      updateRoot
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        ref_key: "root",
        ref: root,
        class: normalizeClass(unref(ns).b()),
        style: normalizeStyle(unref(rootStyle))
      }, [
        createElementVNode("div", {
          class: normalizeClass({ [unref(ns).m("fixed")]: fixed.value }),
          style: normalizeStyle(unref(affixStyle))
        }, [
          renderSlot(_ctx.$slots, "default")
        ], 6)
      ], 6);
    };
  }
});
var Affix = /* @__PURE__ */ _export_sfc$1(_sfc_main$6, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/affix/src/affix.vue"]]);
const ElAffix = withInstall(Affix);
const _sfc_main$5 = /* @__PURE__ */ defineComponent({
  __name: "Search",
  __ssrInlineRender: true,
  props: {
    modelValue: {},
    isChange: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    useRouter();
    const instance = getCurrentInstance();
    const word = computed({
      get() {
        return props.modelValue;
      },
      set(v) {
        instance == null ? void 0 : instance.emit("update:modelValue", v);
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ElInput = ElInput;
      _push(ssrRenderComponent(_component_ElInput, mergeProps({
        type: "text",
        clearable: "",
        "prefix-icon": "ElIconSearch" in _ctx ? _ctx.ElIconSearch : unref(search_default),
        modelValue: unref(word),
        "onUpdate:modelValue": ($event) => isRef(word) ? word.value = $event : null,
        placeholder: " \u641C \u4E00 \u641C ",
        class: "v-input mx-1"
      }, _attrs), null, _parent));
    };
  }
});
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/input/Search.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_2$1 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["__scopeId", "data-v-05141f2d"]]);
const _sfc_main$4 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ "flex-row-c-c": "" }, _attrs))}><i inline-block align-middle i="dark:carbon-moon solar-sun-2-bold"></i></div>`);
}
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/other/MoonSun.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["ssrRender", _sfc_ssrRender$1]]);
const useColorMode = () => {
  return useState("color-mode").value;
};
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "Switch",
  __ssrInlineRender: true,
  setup(__props) {
    const mode = useColorMode();
    const isDark = computed({
      get() {
        return mode.value === "dark";
      },
      set() {
        mode.preference = isDark.value ? "light" : "dark";
      }
    });
    let toggle = (event) => {
      let isAppearanceTransition = document.startViewTransition && !window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      if (!isAppearanceTransition || !event) {
        isDark.value = !isDark.value;
        return null;
      }
      const x = event.clientX;
      const y = event.clientY;
      const endRadius = Math.hypot(
        Math.max(x, innerWidth - x),
        Math.max(y, innerHeight - y)
      );
      const transition = document.startViewTransition(() => {
        isDark.value = !isDark.value;
      });
      transition.ready.then(() => {
        const clipPath = [
          `circle(0px at ${x}px ${y}px)`,
          `circle(${endRadius}px at ${x}px ${y}px)`
        ];
        document.documentElement.animate(
          {
            clipPath: isDark.value ? clipPath : [...clipPath].reverse()
          },
          {
            duration: 300,
            easing: "ease-in",
            pseudoElement: isDark.value ? "::view-transition-new(root)" : "::view-transition-old(root)"
          }
        );
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ElButton = ElButton;
      const _component_ClientOnly = __nuxt_component_0$2;
      const _component_OtherMoonSun = __nuxt_component_2;
      _push(ssrRenderComponent(_component_ElButton, mergeProps({
        onClick: unref(toggle),
        class: "btn",
        "mx-3": "",
        round: ""
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_OtherMoonSun, null, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_ClientOnly, null, {
                default: withCtx(() => [
                  createVNode("span", null, toDisplayString(unref(isDark) ? "\u5207\u6362\u65E5\u95F4" : "\u5207\u6362\u591C\u95F4"), 1)
                ]),
                _: 1
              }),
              createVNode(_component_OtherMoonSun)
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/btn/Switch.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-3f1fbf91"]]);
const _imports_0 = "" + buildAssetsURL("logo.f2f3cfb9.png");
const _imports_1 = "" + buildAssetsURL("logo_dark.692df090.png");
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "HeaderMenu",
  __ssrInlineRender: true,
  setup(__props) {
    useUserStore();
    let searchWord = ref("");
    ref(false);
    const store = useUserStore();
    const onLogin = (type) => {
      if (type === 0) {
        store.showLoginForm = true;
        store.showRegisterForm = false;
      } else {
        store.showLoginForm = false;
        store.showRegisterForm = true;
      }
    };
    const onSerch = (val) => {
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ElAffix = ElAffix;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_InputSearch = __nuxt_component_2$1;
      const _component_BtnSwitch = __nuxt_component_3;
      const _component_ElButton = ElButton;
      const _component_ClientOnly = __nuxt_component_0$2;
      _push(`<div${ssrRenderAttrs(mergeProps({ "shadow-md": "" }, _attrs))} data-v-058b113d>`);
      _push(ssrRenderComponent(_component_ElAffix, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="nav un-select" flex-row-bt-c py-4 px-6 text-m dark:text="light" data-v-058b113d${_scopeId}><div class="left" flex-row-c-c data-v-058b113d${_scopeId}>`);
            _push2(ssrRenderComponent(_component_NuxtLink, {
              "mx-2": "",
              to: "/",
              "flex-row-c-c": "",
              class: "group"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<img w-42px object-contain group-hover:opacity-85 transition-300 group-hover:filter-blur-2px${ssrRenderAttr("src", _imports_0)} dark:hidden data-v-058b113d${_scopeId2}><img w-42px object-contain group-hover:opacity-85 transition-300 group-hover:filter-blur-2px${ssrRenderAttr("src", _imports_1)} hidden dark:block data-v-058b113d${_scopeId2}><span transition-300 group-hover:block hidden w-32px h-32px i-solar:home-2-bold absolute left-9 style="${ssrRenderStyle({ "color": "var(--el-text-color-primary)" })}" data-v-058b113d${_scopeId2}></span><span tracking-2 m-4 font-700 text-xl hidden md:inline-block data-v-058b113d${_scopeId2}>\u6781\u7269\u5708</span>`);
                } else {
                  return [
                    createVNode("img", {
                      "w-42px": "",
                      "object-contain": "",
                      "group-hover:opacity-85": "",
                      "transition-300": "",
                      "group-hover:filter-blur-2px": "",
                      src: _imports_0,
                      "dark:hidden": ""
                    }),
                    createVNode("img", {
                      "w-42px": "",
                      "object-contain": "",
                      "group-hover:opacity-85": "",
                      "transition-300": "",
                      "group-hover:filter-blur-2px": "",
                      src: _imports_1,
                      hidden: "",
                      "dark:block": ""
                    }),
                    createVNode("span", {
                      "transition-300": "",
                      "group-hover:block": "",
                      hidden: "",
                      "w-32px": "",
                      "h-32px": "",
                      "i-solar:home-2-bold": "",
                      absolute: "",
                      "left-9": "",
                      style: { "color": "var(--el-text-color-primary)" }
                    }),
                    createVNode("span", {
                      "tracking-2": "",
                      "m-4": "",
                      "font-700": "",
                      "text-xl": "",
                      hidden: "",
                      "md:inline-block": ""
                    }, "\u6781\u7269\u5708")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="right" flex-row-c-c hidden md:flex data-v-058b113d${_scopeId}><div data-v-058b113d${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputSearch, {
              modelValue: unref(searchWord),
              "onUpdate:modelValue": ($event) => isRef(searchWord) ? searchWord.value = $event : searchWord = $event,
              onSerch
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_component_BtnSwitch, null, null, _parent2, _scopeId));
            if (!unref(store).isLogin) {
              _push2(`<div class="box" data-v-058b113d${_scopeId}><span text-1em px-2 mx-1 cursor-pointer data-v-058b113d${_scopeId}>\u767B \u5F55</span>`);
              _push2(ssrRenderComponent(_component_ElButton, {
                style: { "border-radius": "30px" },
                "px-2": "",
                "mx-1": "",
                "cursor-pointer": "",
                onClick: ($event) => onLogin(
                  1
                  /* REGISTER */
                )
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`\u6CE8 \u518C `);
                  } else {
                    return [
                      createTextVNode("\u6CE8 \u518C ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(ssrRenderComponent(_component_ClientOnly, { class: "box" }, {}, _parent2, _scopeId));
            }
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", {
                class: "nav un-select",
                "flex-row-bt-c": "",
                "py-4": "",
                "px-6": "",
                "text-m": "",
                "dark:text": "light"
              }, [
                createVNode("div", {
                  class: "left",
                  "flex-row-c-c": ""
                }, [
                  createVNode(_component_NuxtLink, {
                    "mx-2": "",
                    to: "/",
                    "flex-row-c-c": "",
                    class: "group"
                  }, {
                    default: withCtx(() => [
                      createVNode("img", {
                        "w-42px": "",
                        "object-contain": "",
                        "group-hover:opacity-85": "",
                        "transition-300": "",
                        "group-hover:filter-blur-2px": "",
                        src: _imports_0,
                        "dark:hidden": ""
                      }),
                      createVNode("img", {
                        "w-42px": "",
                        "object-contain": "",
                        "group-hover:opacity-85": "",
                        "transition-300": "",
                        "group-hover:filter-blur-2px": "",
                        src: _imports_1,
                        hidden: "",
                        "dark:block": ""
                      }),
                      createVNode("span", {
                        "transition-300": "",
                        "group-hover:block": "",
                        hidden: "",
                        "w-32px": "",
                        "h-32px": "",
                        "i-solar:home-2-bold": "",
                        absolute: "",
                        "left-9": "",
                        style: { "color": "var(--el-text-color-primary)" }
                      }),
                      createVNode("span", {
                        "tracking-2": "",
                        "m-4": "",
                        "font-700": "",
                        "text-xl": "",
                        hidden: "",
                        "md:inline-block": ""
                      }, "\u6781\u7269\u5708")
                    ]),
                    _: 1
                  })
                ]),
                createVNode("div", {
                  class: "right",
                  "flex-row-c-c": "",
                  hidden: "",
                  "md:flex": ""
                }, [
                  createVNode("div", null, [
                    createVNode(_component_InputSearch, {
                      modelValue: unref(searchWord),
                      "onUpdate:modelValue": ($event) => isRef(searchWord) ? searchWord.value = $event : searchWord = $event,
                      onSerch
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  createVNode(_component_BtnSwitch),
                  !unref(store).isLogin ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "box"
                  }, [
                    createVNode("span", {
                      "text-1em": "",
                      "px-2": "",
                      "mx-1": "",
                      "cursor-pointer": "",
                      onClick: ($event) => onLogin(
                        0
                        /* LOGIN */
                      )
                    }, "\u767B \u5F55", 8, ["onClick"]),
                    createVNode(_component_ElButton, {
                      style: { "border-radius": "30px" },
                      "px-2": "",
                      "mx-1": "",
                      "cursor-pointer": "",
                      onClick: ($event) => onLogin(
                        1
                        /* REGISTER */
                      )
                    }, {
                      default: withCtx(() => [
                        createTextVNode("\u6CE8 \u518C ")
                      ]),
                      _: 1
                    }, 8, ["onClick"])
                  ])) : (openBlock(), createBlock(_component_ClientOnly, {
                    key: 1,
                    class: "box"
                  }, {
                    default: withCtx(() => {
                      var _a;
                      return [
                        createTextVNode(toDisplayString((_a = unref(store).userInfo) == null ? void 0 : _a.nickname), 1)
                      ];
                    }),
                    _: 1
                  }))
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/menu/HeaderMenu.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-058b113d"]]);
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "DrawerMenu",
  __ssrInlineRender: true,
  setup(__props) {
    useStorage("jiwu_isFold", true);
    useRoute();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ClientOnly = __nuxt_component_0$2;
      _push(ssrRenderComponent(_component_ClientOnly, _attrs, {}, _parent));
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/menu/DrawerMenu.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-16798803"]]);
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_MenuHeaderMenu = __nuxt_component_0;
  const _component_MenuDrawerMenu = __nuxt_component_1;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "defalut" }, _attrs))}>`);
  _push(ssrRenderComponent(_component_MenuHeaderMenu, null, null, _parent));
  _push(`<div flex>`);
  _push(ssrRenderComponent(_component_MenuDrawerMenu, null, null, _parent));
  ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
  _push(`</div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/default.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _default = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { _default as default };
//# sourceMappingURL=default-049dc212.mjs.map
