import { _ as __nuxt_component_0 } from './layout-9cd450dc.mjs';
import { d as buildProps, o as useSizeProp, i as isNumber, f as useNamespace, a2 as useFormItem, V as isUndefined, r as useFormSize, ae as useFormDisabled, h as ElIcon, a6 as arrow_down_default, af as minus_default, ag as arrow_up_default, T as plus_default, a4 as ElInput, w as withInstall, _ as _export_sfc, C as CHANGE_EVENT, ad as INPUT_EVENT, U as UPDATE_MODEL_EVENT, M as throwError, K as debugWarn, g as _export_sfc$1, D as useShopStore, B as useUserStore, ah as updateShopcart, S as StatusCode, a9 as ElMessage, u as useRouter, b as useHead, x as __nuxt_component_1$2, aa as vLoading, ai as getUserShopCartPage, ab as toReactive, aj as deleteBatchShopcartByIds, Y as useOrderStore, E as ElButton } from '../server.mjs';
import { a as ElCheckboxGroup, E as ElCheckbox } from './checkbox-e403f4c1.mjs';
import { defineComponent, ref, reactive, computed, watch, onUpdated, openBlock, createElementBlock, normalizeClass, unref, withModifiers, withDirectives, withKeys, createVNode, withCtx, createBlock, createCommentVNode, useSSRContext, toRaw, mergeProps, resolveDirective, toDisplayString, createTextVNode, isRef, TransitionGroup, Fragment, renderList, nextTick } from 'vue';
import { isNil, throttle } from 'lodash-unified';
import { u as useLocale } from './index-5453207f.mjs';
import { isFunction, isString } from '@vue/shared';
import { E as ElMessageBox } from './checkbox-group-e34a053d.mjs';
import { ssrRenderAttrs, ssrGetDirectiveProps, ssrRenderComponent, ssrRenderStyle, ssrInterpolate, ssrRenderSlot } from 'vue/server-renderer';
import currency from 'currency.js';
import 'vue-router';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'destr';
import 'h3';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'ufo';
import 'cookie-es';
import 'ohash';
import 'pinia-plugin-persistedstate';
import 'gsap';
import 'nprogress';
import '@kangc/v-md-editor';
import 'async-validator';
import '@ctrl/tinycolor';
import 'defu';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'klona';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

const getOffsetTop = (el) => {
  let offset = 0;
  let parent = el;
  while (parent) {
    offset += parent.offsetTop;
    parent = parent.offsetParent;
  }
  return offset;
};
const getOffsetTopDistance = (el, containerEl) => {
  return Math.abs(getOffsetTop(el) - getOffsetTop(containerEl));
};
const getScrollContainer = (el, isVertical) => {
  return;
};
const REPEAT_INTERVAL = 100;
const REPEAT_DELAY = 600;
const vRepeatClick = {
  beforeMount(el, binding) {
    const value = binding.value;
    const { interval = REPEAT_INTERVAL, delay = REPEAT_DELAY } = isFunction(value) ? {} : value;
    let intervalId;
    let delayId;
    const handler = () => isFunction(value) ? value() : value.handler();
    const clear = () => {
      if (delayId) {
        clearTimeout(delayId);
        delayId = void 0;
      }
      if (intervalId) {
        clearInterval(intervalId);
        intervalId = void 0;
      }
    };
    el.addEventListener("mousedown", (evt) => {
      if (evt.button !== 0)
        return;
      clear();
      handler();
      document.addEventListener("mouseup", () => clear(), {
        once: true
      });
      delayId = setTimeout(() => {
        intervalId = setInterval(() => {
          handler();
        }, interval);
      }, delay);
    });
  }
};
const inputNumberProps = buildProps({
  id: {
    type: String,
    default: void 0
  },
  step: {
    type: Number,
    default: 1
  },
  stepStrictly: Boolean,
  max: {
    type: Number,
    default: Number.POSITIVE_INFINITY
  },
  min: {
    type: Number,
    default: Number.NEGATIVE_INFINITY
  },
  modelValue: Number,
  readonly: Boolean,
  disabled: Boolean,
  size: useSizeProp,
  controls: {
    type: Boolean,
    default: true
  },
  controlsPosition: {
    type: String,
    default: "",
    values: ["", "right"]
  },
  valueOnClear: {
    type: [String, Number, null],
    validator: (val) => val === null || isNumber(val) || ["min", "max"].includes(val),
    default: null
  },
  name: String,
  label: String,
  placeholder: String,
  precision: {
    type: Number,
    validator: (val) => val >= 0 && val === Number.parseInt(`${val}`, 10)
  },
  validateEvent: {
    type: Boolean,
    default: true
  }
});
const inputNumberEmits = {
  [CHANGE_EVENT]: (cur, prev) => prev !== cur,
  blur: (e) => e instanceof FocusEvent,
  focus: (e) => e instanceof FocusEvent,
  [INPUT_EVENT]: (val) => isNumber(val) || isNil(val),
  [UPDATE_MODEL_EVENT]: (val) => isNumber(val) || isNil(val)
};
const _hoisted_1 = ["aria-label", "onKeydown"];
const _hoisted_2 = ["aria-label", "onKeydown"];
const __default__ = /* @__PURE__ */ defineComponent({
  name: "ElInputNumber"
});
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  ...__default__,
  props: inputNumberProps,
  emits: inputNumberEmits,
  setup(__props, { expose, emit }) {
    const props = __props;
    const { t } = useLocale();
    const ns = useNamespace("input-number");
    const input = ref();
    const data = reactive({
      currentValue: props.modelValue,
      userInput: null
    });
    const { formItem } = useFormItem();
    const minDisabled = computed(() => isNumber(props.modelValue) && props.modelValue <= props.min);
    const maxDisabled = computed(() => isNumber(props.modelValue) && props.modelValue >= props.max);
    const numPrecision = computed(() => {
      const stepPrecision = getPrecision(props.step);
      if (!isUndefined(props.precision)) {
        if (stepPrecision > props.precision) ;
        return props.precision;
      } else {
        return Math.max(getPrecision(props.modelValue), stepPrecision);
      }
    });
    const controlsAtRight = computed(() => {
      return props.controls && props.controlsPosition === "right";
    });
    const inputNumberSize = useFormSize();
    const inputNumberDisabled = useFormDisabled();
    const displayValue = computed(() => {
      if (data.userInput !== null) {
        return data.userInput;
      }
      let currentValue = data.currentValue;
      if (isNil(currentValue))
        return "";
      if (isNumber(currentValue)) {
        if (Number.isNaN(currentValue))
          return "";
        if (!isUndefined(props.precision)) {
          currentValue = currentValue.toFixed(props.precision);
        }
      }
      return currentValue;
    });
    const toPrecision = (num, pre) => {
      if (isUndefined(pre))
        pre = numPrecision.value;
      if (pre === 0)
        return Math.round(num);
      let snum = String(num);
      const pointPos = snum.indexOf(".");
      if (pointPos === -1)
        return num;
      const nums = snum.replace(".", "").split("");
      const datum = nums[pointPos + pre];
      if (!datum)
        return num;
      const length = snum.length;
      if (snum.charAt(length - 1) === "5") {
        snum = `${snum.slice(0, Math.max(0, length - 1))}6`;
      }
      return Number.parseFloat(Number(snum).toFixed(pre));
    };
    const getPrecision = (value) => {
      if (isNil(value))
        return 0;
      const valueString = value.toString();
      const dotPosition = valueString.indexOf(".");
      let precision = 0;
      if (dotPosition !== -1) {
        precision = valueString.length - dotPosition - 1;
      }
      return precision;
    };
    const ensurePrecision = (val, coefficient = 1) => {
      if (!isNumber(val))
        return data.currentValue;
      return toPrecision(val + props.step * coefficient);
    };
    const increase = () => {
      if (props.readonly || inputNumberDisabled.value || maxDisabled.value)
        return;
      const value = Number(displayValue.value) || 0;
      const newVal = ensurePrecision(value);
      setCurrentValue(newVal);
      emit(INPUT_EVENT, data.currentValue);
    };
    const decrease = () => {
      if (props.readonly || inputNumberDisabled.value || minDisabled.value)
        return;
      const value = Number(displayValue.value) || 0;
      const newVal = ensurePrecision(value, -1);
      setCurrentValue(newVal);
      emit(INPUT_EVENT, data.currentValue);
    };
    const verifyValue = (value, update) => {
      const { max, min, step, precision, stepStrictly, valueOnClear } = props;
      if (max < min) {
        throwError("InputNumber", "min should not be greater than max.");
      }
      let newVal = Number(value);
      if (isNil(value) || Number.isNaN(newVal)) {
        return null;
      }
      if (value === "") {
        if (valueOnClear === null) {
          return null;
        }
        newVal = isString(valueOnClear) ? { min, max }[valueOnClear] : valueOnClear;
      }
      if (stepStrictly) {
        newVal = toPrecision(Math.round(newVal / step) * step, precision);
      }
      if (!isUndefined(precision)) {
        newVal = toPrecision(newVal, precision);
      }
      if (newVal > max || newVal < min) {
        newVal = newVal > max ? max : min;
        update && emit(UPDATE_MODEL_EVENT, newVal);
      }
      return newVal;
    };
    const setCurrentValue = (value, emitChange = true) => {
      var _a;
      const oldVal = data.currentValue;
      const newVal = verifyValue(value);
      if (!emitChange) {
        emit(UPDATE_MODEL_EVENT, newVal);
        return;
      }
      if (oldVal === newVal)
        return;
      data.userInput = null;
      emit(UPDATE_MODEL_EVENT, newVal);
      emit(CHANGE_EVENT, newVal, oldVal);
      if (props.validateEvent) {
        (_a = formItem == null ? void 0 : formItem.validate) == null ? void 0 : _a.call(formItem, "change").catch((err) => debugWarn());
      }
      data.currentValue = newVal;
    };
    const handleInput = (value) => {
      data.userInput = value;
      const newVal = value === "" ? null : Number(value);
      emit(INPUT_EVENT, newVal);
      setCurrentValue(newVal, false);
    };
    const handleInputChange = (value) => {
      const newVal = value !== "" ? Number(value) : "";
      if (isNumber(newVal) && !Number.isNaN(newVal) || value === "") {
        setCurrentValue(newVal);
      }
      data.userInput = null;
    };
    const focus = () => {
      var _a, _b;
      (_b = (_a = input.value) == null ? void 0 : _a.focus) == null ? void 0 : _b.call(_a);
    };
    const blur = () => {
      var _a, _b;
      (_b = (_a = input.value) == null ? void 0 : _a.blur) == null ? void 0 : _b.call(_a);
    };
    const handleFocus = (event) => {
      emit("focus", event);
    };
    const handleBlur = (event) => {
      var _a;
      emit("blur", event);
      if (props.validateEvent) {
        (_a = formItem == null ? void 0 : formItem.validate) == null ? void 0 : _a.call(formItem, "blur").catch((err) => debugWarn());
      }
    };
    watch(() => props.modelValue, (value) => {
      const userInput = verifyValue(data.userInput);
      const newValue = verifyValue(value, true);
      if (!isNumber(userInput) && (!userInput || userInput !== newValue)) {
        data.currentValue = newValue;
        data.userInput = null;
      }
    }, { immediate: true });
    onUpdated(() => {
      var _a;
      const innerInput = (_a = input.value) == null ? void 0 : _a.input;
      innerInput == null ? void 0 : innerInput.setAttribute("aria-valuenow", `${data.currentValue}`);
    });
    expose({
      focus,
      blur
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass([
          unref(ns).b(),
          unref(ns).m(unref(inputNumberSize)),
          unref(ns).is("disabled", unref(inputNumberDisabled)),
          unref(ns).is("without-controls", !_ctx.controls),
          unref(ns).is("controls-right", unref(controlsAtRight))
        ]),
        onDragstart: _cache[1] || (_cache[1] = withModifiers(() => {
        }, ["prevent"]))
      }, [
        _ctx.controls ? withDirectives((openBlock(), createElementBlock("span", {
          key: 0,
          role: "button",
          "aria-label": unref(t)("el.inputNumber.decrease"),
          class: normalizeClass([unref(ns).e("decrease"), unref(ns).is("disabled", unref(minDisabled))]),
          onKeydown: withKeys(decrease, ["enter"])
        }, [
          createVNode(unref(ElIcon), null, {
            default: withCtx(() => [
              unref(controlsAtRight) ? (openBlock(), createBlock(unref(arrow_down_default), { key: 0 })) : (openBlock(), createBlock(unref(minus_default), { key: 1 }))
            ]),
            _: 1
          })
        ], 42, _hoisted_1)), [
          [unref(vRepeatClick), decrease]
        ]) : createCommentVNode("v-if", true),
        _ctx.controls ? withDirectives((openBlock(), createElementBlock("span", {
          key: 1,
          role: "button",
          "aria-label": unref(t)("el.inputNumber.increase"),
          class: normalizeClass([unref(ns).e("increase"), unref(ns).is("disabled", unref(maxDisabled))]),
          onKeydown: withKeys(increase, ["enter"])
        }, [
          createVNode(unref(ElIcon), null, {
            default: withCtx(() => [
              unref(controlsAtRight) ? (openBlock(), createBlock(unref(arrow_up_default), { key: 0 })) : (openBlock(), createBlock(unref(plus_default), { key: 1 }))
            ]),
            _: 1
          })
        ], 42, _hoisted_2)), [
          [unref(vRepeatClick), increase]
        ]) : createCommentVNode("v-if", true),
        createVNode(unref(ElInput), {
          id: _ctx.id,
          ref_key: "input",
          ref: input,
          type: "number",
          step: _ctx.step,
          "model-value": unref(displayValue),
          placeholder: _ctx.placeholder,
          readonly: _ctx.readonly,
          disabled: unref(inputNumberDisabled),
          size: unref(inputNumberSize),
          max: _ctx.max,
          min: _ctx.min,
          name: _ctx.name,
          label: _ctx.label,
          "validate-event": false,
          onWheel: _cache[0] || (_cache[0] = withModifiers(() => {
          }, ["prevent"])),
          onKeydown: [
            withKeys(withModifiers(increase, ["prevent"]), ["up"]),
            withKeys(withModifiers(decrease, ["prevent"]), ["down"])
          ],
          onBlur: handleBlur,
          onFocus: handleFocus,
          onInput: handleInput,
          onChange: handleInputChange
        }, null, 8, ["id", "step", "model-value", "placeholder", "readonly", "disabled", "size", "max", "min", "name", "label", "onKeydown"])
      ], 34);
    };
  }
});
var InputNumber = /* @__PURE__ */ _export_sfc$1(_sfc_main$2, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/input-number/src/input-number.vue"]]);
const ElInputNumber = withInstall(InputNumber);
const SCOPE = "ElInfiniteScroll";
const CHECK_INTERVAL = 50;
const DEFAULT_DELAY = 200;
const DEFAULT_DISTANCE = 0;
const attributes = {
  delay: {
    type: Number,
    default: DEFAULT_DELAY
  },
  distance: {
    type: Number,
    default: DEFAULT_DISTANCE
  },
  disabled: {
    type: Boolean,
    default: false
  },
  immediate: {
    type: Boolean,
    default: true
  }
};
const getScrollOptions = (el, instance) => {
  return Object.entries(attributes).reduce((acm, [name, option]) => {
    var _a, _b;
    const { type, default: defaultValue } = option;
    const attrVal = el.getAttribute(`infinite-scroll-${name}`);
    let value = (_b = (_a = instance[attrVal]) != null ? _a : attrVal) != null ? _b : defaultValue;
    value = value === "false" ? false : value;
    value = type(value);
    acm[name] = Number.isNaN(value) ? defaultValue : value;
    return acm;
  }, {});
};
const destroyObserver = (el) => {
  const { observer } = el[SCOPE];
  if (observer) {
    observer.disconnect();
    delete el[SCOPE].observer;
  }
};
const handleScroll = (el, cb) => {
  const { container, containerEl, instance, observer, lastScrollTop } = el[SCOPE];
  const { disabled, distance } = getScrollOptions(el, instance);
  const { clientHeight, scrollHeight, scrollTop } = containerEl;
  const delta = scrollTop - lastScrollTop;
  el[SCOPE].lastScrollTop = scrollTop;
  if (observer || disabled || delta < 0)
    return;
  let shouldTrigger = false;
  if (container === el) {
    shouldTrigger = scrollHeight - (clientHeight + scrollTop) <= distance;
  } else {
    const { clientTop, scrollHeight: height } = el;
    const offsetTop = getOffsetTopDistance(el, containerEl);
    shouldTrigger = scrollTop + clientHeight >= offsetTop + clientTop + height - distance;
  }
  if (shouldTrigger) {
    cb.call(instance);
  }
};
function checkFull(el, cb) {
  const { containerEl, instance } = el[SCOPE];
  const { disabled } = getScrollOptions(el, instance);
  if (disabled || containerEl.clientHeight === 0)
    return;
  if (containerEl.scrollHeight <= containerEl.clientHeight) {
    cb.call(instance);
  } else {
    destroyObserver(el);
  }
}
const InfiniteScroll = {
  async mounted(el, binding) {
    const { instance, value: cb } = binding;
    if (!isFunction(cb)) {
      throwError(SCOPE, "'v-infinite-scroll' binding value must be a function");
    }
    await nextTick();
    const { delay, immediate } = getScrollOptions(el, instance);
    const container = getScrollContainer();
    const containerEl = container === window ? document.documentElement : container;
    const onScroll = throttle(handleScroll.bind(null, el, cb), delay);
    if (!container)
      return;
    el[SCOPE] = {
      instance,
      container,
      containerEl,
      delay,
      cb,
      onScroll,
      lastScrollTop: containerEl.scrollTop
    };
    if (immediate) {
      const observer = new MutationObserver(throttle(checkFull.bind(null, el, cb), CHECK_INTERVAL));
      el[SCOPE].observer = observer;
      observer.observe(el, { childList: true, subtree: true });
      checkFull(el, cb);
    }
    container.addEventListener("scroll", onScroll);
  },
  unmounted(el) {
    const { container, onScroll } = el[SCOPE];
    container == null ? void 0 : container.removeEventListener("scroll", onScroll);
    destroyObserver(el);
  },
  async updated(el) {
    if (!el[SCOPE]) {
      await nextTick();
    } else {
      const { containerEl, cb, observer } = el[SCOPE];
      if (containerEl.clientHeight && observer) {
        checkFull(el, cb);
      }
    }
  }
};
const _InfiniteScroll = InfiniteScroll;
_InfiniteScroll.install = (app) => {
  app.directive("InfiniteScroll", _InfiniteScroll);
};
const ElInfiniteScroll = _InfiniteScroll;
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "ShopLine",
  __ssrInlineRender: true,
  props: {
    shopCart: {}
  },
  setup(__props) {
    const { shopCart } = __props;
    useShopStore();
    const user = useUserStore();
    const isUpdateLoading = ref(false);
    ref(true);
    const skuList = ref([]);
    const selectShopcartId = ref(shopCart.id);
    watch(
      shopCart,
      (vo) => {
        changeUpdateShopcart(vo.skuId, vo.quantity);
      },
      { deep: true }
    );
    const changeUpdateShopcart = async (skuId, quantity) => {
      if (isUpdateLoading.value || !quantity)
        return;
      isUpdateLoading.value = true;
      const data = await updateShopcart(
        selectShopcartId.value,
        {
          skuId,
          quantity
        },
        user.getToken
      );
      if (data.code != StatusCode.SUCCESS) {
        ElMessage.closeAll();
        ElMessage.error("\u4FEE\u6539\u5931\u8D25\uFF0C\u7A0D\u540E\u91CD\u8BD5\uFF01");
      } else {
        shopCart.skuId = skuId;
        shopCart.quantity = quantity;
      }
      const timer = setTimeout(() => {
        isUpdateLoading.value = false;
        clearTimeout(timer);
      }, 300);
    };
    ref(
      (shopCart.size || "") + " " + (shopCart.color || "") + " " + (shopCart.combo || "")
    );
    computed({
      get() {
        return (shopCart.size || "") + " " + (shopCart.color || "") + " " + (shopCart.combo || "");
      },
      set(skuId) {
        const p = toRaw(skuList.value.find((p2) => p2.id === skuId));
        if (p && p.size && p.color && p.combo) {
          shopCart.size = p.size;
          shopCart.image = p.image;
          shopCart.price = p.price;
          shopCart.costPrice = p.costPrice;
          shopCart.color = p.color;
          shopCart.combo = p.combo;
          shopCart.skuId = skuId;
        }
      }
    });
    useRouter();
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_ClientOnly = __nuxt_component_1$2;
      const _component_el_input_number = ElInputNumber;
      const _directive_loading = vLoading;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "card group",
        "flex-row-bt-c": "",
        "cursor-pointer": "",
        "p-4": "",
        "rounded-6px": "",
        "mt-2": "",
        "mb-3": "",
        "transition-300": "",
        "border-2px": "",
        "hover:shadow": "",
        "hover:border": "solid violet-6",
        "dark:hover:bg": "dark-1",
        "border-dashed": "",
        "border-default": ""
      }, _attrs, ssrGetDirectiveProps(_ctx, _directive_loading, unref(isUpdateLoading))))} data-v-ffc5366a>`);
      _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
      _push(`<div px-4 style="${ssrRenderStyle({ "width": "78%", "height": "100%" })}" group flex flex-col items-start justify-between data-v-ffc5366a><h3 tracking-1px max-w-12em md:max-w-16em class="overflow-hidden truncate ..." data-v-ffc5366a>${ssrInterpolate(_ctx.shopCart.name)}</h3><p font-700 color-red-6 mt-1 mb-5 data-v-ffc5366a> \uFFE5${ssrInterpolate((_a = _ctx.shopCart.price) == null ? void 0 : _a.toFixed(2))} <span color-coolgray text-0.6em style="${ssrRenderStyle({ "text-decoration": "line-through" })}" data-v-ffc5366a>\uFFE5${ssrInterpolate(_ctx.shopCart.costPrice.toFixed(2))}</span></p><p flex-row-bt-c class="w-1/1 mt-2" data-v-ffc5366a>`);
      _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
      _push(ssrRenderComponent(_component_el_input_number, {
        min: 1,
        max: 99,
        modelValue: _ctx.shopCart.quantity,
        "onUpdate:modelValue": ($event) => _ctx.shopCart.quantity = $event
      }, null, _parent));
      _push(`</p></div><div flex flex-col items-center flex-1 relative data-v-ffc5366a><span i-solar:trash-bin-minimalistic-bold-duotone p-3 dark:bg-light transition-300 absolute opacity-0 group-hover:opacity-80 style="${ssrRenderStyle({ "top": "-3em" })}" data-v-ffc5366a></span>`);
      ssrRenderSlot(_ctx.$slots, "btn", {}, null, _push, _parent);
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/card/ShopLine.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-ffc5366a"]]);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "\u6781\u7269 \u6211\u7684\u8D2D\u7269\u8F66",
      meta: [
        {
          name: "description",
          content: "\u6781\u7269\u5708-\u6211\u7684\u8D2D\u7269\u8F66"
        }
      ]
    });
    const shop = useShopStore();
    const user = useUserStore();
    const isLoading = ref(false);
    ref(false);
    const isNoMore = computed(() => {
      var _a;
      return shop.shopcartList.length === ((_a = shop.pageInfo) == null ? void 0 : _a.total);
    });
    const loadShopcartList = async () => {
      if (!user.isLogin || isLoading.value)
        return;
      if (shop.pageInfo.pages > 0 && shop.shopcartList.length < shop.pageInfo.total) {
        return;
      }
      isLoading.value = true;
      shop.page++;
      const { data } = await getUserShopCartPage(shop.page, shop.size, user.getToken);
      if (isNoMore.value || (data == null ? void 0 : data.total) === -1) {
        return isLoading.value = false;
      }
      shop.pageInfo = toReactive({ ...data });
      let timer;
      if (!(data == null ? void 0 : data.records))
        return;
      for await (const p of data.records) {
        await new Promise((resolve) => {
          timer = setTimeout(() => {
            shop.shopcartList.push(p);
            clearTimeout(timer ?? void 0);
            timer = null;
            isLoading.value = false;
            return resolve(true);
          }, 50);
        });
      }
    };
    const notMore = computed(() => {
      return shop.shopcartList.length >= shop.pageInfo.total || shop.pageInfo.current === shop.pageInfo.pages;
    });
    if (shop.shopcartList.length === 0) {
      loadShopcartList();
    }
    const isEdit = ref(false);
    const selectIds = ref([]);
    const deleteBatchShopcart = (text = "\u5220\u9664") => {
      ElMessageBox().then(async (res) => {
        if (res === "confirm") {
          const { code } = await deleteBatchShopcartByIds(selectIds.value, user.getToken);
          if (code === StatusCode.SUCCESS && shop.deleteBatchShopCart(selectIds.value)) {
            selectIds.value.splice(0);
            ElMessage.success(text + "\u6210\u529F\uFF01");
          } else {
            ElMessage.error("\u5220\u9664\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5\u8BD5\u770B\uFF01");
          }
        }
      }).catch((err) => {
      });
    };
    const clearShopcart = () => {
      selectIds.value.push(...shop.shopcartList.map((p) => p.id));
      deleteBatchShopcart("\u6E05\u7A7A");
    };
    const isSelectAll = ref(false);
    watch(isSelectAll, (val) => {
      selectIds.value.splice(0);
      if (val) {
        selectIds.value.push(...shop.shopcartList.map((p) => p.id));
      }
    });
    computed(() => {
      let count = 0;
      for (const p of shop.shopcartList) {
        count += p.quantity;
      }
      return count;
    });
    const toOrderPage = (ids) => {
      const dtoList = [];
      shop.shopcartList.map((p) => {
        if (ids.includes(p.id)) {
          const { skuId, quantity } = p;
          dtoList.push({ skuId, quantity });
        }
      });
      const order = useOrderStore();
      order.$patch({
        pushOrderItems: dtoList
      });
      useRouter().push({
        path: "/order/pay"
      });
    };
    const getAllNums = ref(0);
    const getAllPrice = computed(() => {
      getAllNums.value = 0;
      const selectList = shop.shopcartList.filter((p) => selectIds.value.includes(p.id));
      let count = currency(0);
      selectList.forEach((p) => {
        getAllNums.value += p.quantity;
        count = count.add(currency(p.price).multiply(p.quantity));
      });
      return count;
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLayout = __nuxt_component_0;
      const _component_ClientOnly = __nuxt_component_1$2;
      const _component_el_checkbox_group = ElCheckboxGroup;
      const _component_CardShopLine = __nuxt_component_3;
      const _component_el_checkbox = ElCheckbox;
      const _component_el_button = ElButton;
      const _directive_infinite_scroll = ElInfiniteScroll;
      const _directive_incre_up = resolveDirective("incre-up");
      _push(ssrRenderComponent(_component_NuxtLayout, mergeProps({
        menu: ["back"],
        footer: false
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_ClientOnly, null, {
                default: withCtx(() => [
                  unref(user).isLogin ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "shopcart-list",
                    "border-default": "",
                    "rounded-t-10px": "",
                    "shadow-md": "",
                    "bg-white": "",
                    "dark:bg-dark": "",
                    "p-20px": "",
                    "min-h-95vh": "",
                    relative: "",
                    "mt-2em": "",
                    "mx-a": "",
                    "w-700px": ""
                  }, [
                    createVNode("h2", {
                      "mb-2": "",
                      "text-center": "",
                      "border-0": "",
                      "border-b-1": "",
                      "border-default": "",
                      "tracking-0.1em": "",
                      "pb-4": ""
                    }, [
                      createVNode("small", {
                        style: { "font-size": "0.8em", "padding-top": "0.2em", "position": "absolute", "right": "1em" },
                        "cursor-pointer": "",
                        "select-none": "",
                        onClick: ($event) => isEdit.value = !unref(isEdit),
                        plain: !unref(isEdit),
                        class: "transition-300",
                        "text-green-5": ""
                      }, toDisplayString(!unref(isEdit) ? "\u7BA1\u7406" : "\u53D6\u6D88"), 9, ["onClick", "plain"]),
                      createTextVNode(" \u8D2D\u7269\u8F66 ")
                    ]),
                    withDirectives((openBlock(), createBlock("div", {
                      "mb-2": "",
                      "infinite-scroll-delay": 1e3,
                      "infinite-scroll-disabled": unref(notMore),
                      style: { "overflow": "auto" }
                    }, [
                      createVNode(_component_el_checkbox_group, {
                        modelValue: unref(selectIds),
                        "onUpdate:modelValue": ($event) => isRef(selectIds) ? selectIds.value = $event : null,
                        size: "large",
                        class: "relative"
                      }, {
                        default: withCtx(() => [
                          createVNode(TransitionGroup, {
                            tag: "div",
                            name: "fade-list"
                          }, {
                            default: withCtx(() => [
                              (openBlock(true), createBlock(Fragment, null, renderList(unref(shop).shopcartList, (p, i) => {
                                return openBlock(), createBlock("li", {
                                  key: p.id
                                }, [
                                  createVNode(_component_CardShopLine, { "shop-cart": p }, {
                                    btn: withCtx(() => [
                                      createVNode(_component_el_checkbox, {
                                        label: p.id,
                                        disabled: !p.stock
                                      }, null, 8, ["label", "disabled"])
                                    ]),
                                    _: 2
                                  }, 1032, ["shop-cart"])
                                ]);
                              }), 128))
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["modelValue", "onUpdate:modelValue"])
                    ], 8, ["infinite-scroll-disabled"])), [
                      [_directive_infinite_scroll, loadShopcartList]
                    ]),
                    createVNode("div", { class: "bottom drop-blur-2em mb-0 w-660px mt-4em fixed bottom-4 h-4em px-4 flex justify-between items-center border-default rounded-10px animate-fade-in-up border-2px my-4 shadow-md bg-white dark-bg-dark-6 z-999" }, [
                      createVNode("div", {
                        absolute: "",
                        class: "-top-3em right-0",
                        "p-2": "",
                        "px-4": "",
                        "w-660px": "",
                        flex: "",
                        "items-end": "",
                        "justify-between": ""
                      }, [
                        createVNode("span", {
                          "float-left": "",
                          "p-1": ""
                        }, "\u5171\u8BA1 " + toDisplayString(unref(getAllNums)) + " \u4EF6", 1),
                        createVNode("div", {
                          flex: "",
                          "items-end": ""
                        }, [
                          createVNode("span", { "p-1": "" }, "\u603B\u8BA1\uFF1A\uFFE5"),
                          withDirectives(createVNode("h2", { "text-red-5": "" }, null, 512), [
                            [_directive_incre_up, unref(getAllPrice)]
                          ])
                        ])
                      ]),
                      createVNode(_component_el_checkbox, {
                        modelValue: unref(isSelectAll),
                        "onUpdate:modelValue": ($event) => isRef(isSelectAll) ? isSelectAll.value = $event : null,
                        size: "large",
                        label: "\u5168 \u9009"
                      }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                      createVNode("div", { flex: "" }, [
                        unref(isEdit) && unref(selectIds).length ? (openBlock(), createBlock(_component_el_button, {
                          key: 0,
                          class: "fadeInOut flex-1",
                          style: { "padding": "0em 1em" },
                          type: "danger",
                          plain: "",
                          disabled: unref(selectIds).length === 0 && !unref(isEdit),
                          round: "",
                          onClick: ($event) => deleteBatchShopcart("\u6279\u91CF\u5220\u9664")
                        }, {
                          default: withCtx(() => [
                            createTextVNode("\u6279\u91CF\u5220\u9664 "),
                            createVNode("i", {
                              "i-solar:trash-bin-trash-broken": "",
                              "mr-1": ""
                            })
                          ]),
                          _: 1
                        }, 8, ["disabled", "onClick"])) : createCommentVNode("", true),
                        unref(isEdit) ? (openBlock(), createBlock(_component_el_button, {
                          key: 1,
                          class: "fadeInOut flex-1",
                          style: { "padding": "0em 1em" },
                          type: "danger",
                          plain: "",
                          disabled: !unref(isEdit),
                          round: "",
                          onClick: clearShopcart
                        }, {
                          default: withCtx(() => [
                            createVNode("i", {
                              "i-solar:trash-bin-trash-broken": "",
                              "mr-1": ""
                            }),
                            createTextVNode(" \u6E05\u7A7A ")
                          ]),
                          _: 1
                        }, 8, ["disabled"])) : createCommentVNode("", true),
                        createVNode(_component_el_button, {
                          class: "fadeInOut flex-1",
                          style: { "padding": "0em 2em" },
                          type: "info",
                          round: "",
                          disabled: unref(selectIds).length === 0,
                          onClick: ($event) => toOrderPage(unref(selectIds)),
                          "tracking-0.1em": ""
                        }, {
                          default: withCtx(() => [
                            createTextVNode("\u53BB\u7ED3\u7B97")
                          ]),
                          _: 1
                        }, 8, ["disabled", "onClick"])
                      ])
                    ])
                  ])) : createCommentVNode("", true)
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/shopcart/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-3d523d3d"]]);

export { index as default };
//# sourceMappingURL=index-c7e563b0.mjs.map
