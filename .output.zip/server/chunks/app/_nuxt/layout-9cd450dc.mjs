import { defineComponent, inject, computed, unref, Transition, h } from 'vue';
import { a as useRoute, aR as appLayoutTransition, aS as _wrapIf } from '../server.mjs';
import { useRoute as useRoute$1 } from 'vue-router';

const layouts = {
  default: () => import('./default-5f950aca.mjs').then((m) => m.default || m),
  error: () => import('./error-30f14533.mjs').then((m) => m.default || m),
  second: () => import('./second-d1ba3d24.mjs').then((m) => m.default || m),
  user: () => import('./user-3fc23c14.mjs').then((m) => m.default || m)
};
const LayoutLoader = /* @__PURE__ */ defineComponent({
  name: "LayoutLoader",
  inheritAttrs: false,
  props: {
    name: String,
    ...{}
  },
  async setup(props, context) {
    const LayoutComponent = await layouts[props.name]().then((r) => r.default || r);
    return () => {
      return h(LayoutComponent, context.attrs, context.slots);
    };
  }
});
const __nuxt_component_0 = /* @__PURE__ */ defineComponent({
  name: "NuxtLayout",
  inheritAttrs: false,
  props: {
    name: {
      type: [String, Boolean, Object],
      default: null
    }
  },
  setup(props, context) {
    const injectedRoute = inject("_route");
    const route = injectedRoute === useRoute() ? useRoute$1() : injectedRoute;
    const layout = computed(() => unref(props.name) ?? route.meta.layout ?? "default");
    return () => {
      const hasLayout = layout.value && layout.value in layouts;
      const transitionProps = route.meta.layoutTransition ?? appLayoutTransition;
      return _wrapIf(Transition, hasLayout && transitionProps, {
        default: () => _wrapIf(LayoutLoader, hasLayout && {
          key: layout.value,
          name: layout.value,
          ...{},
          ...context.attrs
        }, context.slots).default()
      }).default();
    };
  }
});

export { __nuxt_component_0 as _ };
//# sourceMappingURL=layout-9cd450dc.mjs.map
