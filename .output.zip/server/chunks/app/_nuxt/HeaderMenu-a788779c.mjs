import { _ as __nuxt_component_0$1 } from './nuxt-link-1d0a99ed.mjs';
import { _ as _export_sfc, u as useRouter, B as useUserStore, a4 as ElInput, x as __nuxt_component_1$2 } from '../server.mjs';
import { useSSRContext, defineComponent, getCurrentInstance, computed, unref, isRef, ref, mergeProps, withCtx, createVNode } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrRenderStyle } from 'vue/server-renderer';
import { _ as _imports_0, a as _imports_1 } from './logo_dark-b7cf3e36.mjs';

const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "Search",
  __ssrInlineRender: true,
  props: {
    modelValue: {},
    isChange: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    const router = useRouter();
    const instance = getCurrentInstance();
    const word = computed({
      get() {
        return props.modelValue;
      },
      set(v) {
        instance == null ? void 0 : instance.emit("update:modelValue", v);
      }
    });
    const onSearch = () => {
      router.push({
        path: `/search`,
        query: {
          name: word.value.trim()
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ElInput = ElInput;
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-1fc371dd>`);
      _push(ssrRenderComponent(_component_ElInput, {
        type: "text",
        onKeyup: onSearch,
        "text-center": "",
        clearable: "",
        modelValue: unref(word),
        "onUpdate:modelValue": ($event) => isRef(word) ? word.value = $event : null,
        placeholder: "\u5F00\u542F\u641C\u7D22\u4E4B\u65C5\u2728",
        class: "v-input mx-1"
      }, null, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/input/Search.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-1fc371dd"]]);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "HeaderMenu",
  __ssrInlineRender: true,
  props: {
    topClass: {}
  },
  setup(__props) {
    let searchWord = ref("");
    useUserStore();
    const onSerch = (val) => {
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_InputSearch = __nuxt_component_1;
      const _component_ClientOnly = __nuxt_component_1$2;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["nav un-select", _ctx.topClass],
        "flex-row-bt-c": "",
        "py-4": "",
        "px-6": "",
        "text-m": "",
        "dark:text": "light"
      }, _attrs))} data-v-1a8e2ef6><div class="left" flex-row-c-c group data-v-1a8e2ef6>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        "mx-2": "",
        to: "/",
        "flex-row-c-c": "",
        class: "group"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img w-42px object-contain group-hover:opacity-85 transition-300 group-hover:filter-blur-2px${ssrRenderAttr("src", _imports_0)} dark:hidden data-v-1a8e2ef6${_scopeId}><img w-42px object-contain group-hover:opacity-85 transition-300 group-hover:filter-blur-2px${ssrRenderAttr("src", _imports_1)} hidden dark:block data-v-1a8e2ef6${_scopeId}><span transition-300 group-hover:block hidden w-32px h-32px i-solar:home-2-bold absolute left-9 style="${ssrRenderStyle({ "color": "var(--el-text-color-primary)" })}" data-v-1a8e2ef6${_scopeId}></span><span tracking-2 m-4 font-700 text-xl hidden md:inline-block data-v-1a8e2ef6${_scopeId}>\u6781\u7269\u5708</span>`);
          } else {
            return [
              createVNode("img", {
                "w-42px": "",
                "object-contain": "",
                "group-hover:opacity-85": "",
                "transition-300": "",
                "group-hover:filter-blur-2px": "",
                src: _imports_0,
                "dark:hidden": ""
              }),
              createVNode("img", {
                "w-42px": "",
                "object-contain": "",
                "group-hover:opacity-85": "",
                "transition-300": "",
                "group-hover:filter-blur-2px": "",
                src: _imports_1,
                hidden: "",
                "dark:block": ""
              }),
              createVNode("span", {
                "transition-300": "",
                "group-hover:block": "",
                hidden: "",
                "w-32px": "",
                "h-32px": "",
                "i-solar:home-2-bold": "",
                absolute: "",
                "left-9": "",
                style: { "color": "var(--el-text-color-primary)" }
              }),
              createVNode("span", {
                "tracking-2": "",
                "m-4": "",
                "font-700": "",
                "text-xl": "",
                hidden: "",
                "md:inline-block": ""
              }, "\u6781\u7269\u5708")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="animate__animated input-search" data-v-1a8e2ef6>`);
      _push(ssrRenderComponent(_component_InputSearch, {
        modelValue: unref(searchWord),
        "onUpdate:modelValue": ($event) => isRef(searchWord) ? searchWord.value = $event : searchWord = $event,
        onSerch
      }, null, _parent));
      _push(`</div><div class="right" flex-row-c-c hidden md:flex data-v-1a8e2ef6>`);
      _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/menu/HeaderMenu.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-1a8e2ef6"]]);

export { __nuxt_component_0 as _ };
//# sourceMappingURL=HeaderMenu-a788779c.mjs.map
