import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_0 } from './layout-ac63d22b.mjs';
import { b as buildProps, g as definePropType, e as useNamespace, h as addUnit, j as useResizeObserver, f as useEventListener, w as withInstall, l as ElIcon, m as arrow_left_default, n as arrow_right_default, o as withNoopInstall, p as mutable, q as full_screen_default, s as scale_to_original_default, i as isNumber, r as close_default, z as zoom_out_default, v as zoom_in_default, x as refresh_left_default, y as refresh_right_default, B as useAttrs$1, D as picture_filled_default, d as _export_sfc$1, G as useNuxtApp, I as useUserStore, a as useRouter, K as useAsyncData, S as StatusCode, L as baseUrlImg, N as Sort, A as keysOf, F as request, H as __nuxt_component_0$2, J as useHttp, E as ElButton, M as picture_default, _ as _export_sfc, t as throwError } from '../server.mjs';
import { u as useStorage, t as toReactive } from './index-f1266410.mjs';
import { ref, defineComponent, computed, watch, nextTick, provide, reactive, onUpdated, openBlock, createElementBlock, normalizeClass, unref, createElementVNode, normalizeStyle, createBlock, resolveDynamicComponent, withCtx, renderSlot, createCommentVNode, withModifiers, Transition, withDirectives, createVNode, vShow, Fragment, renderList, toDisplayString, markRaw, effectScope, shallowRef, Teleport, useAttrs, mergeProps, toRef, normalizeProps, useSSRContext, inject, getCurrentInstance, onUnmounted, withAsyncContext, createTextVNode, isRef, isVNode } from 'vue';
import { ssrRenderComponent, ssrRenderAttrs, ssrRenderAttr, ssrRenderList, ssrRenderStyle, ssrInterpolate, ssrRenderSlot } from 'vue/server-renderer';
import { isObject, isString, isArray } from '@vue/shared';
import { throttle, get } from 'lodash-unified';
import { _ as __nuxt_component_0$1 } from './nuxt-link-e022643b.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'vue-router';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'cookie-es';
import 'pinia-plugin-persistedstate';
import 'nprogress';
import 'async-validator';
import '@ctrl/tinycolor';
import 'axios';
import 'lodash';

const flattedChildren = (children) => {
  const vNodes = isArray(children) ? children : [children];
  const result = [];
  vNodes.forEach((child) => {
    var _a;
    if (isArray(child)) {
      result.push(...flattedChildren(child));
    } else if (isVNode(child) && isArray(child.children)) {
      result.push(...flattedChildren(child.children));
    } else {
      result.push(child);
      if (isVNode(child) && ((_a = child.component) == null ? void 0 : _a.subTree)) {
        result.push(...flattedChildren(child.component.subTree));
      }
    }
  });
  return result;
};
var English = {
  name: "en",
  el: {
    colorpicker: {
      confirm: "OK",
      clear: "Clear",
      defaultLabel: "color picker",
      description: "current color is {color}. press enter to select a new color."
    },
    datepicker: {
      now: "Now",
      today: "Today",
      cancel: "Cancel",
      clear: "Clear",
      confirm: "OK",
      dateTablePrompt: "Use the arrow keys and enter to select the day of the month",
      monthTablePrompt: "Use the arrow keys and enter to select the month",
      yearTablePrompt: "Use the arrow keys and enter to select the year",
      selectedDate: "Selected date",
      selectDate: "Select date",
      selectTime: "Select time",
      startDate: "Start Date",
      startTime: "Start Time",
      endDate: "End Date",
      endTime: "End Time",
      prevYear: "Previous Year",
      nextYear: "Next Year",
      prevMonth: "Previous Month",
      nextMonth: "Next Month",
      year: "",
      month1: "January",
      month2: "February",
      month3: "March",
      month4: "April",
      month5: "May",
      month6: "June",
      month7: "July",
      month8: "August",
      month9: "September",
      month10: "October",
      month11: "November",
      month12: "December",
      week: "week",
      weeks: {
        sun: "Sun",
        mon: "Mon",
        tue: "Tue",
        wed: "Wed",
        thu: "Thu",
        fri: "Fri",
        sat: "Sat"
      },
      weeksFull: {
        sun: "Sunday",
        mon: "Monday",
        tue: "Tuesday",
        wed: "Wednesday",
        thu: "Thursday",
        fri: "Friday",
        sat: "Saturday"
      },
      months: {
        jan: "Jan",
        feb: "Feb",
        mar: "Mar",
        apr: "Apr",
        may: "May",
        jun: "Jun",
        jul: "Jul",
        aug: "Aug",
        sep: "Sep",
        oct: "Oct",
        nov: "Nov",
        dec: "Dec"
      }
    },
    inputNumber: {
      decrease: "decrease number",
      increase: "increase number"
    },
    select: {
      loading: "Loading",
      noMatch: "No matching data",
      noData: "No data",
      placeholder: "Select"
    },
    dropdown: {
      toggleDropdown: "Toggle Dropdown"
    },
    cascader: {
      noMatch: "No matching data",
      loading: "Loading",
      placeholder: "Select",
      noData: "No data"
    },
    pagination: {
      goto: "Go to",
      pagesize: "/page",
      total: "Total {total}",
      pageClassifier: "",
      page: "Page",
      prev: "Go to previous page",
      next: "Go to next page",
      currentPage: "page {pager}",
      prevPages: "Previous {pager} pages",
      nextPages: "Next {pager} pages",
      deprecationWarning: "Deprecated usages detected, please refer to the el-pagination documentation for more details"
    },
    dialog: {
      close: "Close this dialog"
    },
    drawer: {
      close: "Close this dialog"
    },
    messagebox: {
      title: "Message",
      confirm: "OK",
      cancel: "Cancel",
      error: "Illegal input",
      close: "Close this dialog"
    },
    upload: {
      deleteTip: "press delete to remove",
      delete: "Delete",
      preview: "Preview",
      continue: "Continue"
    },
    slider: {
      defaultLabel: "slider between {min} and {max}",
      defaultRangeStartLabel: "pick start value",
      defaultRangeEndLabel: "pick end value"
    },
    table: {
      emptyText: "No Data",
      confirmFilter: "Confirm",
      resetFilter: "Reset",
      clearFilter: "All",
      sumText: "Sum"
    },
    tree: {
      emptyText: "No Data"
    },
    transfer: {
      noMatch: "No matching data",
      noData: "No data",
      titles: ["List 1", "List 2"],
      filterPlaceholder: "Enter keyword",
      noCheckedFormat: "{total} items",
      hasCheckedFormat: "{checked}/{total} checked"
    },
    image: {
      error: "FAILED"
    },
    pageHeader: {
      title: "Back"
    },
    popconfirm: {
      confirmButtonText: "Yes",
      cancelButtonText: "No"
    }
  }
};
const buildTranslator = (locale) => (path, option) => translate(path, option, unref(locale));
const translate = (path, option, locale) => get(locale, path, path).replace(/\{(\w+)\}/g, (_, key) => {
  var _a;
  return `${(_a = option == null ? void 0 : option[key]) != null ? _a : `{${key}}`}`;
});
const buildLocaleContext = (locale) => {
  const lang = computed(() => unref(locale).name);
  const localeRef = isRef(locale) ? locale : ref(locale);
  return {
    lang,
    locale: localeRef,
    t: buildTranslator(locale)
  };
};
const localeContextKey = Symbol("localeContextKey");
const useLocale = (localeOverrides) => {
  const locale = localeOverrides || inject(localeContextKey, ref());
  return buildLocaleContext(computed(() => locale.value || English));
};
const useThrottleRender = (loading, throttle2 = 0) => {
  if (throttle2 === 0)
    return loading;
  const throttled = ref(false);
  let timeoutHandle = 0;
  const dispatchThrottling = () => {
    if (timeoutHandle) {
      clearTimeout(timeoutHandle);
    }
    timeoutHandle = window.setTimeout(() => {
      throttled.value = loading.value;
    }, throttle2);
  };
  watch(() => loading.value, (val) => {
    if (val) {
      dispatchThrottling();
    } else {
      throttled.value = val;
    }
  });
  return throttled;
};
const zIndex = ref(0);
const defaultInitialZIndex = 2e3;
const zIndexContextKey = Symbol("zIndexContextKey");
const useZIndex = (zIndexOverrides) => {
  const zIndexInjection = zIndexOverrides || inject(zIndexContextKey, void 0);
  const initialZIndex = computed(() => {
    const zIndexFromInjection = unref(zIndexInjection);
    return isNumber(zIndexFromInjection) ? zIndexFromInjection : defaultInitialZIndex;
  });
  const currentZIndex = computed(() => initialZIndex.value + zIndex.value);
  const nextZIndex = () => {
    zIndex.value++;
    return currentZIndex.value;
  };
  return {
    initialZIndex,
    currentZIndex,
    nextZIndex
  };
};
const getOrderedChildren = (vm, childComponentName, children) => {
  const nodes = flattedChildren(vm.subTree).filter((n) => {
    var _a;
    return isVNode(n) && ((_a = n.type) == null ? void 0 : _a.name) === childComponentName && !!n.component;
  });
  const uids = nodes.map((n) => n.component.uid);
  return uids.map((uid) => children[uid]).filter((p) => !!p);
};
const useOrderedChildren = (vm, childComponentName) => {
  const children = {};
  const orderedChildren = shallowRef([]);
  const addChild = (child) => {
    children[child.uid] = child;
    orderedChildren.value = getOrderedChildren(vm, childComponentName, children);
  };
  const removeChild = (uid) => {
    delete children[uid];
    orderedChildren.value = orderedChildren.value.filter((children2) => children2.uid !== uid);
  };
  return {
    children: orderedChildren,
    addChild,
    removeChild
  };
};
const GAP = 4;
const BAR_MAP = {
  vertical: {
    offset: "offsetHeight",
    scroll: "scrollTop",
    scrollSize: "scrollHeight",
    size: "height",
    key: "vertical",
    axis: "Y",
    client: "clientY",
    direction: "top"
  },
  horizontal: {
    offset: "offsetWidth",
    scroll: "scrollLeft",
    scrollSize: "scrollWidth",
    size: "width",
    key: "horizontal",
    axis: "X",
    client: "clientX",
    direction: "left"
  }
};
const renderThumbStyle = ({
  move,
  size,
  bar
}) => ({
  [bar.size]: size,
  transform: `translate${bar.axis}(${move}%)`
});
const scrollbarContextKey = Symbol("scrollbarContextKey");
const thumbProps = buildProps({
  vertical: Boolean,
  size: String,
  move: Number,
  ratio: {
    type: Number,
    required: true
  },
  always: Boolean
});
const COMPONENT_NAME$3 = "Thumb";
const _sfc_main$h = /* @__PURE__ */ defineComponent({
  __name: "thumb",
  props: thumbProps,
  setup(__props) {
    const props = __props;
    const scrollbar2 = inject(scrollbarContextKey);
    const ns = useNamespace("scrollbar");
    if (!scrollbar2)
      throwError(COMPONENT_NAME$3, "can not inject scrollbar context");
    const instance = ref();
    const thumb = ref();
    const thumbState = ref({});
    const visible = ref(false);
    let cursorDown = false;
    let cursorLeave = false;
    let originalOnSelectStart = null;
    const bar = computed(() => BAR_MAP[props.vertical ? "vertical" : "horizontal"]);
    const thumbStyle = computed(() => renderThumbStyle({
      size: props.size,
      move: props.move,
      bar: bar.value
    }));
    const offsetRatio = computed(() => instance.value[bar.value.offset] ** 2 / scrollbar2.wrapElement[bar.value.scrollSize] / props.ratio / thumb.value[bar.value.offset]);
    const clickThumbHandler = (e) => {
      var _a;
      e.stopPropagation();
      if (e.ctrlKey || [1, 2].includes(e.button))
        return;
      (_a = window.getSelection()) == null ? void 0 : _a.removeAllRanges();
      startDrag(e);
      const el = e.currentTarget;
      if (!el)
        return;
      thumbState.value[bar.value.axis] = el[bar.value.offset] - (e[bar.value.client] - el.getBoundingClientRect()[bar.value.direction]);
    };
    const clickTrackHandler = (e) => {
      if (!thumb.value || !instance.value || !scrollbar2.wrapElement)
        return;
      const offset = Math.abs(e.target.getBoundingClientRect()[bar.value.direction] - e[bar.value.client]);
      const thumbHalf = thumb.value[bar.value.offset] / 2;
      const thumbPositionPercentage = (offset - thumbHalf) * 100 * offsetRatio.value / instance.value[bar.value.offset];
      scrollbar2.wrapElement[bar.value.scroll] = thumbPositionPercentage * scrollbar2.wrapElement[bar.value.scrollSize] / 100;
    };
    const startDrag = (e) => {
      e.stopImmediatePropagation();
      cursorDown = true;
      document.addEventListener("mousemove", mouseMoveDocumentHandler);
      document.addEventListener("mouseup", mouseUpDocumentHandler);
      originalOnSelectStart = document.onselectstart;
      document.onselectstart = () => false;
    };
    const mouseMoveDocumentHandler = (e) => {
      if (!instance.value || !thumb.value)
        return;
      if (cursorDown === false)
        return;
      const prevPage = thumbState.value[bar.value.axis];
      if (!prevPage)
        return;
      const offset = (instance.value.getBoundingClientRect()[bar.value.direction] - e[bar.value.client]) * -1;
      const thumbClickPosition = thumb.value[bar.value.offset] - prevPage;
      const thumbPositionPercentage = (offset - thumbClickPosition) * 100 * offsetRatio.value / instance.value[bar.value.offset];
      scrollbar2.wrapElement[bar.value.scroll] = thumbPositionPercentage * scrollbar2.wrapElement[bar.value.scrollSize] / 100;
    };
    const mouseUpDocumentHandler = () => {
      cursorDown = false;
      thumbState.value[bar.value.axis] = 0;
      document.removeEventListener("mousemove", mouseMoveDocumentHandler);
      document.removeEventListener("mouseup", mouseUpDocumentHandler);
      restoreOnselectstart();
      if (cursorLeave)
        visible.value = false;
    };
    const mouseMoveScrollbarHandler = () => {
      cursorLeave = false;
      visible.value = !!props.size;
    };
    const mouseLeaveScrollbarHandler = () => {
      cursorLeave = true;
      visible.value = cursorDown;
    };
    const restoreOnselectstart = () => {
      if (document.onselectstart !== originalOnSelectStart)
        document.onselectstart = originalOnSelectStart;
    };
    useEventListener(toRef(scrollbar2, "scrollbarElement"), "mousemove", mouseMoveScrollbarHandler);
    useEventListener(toRef(scrollbar2, "scrollbarElement"), "mouseleave", mouseLeaveScrollbarHandler);
    return (_ctx, _cache) => {
      return openBlock(), createBlock(Transition, {
        name: unref(ns).b("fade"),
        persisted: ""
      }, {
        default: withCtx(() => [
          withDirectives(createElementVNode("div", {
            ref_key: "instance",
            ref: instance,
            class: normalizeClass([unref(ns).e("bar"), unref(ns).is(unref(bar).key)]),
            onMousedown: clickTrackHandler
          }, [
            createElementVNode("div", {
              ref_key: "thumb",
              ref: thumb,
              class: normalizeClass(unref(ns).e("thumb")),
              style: normalizeStyle(unref(thumbStyle)),
              onMousedown: clickThumbHandler
            }, null, 38)
          ], 34), [
            [vShow, _ctx.always || visible.value]
          ])
        ]),
        _: 1
      }, 8, ["name"]);
    };
  }
});
var Thumb = /* @__PURE__ */ _export_sfc$1(_sfc_main$h, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/scrollbar/src/thumb.vue"]]);
const barProps = buildProps({
  always: {
    type: Boolean,
    default: true
  },
  width: String,
  height: String,
  ratioX: {
    type: Number,
    default: 1
  },
  ratioY: {
    type: Number,
    default: 1
  }
});
const _sfc_main$g = /* @__PURE__ */ defineComponent({
  __name: "bar",
  props: barProps,
  setup(__props, { expose }) {
    const props = __props;
    const moveX = ref(0);
    const moveY = ref(0);
    const handleScroll = (wrap) => {
      if (wrap) {
        const offsetHeight = wrap.offsetHeight - GAP;
        const offsetWidth = wrap.offsetWidth - GAP;
        moveY.value = wrap.scrollTop * 100 / offsetHeight * props.ratioY;
        moveX.value = wrap.scrollLeft * 100 / offsetWidth * props.ratioX;
      }
    };
    expose({
      handleScroll
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(Thumb, {
          move: moveX.value,
          ratio: _ctx.ratioX,
          size: _ctx.width,
          always: _ctx.always
        }, null, 8, ["move", "ratio", "size", "always"]),
        createVNode(Thumb, {
          move: moveY.value,
          ratio: _ctx.ratioY,
          size: _ctx.height,
          vertical: "",
          always: _ctx.always
        }, null, 8, ["move", "ratio", "size", "always"])
      ], 64);
    };
  }
});
var Bar = /* @__PURE__ */ _export_sfc$1(_sfc_main$g, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/scrollbar/src/bar.vue"]]);
const scrollbarProps = buildProps({
  height: {
    type: [String, Number],
    default: ""
  },
  maxHeight: {
    type: [String, Number],
    default: ""
  },
  native: {
    type: Boolean,
    default: false
  },
  wrapStyle: {
    type: definePropType([String, Object, Array]),
    default: ""
  },
  wrapClass: {
    type: [String, Array],
    default: ""
  },
  viewClass: {
    type: [String, Array],
    default: ""
  },
  viewStyle: {
    type: [String, Array, Object],
    default: ""
  },
  noresize: Boolean,
  tag: {
    type: String,
    default: "div"
  },
  always: Boolean,
  minSize: {
    type: Number,
    default: 20
  }
});
const scrollbarEmits = {
  scroll: ({
    scrollTop,
    scrollLeft
  }) => [scrollTop, scrollLeft].every(isNumber)
};
const COMPONENT_NAME$2 = "ElScrollbar";
const __default__$7 = /* @__PURE__ */ defineComponent({
  name: COMPONENT_NAME$2
});
const _sfc_main$f = /* @__PURE__ */ defineComponent({
  ...__default__$7,
  props: scrollbarProps,
  emits: scrollbarEmits,
  setup(__props, { expose, emit }) {
    const props = __props;
    const ns = useNamespace("scrollbar");
    let stopResizeObserver = void 0;
    let stopResizeListener = void 0;
    const scrollbarRef = ref();
    const wrapRef = ref();
    const resizeRef = ref();
    const sizeWidth = ref("0");
    const sizeHeight = ref("0");
    const barRef = ref();
    const ratioY = ref(1);
    const ratioX = ref(1);
    const style = computed(() => {
      const style2 = {};
      if (props.height)
        style2.height = addUnit(props.height);
      if (props.maxHeight)
        style2.maxHeight = addUnit(props.maxHeight);
      return [props.wrapStyle, style2];
    });
    const wrapKls = computed(() => {
      return [
        props.wrapClass,
        ns.e("wrap"),
        { [ns.em("wrap", "hidden-default")]: !props.native }
      ];
    });
    const resizeKls = computed(() => {
      return [ns.e("view"), props.viewClass];
    });
    const handleScroll = () => {
      var _a;
      if (wrapRef.value) {
        (_a = barRef.value) == null ? void 0 : _a.handleScroll(wrapRef.value);
        emit("scroll", {
          scrollTop: wrapRef.value.scrollTop,
          scrollLeft: wrapRef.value.scrollLeft
        });
      }
    };
    function scrollTo(arg1, arg2) {
      if (isObject(arg1)) {
        wrapRef.value.scrollTo(arg1);
      } else if (isNumber(arg1) && isNumber(arg2)) {
        wrapRef.value.scrollTo(arg1, arg2);
      }
    }
    const setScrollTop = (value) => {
      if (!isNumber(value)) {
        return;
      }
      wrapRef.value.scrollTop = value;
    };
    const setScrollLeft = (value) => {
      if (!isNumber(value)) {
        return;
      }
      wrapRef.value.scrollLeft = value;
    };
    const update = () => {
      if (!wrapRef.value)
        return;
      const offsetHeight = wrapRef.value.offsetHeight - GAP;
      const offsetWidth = wrapRef.value.offsetWidth - GAP;
      const originalHeight = offsetHeight ** 2 / wrapRef.value.scrollHeight;
      const originalWidth = offsetWidth ** 2 / wrapRef.value.scrollWidth;
      const height = Math.max(originalHeight, props.minSize);
      const width = Math.max(originalWidth, props.minSize);
      ratioY.value = originalHeight / (offsetHeight - originalHeight) / (height / (offsetHeight - height));
      ratioX.value = originalWidth / (offsetWidth - originalWidth) / (width / (offsetWidth - width));
      sizeHeight.value = height + GAP < offsetHeight ? `${height}px` : "";
      sizeWidth.value = width + GAP < offsetWidth ? `${width}px` : "";
    };
    watch(() => props.noresize, (noresize) => {
      if (noresize) {
        stopResizeObserver == null ? void 0 : stopResizeObserver();
        stopResizeListener == null ? void 0 : stopResizeListener();
      } else {
        ({ stop: stopResizeObserver } = useResizeObserver(resizeRef, update));
        stopResizeListener = useEventListener("resize", update);
      }
    }, { immediate: true });
    watch(() => [props.maxHeight, props.height], () => {
      if (!props.native)
        nextTick(() => {
          var _a;
          update();
          if (wrapRef.value) {
            (_a = barRef.value) == null ? void 0 : _a.handleScroll(wrapRef.value);
          }
        });
    });
    provide(scrollbarContextKey, reactive({
      scrollbarElement: scrollbarRef,
      wrapElement: wrapRef
    }));
    onUpdated(() => update());
    expose({
      wrapRef,
      update,
      scrollTo,
      setScrollTop,
      setScrollLeft,
      handleScroll
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        ref_key: "scrollbarRef",
        ref: scrollbarRef,
        class: normalizeClass(unref(ns).b())
      }, [
        createElementVNode("div", {
          ref_key: "wrapRef",
          ref: wrapRef,
          class: normalizeClass(unref(wrapKls)),
          style: normalizeStyle(unref(style)),
          onScroll: handleScroll
        }, [
          (openBlock(), createBlock(resolveDynamicComponent(_ctx.tag), {
            ref_key: "resizeRef",
            ref: resizeRef,
            class: normalizeClass(unref(resizeKls)),
            style: normalizeStyle(_ctx.viewStyle)
          }, {
            default: withCtx(() => [
              renderSlot(_ctx.$slots, "default")
            ]),
            _: 3
          }, 8, ["class", "style"]))
        ], 38),
        !_ctx.native ? (openBlock(), createBlock(Bar, {
          key: 0,
          ref_key: "barRef",
          ref: barRef,
          height: sizeHeight.value,
          width: sizeWidth.value,
          always: _ctx.always,
          "ratio-x": ratioX.value,
          "ratio-y": ratioY.value
        }, null, 8, ["height", "width", "always", "ratio-x", "ratio-y"])) : createCommentVNode("v-if", true)
      ], 2);
    };
  }
});
var Scrollbar = /* @__PURE__ */ _export_sfc$1(_sfc_main$f, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/scrollbar/src/scrollbar.vue"]]);
const ElScrollbar = withInstall(Scrollbar);
const carouselProps = buildProps({
  initialIndex: {
    type: Number,
    default: 0
  },
  height: {
    type: String,
    default: ""
  },
  trigger: {
    type: String,
    values: ["hover", "click"],
    default: "hover"
  },
  autoplay: {
    type: Boolean,
    default: true
  },
  interval: {
    type: Number,
    default: 3e3
  },
  indicatorPosition: {
    type: String,
    values: ["", "none", "outside"],
    default: ""
  },
  arrow: {
    type: String,
    values: ["always", "hover", "never"],
    default: "hover"
  },
  type: {
    type: String,
    values: ["", "card"],
    default: ""
  },
  loop: {
    type: Boolean,
    default: true
  },
  direction: {
    type: String,
    values: ["horizontal", "vertical"],
    default: "horizontal"
  },
  pauseOnHover: {
    type: Boolean,
    default: true
  }
});
const carouselEmits = {
  change: (current, prev) => [current, prev].every(isNumber)
};
const carouselContextKey = Symbol("carouselContextKey");
const THROTTLE_TIME = 300;
const useCarousel = (props, emit, componentName) => {
  const {
    children: items,
    addChild: addItem,
    removeChild: removeItem
  } = useOrderedChildren(getCurrentInstance(), "ElCarouselItem");
  const activeIndex = ref(-1);
  const timer = ref(null);
  const hover = ref(false);
  const root = ref();
  const containerHeight = ref(0);
  const arrowDisplay = computed(() => props.arrow !== "never" && !unref(isVertical));
  const hasLabel = computed(() => {
    return items.value.some((item) => item.props.label.toString().length > 0);
  });
  const isCardType = computed(() => props.type === "card");
  const isVertical = computed(() => props.direction === "vertical");
  const containerStyle = computed(() => {
    if (props.height !== "auto") {
      return {
        height: props.height
      };
    }
    return {
      height: `${containerHeight.value}px`,
      overflow: "hidden"
    };
  });
  const throttledArrowClick = throttle((index) => {
    setActiveItem(index);
  }, THROTTLE_TIME, { trailing: true });
  const throttledIndicatorHover = throttle((index) => {
    handleIndicatorHover(index);
  }, THROTTLE_TIME);
  function pauseTimer() {
    if (timer.value) {
      clearInterval(timer.value);
      timer.value = null;
    }
  }
  function startTimer() {
    if (props.interval <= 0 || !props.autoplay || timer.value)
      return;
    timer.value = setInterval(() => playSlides(), props.interval);
  }
  const playSlides = () => {
    if (activeIndex.value < items.value.length - 1) {
      activeIndex.value = activeIndex.value + 1;
    } else if (props.loop) {
      activeIndex.value = 0;
    }
  };
  function setActiveItem(index) {
    if (isString(index)) {
      const filteredItems = items.value.filter((item) => item.props.name === index);
      if (filteredItems.length > 0) {
        index = items.value.indexOf(filteredItems[0]);
      }
    }
    index = Number(index);
    if (Number.isNaN(index) || index !== Math.floor(index)) {
      return;
    }
    const itemCount = items.value.length;
    const oldIndex = activeIndex.value;
    if (index < 0) {
      activeIndex.value = props.loop ? itemCount - 1 : 0;
    } else if (index >= itemCount) {
      activeIndex.value = props.loop ? 0 : itemCount - 1;
    } else {
      activeIndex.value = index;
    }
    if (oldIndex === activeIndex.value) {
      resetItemPosition(oldIndex);
    }
    resetTimer();
  }
  function resetItemPosition(oldIndex) {
    items.value.forEach((item, index) => {
      item.translateItem(index, activeIndex.value, oldIndex);
    });
  }
  function itemInStage(item, index) {
    var _a, _b, _c, _d;
    const _items = unref(items);
    const itemCount = _items.length;
    if (itemCount === 0 || !item.states.inStage)
      return false;
    const nextItemIndex = index + 1;
    const prevItemIndex = index - 1;
    const lastItemIndex = itemCount - 1;
    const isLastItemActive = _items[lastItemIndex].states.active;
    const isFirstItemActive = _items[0].states.active;
    const isNextItemActive = (_b = (_a = _items[nextItemIndex]) == null ? void 0 : _a.states) == null ? void 0 : _b.active;
    const isPrevItemActive = (_d = (_c = _items[prevItemIndex]) == null ? void 0 : _c.states) == null ? void 0 : _d.active;
    if (index === lastItemIndex && isFirstItemActive || isNextItemActive) {
      return "left";
    } else if (index === 0 && isLastItemActive || isPrevItemActive) {
      return "right";
    }
    return false;
  }
  function handleMouseEnter() {
    hover.value = true;
    if (props.pauseOnHover) {
      pauseTimer();
    }
  }
  function handleMouseLeave() {
    hover.value = false;
    startTimer();
  }
  function handleButtonEnter(arrow) {
    if (unref(isVertical))
      return;
    items.value.forEach((item, index) => {
      if (arrow === itemInStage(item, index)) {
        item.states.hover = true;
      }
    });
  }
  function handleButtonLeave() {
    if (unref(isVertical))
      return;
    items.value.forEach((item) => {
      item.states.hover = false;
    });
  }
  function handleIndicatorClick(index) {
    activeIndex.value = index;
  }
  function handleIndicatorHover(index) {
    if (props.trigger === "hover" && index !== activeIndex.value) {
      activeIndex.value = index;
    }
  }
  function prev() {
    setActiveItem(activeIndex.value - 1);
  }
  function next() {
    setActiveItem(activeIndex.value + 1);
  }
  function resetTimer() {
    pauseTimer();
    startTimer();
  }
  function setContainerHeight(height) {
    if (props.height !== "auto")
      return;
    containerHeight.value = height;
  }
  watch(() => activeIndex.value, (current, prev2) => {
    resetItemPosition(prev2);
    if (prev2 > -1) {
      emit("change", current, prev2);
    }
  });
  watch(() => props.autoplay, (autoplay) => {
    autoplay ? startTimer() : pauseTimer();
  });
  watch(() => props.loop, () => {
    setActiveItem(activeIndex.value);
  });
  watch(() => props.interval, () => {
    resetTimer();
  });
  watch(() => items.value, () => {
    if (items.value.length > 0)
      setActiveItem(props.initialIndex);
  });
  shallowRef();
  provide(carouselContextKey, {
    root,
    isCardType,
    isVertical,
    items,
    loop: props.loop,
    addItem,
    removeItem,
    setActiveItem,
    setContainerHeight
  });
  return {
    root,
    activeIndex,
    arrowDisplay,
    hasLabel,
    hover,
    isCardType,
    items,
    isVertical,
    containerStyle,
    handleButtonEnter,
    handleButtonLeave,
    handleIndicatorClick,
    handleMouseEnter,
    handleMouseLeave,
    setActiveItem,
    prev,
    next,
    throttledArrowClick,
    throttledIndicatorHover
  };
};
const _hoisted_1$2 = ["onMouseenter", "onClick"];
const _hoisted_2$1 = { key: 0 };
const COMPONENT_NAME$1 = "ElCarousel";
const __default__$6 = /* @__PURE__ */ defineComponent({
  name: COMPONENT_NAME$1
});
const _sfc_main$e = /* @__PURE__ */ defineComponent({
  ...__default__$6,
  props: carouselProps,
  emits: carouselEmits,
  setup(__props, { expose, emit }) {
    const props = __props;
    const {
      root,
      activeIndex,
      arrowDisplay,
      hasLabel,
      hover,
      isCardType,
      items,
      isVertical,
      containerStyle,
      handleButtonEnter,
      handleButtonLeave,
      handleIndicatorClick,
      handleMouseEnter,
      handleMouseLeave,
      setActiveItem,
      prev,
      next,
      throttledArrowClick,
      throttledIndicatorHover
    } = useCarousel(props, emit);
    const ns = useNamespace("carousel");
    const carouselClasses = computed(() => {
      const classes = [ns.b(), ns.m(props.direction)];
      if (unref(isCardType)) {
        classes.push(ns.m("card"));
      }
      return classes;
    });
    const indicatorsClasses = computed(() => {
      const classes = [ns.e("indicators"), ns.em("indicators", props.direction)];
      if (unref(hasLabel)) {
        classes.push(ns.em("indicators", "labels"));
      }
      if (props.indicatorPosition === "outside") {
        classes.push(ns.em("indicators", "outside"));
      }
      if (unref(isVertical)) {
        classes.push(ns.em("indicators", "right"));
      }
      return classes;
    });
    expose({
      setActiveItem,
      prev,
      next
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        ref_key: "root",
        ref: root,
        class: normalizeClass(unref(carouselClasses)),
        onMouseenter: _cache[6] || (_cache[6] = withModifiers((...args) => unref(handleMouseEnter) && unref(handleMouseEnter)(...args), ["stop"])),
        onMouseleave: _cache[7] || (_cache[7] = withModifiers((...args) => unref(handleMouseLeave) && unref(handleMouseLeave)(...args), ["stop"]))
      }, [
        createElementVNode("div", {
          class: normalizeClass(unref(ns).e("container")),
          style: normalizeStyle(unref(containerStyle))
        }, [
          unref(arrowDisplay) ? (openBlock(), createBlock(Transition, {
            key: 0,
            name: "carousel-arrow-left",
            persisted: ""
          }, {
            default: withCtx(() => [
              withDirectives(createElementVNode("button", {
                type: "button",
                class: normalizeClass([unref(ns).e("arrow"), unref(ns).em("arrow", "left")]),
                onMouseenter: _cache[0] || (_cache[0] = ($event) => unref(handleButtonEnter)("left")),
                onMouseleave: _cache[1] || (_cache[1] = (...args) => unref(handleButtonLeave) && unref(handleButtonLeave)(...args)),
                onClick: _cache[2] || (_cache[2] = withModifiers(($event) => unref(throttledArrowClick)(unref(activeIndex) - 1), ["stop"]))
              }, [
                createVNode(unref(ElIcon), null, {
                  default: withCtx(() => [
                    createVNode(unref(arrow_left_default))
                  ]),
                  _: 1
                })
              ], 34), [
                [
                  vShow,
                  (_ctx.arrow === "always" || unref(hover)) && (props.loop || unref(activeIndex) > 0)
                ]
              ])
            ]),
            _: 1
          })) : createCommentVNode("v-if", true),
          unref(arrowDisplay) ? (openBlock(), createBlock(Transition, {
            key: 1,
            name: "carousel-arrow-right",
            persisted: ""
          }, {
            default: withCtx(() => [
              withDirectives(createElementVNode("button", {
                type: "button",
                class: normalizeClass([unref(ns).e("arrow"), unref(ns).em("arrow", "right")]),
                onMouseenter: _cache[3] || (_cache[3] = ($event) => unref(handleButtonEnter)("right")),
                onMouseleave: _cache[4] || (_cache[4] = (...args) => unref(handleButtonLeave) && unref(handleButtonLeave)(...args)),
                onClick: _cache[5] || (_cache[5] = withModifiers(($event) => unref(throttledArrowClick)(unref(activeIndex) + 1), ["stop"]))
              }, [
                createVNode(unref(ElIcon), null, {
                  default: withCtx(() => [
                    createVNode(unref(arrow_right_default))
                  ]),
                  _: 1
                })
              ], 34), [
                [
                  vShow,
                  (_ctx.arrow === "always" || unref(hover)) && (props.loop || unref(activeIndex) < unref(items).length - 1)
                ]
              ])
            ]),
            _: 1
          })) : createCommentVNode("v-if", true),
          renderSlot(_ctx.$slots, "default")
        ], 6),
        _ctx.indicatorPosition !== "none" ? (openBlock(), createElementBlock("ul", {
          key: 0,
          class: normalizeClass(unref(indicatorsClasses))
        }, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(unref(items), (item, index) => {
            return openBlock(), createElementBlock("li", {
              key: index,
              class: normalizeClass([
                unref(ns).e("indicator"),
                unref(ns).em("indicator", _ctx.direction),
                unref(ns).is("active", index === unref(activeIndex))
              ]),
              onMouseenter: ($event) => unref(throttledIndicatorHover)(index),
              onClick: withModifiers(($event) => unref(handleIndicatorClick)(index), ["stop"])
            }, [
              createElementVNode("button", {
                class: normalizeClass(unref(ns).e("button"))
              }, [
                unref(hasLabel) ? (openBlock(), createElementBlock("span", _hoisted_2$1, toDisplayString(item.props.label), 1)) : createCommentVNode("v-if", true)
              ], 2)
            ], 42, _hoisted_1$2);
          }), 128))
        ], 2)) : createCommentVNode("v-if", true)
      ], 34);
    };
  }
});
var Carousel = /* @__PURE__ */ _export_sfc$1(_sfc_main$e, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/carousel/src/carousel.vue"]]);
const carouselItemProps = buildProps({
  name: { type: String, default: "" },
  label: {
    type: [String, Number],
    default: ""
  }
});
const useCarouselItem = (props, componentName) => {
  const carouselContext = inject(carouselContextKey);
  const instance = getCurrentInstance();
  const carouselItemRef = ref();
  const hover = ref(false);
  const translate2 = ref(0);
  const scale = ref(1);
  const active = ref(false);
  const ready = ref(false);
  const inStage = ref(false);
  const animating = ref(false);
  const { isCardType, isVertical } = carouselContext;
  function handleItemClick() {
    if (carouselContext && unref(isCardType)) {
      const index = carouselContext.items.value.findIndex(({ uid }) => uid === instance.uid);
      carouselContext.setActiveItem(index);
    }
  }
  onUnmounted(() => {
    carouselContext.removeItem(instance.uid);
  });
  return {
    carouselItemRef,
    active,
    animating,
    hover,
    inStage,
    isVertical,
    translate: translate2,
    isCardType,
    scale,
    ready,
    handleItemClick
  };
};
const __default__$5 = /* @__PURE__ */ defineComponent({
  name: "ElCarouselItem"
});
const _sfc_main$d = /* @__PURE__ */ defineComponent({
  ...__default__$5,
  props: carouselItemProps,
  setup(__props) {
    const ns = useNamespace("carousel");
    const {
      carouselItemRef,
      active,
      animating,
      hover,
      inStage,
      isVertical,
      translate: translate2,
      isCardType,
      scale,
      ready,
      handleItemClick
    } = useCarouselItem();
    const itemStyle = computed(() => {
      const translateType = `translate${unref(isVertical) ? "Y" : "X"}`;
      const _translate = `${translateType}(${unref(translate2)}px)`;
      const _scale = `scale(${unref(scale)})`;
      const transform = [_translate, _scale].join(" ");
      return {
        transform
      };
    });
    return (_ctx, _cache) => {
      return withDirectives((openBlock(), createElementBlock("div", {
        ref_key: "carouselItemRef",
        ref: carouselItemRef,
        class: normalizeClass([
          unref(ns).e("item"),
          unref(ns).is("active", unref(active)),
          unref(ns).is("in-stage", unref(inStage)),
          unref(ns).is("hover", unref(hover)),
          unref(ns).is("animating", unref(animating)),
          {
            [unref(ns).em("item", "card")]: unref(isCardType),
            [unref(ns).em("item", "card-vertical")]: unref(isCardType) && unref(isVertical)
          }
        ]),
        style: normalizeStyle(unref(itemStyle)),
        onClick: _cache[0] || (_cache[0] = (...args) => unref(handleItemClick) && unref(handleItemClick)(...args))
      }, [
        unref(isCardType) ? withDirectives((openBlock(), createElementBlock("div", {
          key: 0,
          class: normalizeClass(unref(ns).e("mask"))
        }, null, 2)), [
          [vShow, !unref(active)]
        ]) : createCommentVNode("v-if", true),
        renderSlot(_ctx.$slots, "default")
      ], 6)), [
        [vShow, unref(ready)]
      ]);
    };
  }
});
var CarouselItem = /* @__PURE__ */ _export_sfc$1(_sfc_main$d, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/carousel/src/carousel-item.vue"]]);
const ElCarousel = withInstall(Carousel, {
  CarouselItem
});
const ElCarouselItem = withNoopInstall(CarouselItem);
const dividerProps = buildProps({
  direction: {
    type: String,
    values: ["horizontal", "vertical"],
    default: "horizontal"
  },
  contentPosition: {
    type: String,
    values: ["left", "center", "right"],
    default: "center"
  },
  borderStyle: {
    type: definePropType(String),
    default: "solid"
  }
});
const __default__$4 = /* @__PURE__ */ defineComponent({
  name: "ElDivider"
});
const _sfc_main$c = /* @__PURE__ */ defineComponent({
  ...__default__$4,
  props: dividerProps,
  setup(__props) {
    const props = __props;
    const ns = useNamespace("divider");
    const dividerStyle = computed(() => {
      return ns.cssVar({
        "border-style": props.borderStyle
      });
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass([unref(ns).b(), unref(ns).m(_ctx.direction)]),
        style: normalizeStyle(unref(dividerStyle)),
        role: "separator"
      }, [
        _ctx.$slots.default && _ctx.direction !== "vertical" ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: normalizeClass([unref(ns).e("text"), unref(ns).is(_ctx.contentPosition)])
        }, [
          renderSlot(_ctx.$slots, "default")
        ], 2)) : createCommentVNode("v-if", true)
      ], 6);
    };
  }
});
var Divider = /* @__PURE__ */ _export_sfc$1(_sfc_main$c, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/divider/src/divider.vue"]]);
const ElDivider = withInstall(Divider);
const imageViewerProps = buildProps({
  urlList: {
    type: definePropType(Array),
    default: () => mutable([])
  },
  zIndex: {
    type: Number
  },
  initialIndex: {
    type: Number,
    default: 0
  },
  infinite: {
    type: Boolean,
    default: true
  },
  hideOnClickModal: {
    type: Boolean,
    default: false
  },
  teleported: {
    type: Boolean,
    default: false
  },
  closeOnPressEscape: {
    type: Boolean,
    default: true
  },
  zoomRate: {
    type: Number,
    default: 1.2
  }
});
const imageViewerEmits = {
  close: () => true,
  switch: (index) => isNumber(index)
};
const _hoisted_1$1 = ["src"];
const __default__$3 = /* @__PURE__ */ defineComponent({
  name: "ElImageViewer"
});
const _sfc_main$b = /* @__PURE__ */ defineComponent({
  ...__default__$3,
  props: imageViewerProps,
  emits: imageViewerEmits,
  setup(__props, { expose, emit }) {
    const props = __props;
    const modes = {
      CONTAIN: {
        name: "contain",
        icon: markRaw(full_screen_default)
      },
      ORIGINAL: {
        name: "original",
        icon: markRaw(scale_to_original_default)
      }
    };
    const { t } = useLocale();
    const ns = useNamespace("image-viewer");
    const { nextZIndex } = useZIndex();
    const wrapper = ref();
    const imgRefs = ref([]);
    const scopeEventListener = effectScope();
    const loading = ref(true);
    const activeIndex = ref(props.initialIndex);
    const mode = shallowRef(modes.CONTAIN);
    const transform = ref({
      scale: 1,
      deg: 0,
      offsetX: 0,
      offsetY: 0,
      enableTransition: false
    });
    const isSingle = computed(() => {
      const { urlList } = props;
      return urlList.length <= 1;
    });
    const isFirst = computed(() => {
      return activeIndex.value === 0;
    });
    const isLast = computed(() => {
      return activeIndex.value === props.urlList.length - 1;
    });
    const currentImg = computed(() => {
      return props.urlList[activeIndex.value];
    });
    const imgStyle = computed(() => {
      const { scale, deg, offsetX, offsetY, enableTransition } = transform.value;
      let translateX = offsetX / scale;
      let translateY = offsetY / scale;
      switch (deg % 360) {
        case 90:
        case -270:
          [translateX, translateY] = [translateY, -translateX];
          break;
        case 180:
        case -180:
          [translateX, translateY] = [-translateX, -translateY];
          break;
        case 270:
        case -90:
          [translateX, translateY] = [-translateY, translateX];
          break;
      }
      const style = {
        transform: `scale(${scale}) rotate(${deg}deg) translate(${translateX}px, ${translateY}px)`,
        transition: enableTransition ? "transform .3s" : ""
      };
      if (mode.value.name === modes.CONTAIN.name) {
        style.maxWidth = style.maxHeight = "100%";
      }
      return style;
    });
    const computedZIndex = computed(() => {
      return isNumber(props.zIndex) ? props.zIndex : nextZIndex();
    });
    function hide() {
      unregisterEventListener();
      emit("close");
    }
    function unregisterEventListener() {
      scopeEventListener.stop();
    }
    function handleImgLoad() {
      loading.value = false;
    }
    function handleImgError(e) {
      loading.value = false;
      e.target.alt = t("el.image.error");
    }
    function handleMouseDown(e) {
      if (loading.value || e.button !== 0 || !wrapper.value)
        return;
      transform.value.enableTransition = false;
      const { offsetX, offsetY } = transform.value;
      const startX = e.pageX;
      const startY = e.pageY;
      const dragHandler = throttle((ev) => {
        transform.value = {
          ...transform.value,
          offsetX: offsetX + ev.pageX - startX,
          offsetY: offsetY + ev.pageY - startY
        };
      });
      const removeMousemove = useEventListener(document, "mousemove", dragHandler);
      useEventListener(document, "mouseup", () => {
        removeMousemove();
      });
      e.preventDefault();
    }
    function reset() {
      transform.value = {
        scale: 1,
        deg: 0,
        offsetX: 0,
        offsetY: 0,
        enableTransition: false
      };
    }
    function toggleMode() {
      if (loading.value)
        return;
      const modeNames = keysOf(modes);
      const modeValues = Object.values(modes);
      const currentMode = mode.value.name;
      const index = modeValues.findIndex((i) => i.name === currentMode);
      const nextIndex = (index + 1) % modeNames.length;
      mode.value = modes[modeNames[nextIndex]];
      reset();
    }
    function setActiveItem(index) {
      const len = props.urlList.length;
      activeIndex.value = (index + len) % len;
    }
    function prev() {
      if (isFirst.value && !props.infinite)
        return;
      setActiveItem(activeIndex.value - 1);
    }
    function next() {
      if (isLast.value && !props.infinite)
        return;
      setActiveItem(activeIndex.value + 1);
    }
    function handleActions(action, options = {}) {
      if (loading.value)
        return;
      const { zoomRate, rotateDeg, enableTransition } = {
        zoomRate: props.zoomRate,
        rotateDeg: 90,
        enableTransition: true,
        ...options
      };
      switch (action) {
        case "zoomOut":
          if (transform.value.scale > 0.2) {
            transform.value.scale = Number.parseFloat((transform.value.scale / zoomRate).toFixed(3));
          }
          break;
        case "zoomIn":
          if (transform.value.scale < 7) {
            transform.value.scale = Number.parseFloat((transform.value.scale * zoomRate).toFixed(3));
          }
          break;
        case "clockwise":
          transform.value.deg += rotateDeg;
          break;
        case "anticlockwise":
          transform.value.deg -= rotateDeg;
          break;
      }
      transform.value.enableTransition = enableTransition;
    }
    watch(currentImg, () => {
      nextTick(() => {
        const $img = imgRefs.value[0];
        if (!($img == null ? void 0 : $img.complete)) {
          loading.value = true;
        }
      });
    });
    watch(activeIndex, (val) => {
      reset();
      emit("switch", val);
    });
    expose({
      setActiveItem
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(Teleport, {
        to: "body",
        disabled: !_ctx.teleported
      }, [
        createVNode(Transition, {
          name: "viewer-fade",
          appear: ""
        }, {
          default: withCtx(() => [
            createElementVNode("div", {
              ref_key: "wrapper",
              ref: wrapper,
              tabindex: -1,
              class: normalizeClass(unref(ns).e("wrapper")),
              style: normalizeStyle({ zIndex: unref(computedZIndex) })
            }, [
              createElementVNode("div", {
                class: normalizeClass(unref(ns).e("mask")),
                onClick: _cache[0] || (_cache[0] = withModifiers(($event) => _ctx.hideOnClickModal && hide(), ["self"]))
              }, null, 2),
              createCommentVNode(" CLOSE "),
              createElementVNode("span", {
                class: normalizeClass([unref(ns).e("btn"), unref(ns).e("close")]),
                onClick: hide
              }, [
                createVNode(unref(ElIcon), null, {
                  default: withCtx(() => [
                    createVNode(unref(close_default))
                  ]),
                  _: 1
                })
              ], 2),
              createCommentVNode(" ARROW "),
              !unref(isSingle) ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                createElementVNode("span", {
                  class: normalizeClass([
                    unref(ns).e("btn"),
                    unref(ns).e("prev"),
                    unref(ns).is("disabled", !_ctx.infinite && unref(isFirst))
                  ]),
                  onClick: prev
                }, [
                  createVNode(unref(ElIcon), null, {
                    default: withCtx(() => [
                      createVNode(unref(arrow_left_default))
                    ]),
                    _: 1
                  })
                ], 2),
                createElementVNode("span", {
                  class: normalizeClass([
                    unref(ns).e("btn"),
                    unref(ns).e("next"),
                    unref(ns).is("disabled", !_ctx.infinite && unref(isLast))
                  ]),
                  onClick: next
                }, [
                  createVNode(unref(ElIcon), null, {
                    default: withCtx(() => [
                      createVNode(unref(arrow_right_default))
                    ]),
                    _: 1
                  })
                ], 2)
              ], 64)) : createCommentVNode("v-if", true),
              createCommentVNode(" ACTIONS "),
              createElementVNode("div", {
                class: normalizeClass([unref(ns).e("btn"), unref(ns).e("actions")])
              }, [
                createElementVNode("div", {
                  class: normalizeClass(unref(ns).e("actions__inner"))
                }, [
                  createVNode(unref(ElIcon), {
                    onClick: _cache[1] || (_cache[1] = ($event) => handleActions("zoomOut"))
                  }, {
                    default: withCtx(() => [
                      createVNode(unref(zoom_out_default))
                    ]),
                    _: 1
                  }),
                  createVNode(unref(ElIcon), {
                    onClick: _cache[2] || (_cache[2] = ($event) => handleActions("zoomIn"))
                  }, {
                    default: withCtx(() => [
                      createVNode(unref(zoom_in_default))
                    ]),
                    _: 1
                  }),
                  createElementVNode("i", {
                    class: normalizeClass(unref(ns).e("actions__divider"))
                  }, null, 2),
                  createVNode(unref(ElIcon), { onClick: toggleMode }, {
                    default: withCtx(() => [
                      (openBlock(), createBlock(resolveDynamicComponent(unref(mode).icon)))
                    ]),
                    _: 1
                  }),
                  createElementVNode("i", {
                    class: normalizeClass(unref(ns).e("actions__divider"))
                  }, null, 2),
                  createVNode(unref(ElIcon), {
                    onClick: _cache[3] || (_cache[3] = ($event) => handleActions("anticlockwise"))
                  }, {
                    default: withCtx(() => [
                      createVNode(unref(refresh_left_default))
                    ]),
                    _: 1
                  }),
                  createVNode(unref(ElIcon), {
                    onClick: _cache[4] || (_cache[4] = ($event) => handleActions("clockwise"))
                  }, {
                    default: withCtx(() => [
                      createVNode(unref(refresh_right_default))
                    ]),
                    _: 1
                  })
                ], 2)
              ], 2),
              createCommentVNode(" CANVAS "),
              createElementVNode("div", {
                class: normalizeClass(unref(ns).e("canvas"))
              }, [
                (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.urlList, (url, i) => {
                  return withDirectives((openBlock(), createElementBlock("img", {
                    ref_for: true,
                    ref: (el) => imgRefs.value[i] = el,
                    key: url,
                    src: url,
                    style: normalizeStyle(unref(imgStyle)),
                    class: normalizeClass(unref(ns).e("img")),
                    onLoad: handleImgLoad,
                    onError: handleImgError,
                    onMousedown: handleMouseDown
                  }, null, 46, _hoisted_1$1)), [
                    [vShow, i === activeIndex.value]
                  ]);
                }), 128))
              ], 2),
              renderSlot(_ctx.$slots, "default")
            ], 6)
          ]),
          _: 3
        })
      ], 8, ["disabled"]);
    };
  }
});
var ImageViewer = /* @__PURE__ */ _export_sfc$1(_sfc_main$b, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/image-viewer/src/image-viewer.vue"]]);
const ElImageViewer = withInstall(ImageViewer);
const imageProps = buildProps({
  hideOnClickModal: {
    type: Boolean,
    default: false
  },
  src: {
    type: String,
    default: ""
  },
  fit: {
    type: String,
    values: ["", "contain", "cover", "fill", "none", "scale-down"],
    default: ""
  },
  loading: {
    type: String,
    values: ["eager", "lazy"]
  },
  lazy: {
    type: Boolean,
    default: false
  },
  scrollContainer: {
    type: definePropType([String, Object])
  },
  previewSrcList: {
    type: definePropType(Array),
    default: () => mutable([])
  },
  previewTeleported: {
    type: Boolean,
    default: false
  },
  zIndex: {
    type: Number
  },
  initialIndex: {
    type: Number,
    default: 0
  },
  infinite: {
    type: Boolean,
    default: true
  },
  closeOnPressEscape: {
    type: Boolean,
    default: true
  },
  zoomRate: {
    type: Number,
    default: 1.2
  }
});
const imageEmits = {
  load: (evt) => evt instanceof Event,
  error: (evt) => evt instanceof Event,
  switch: (val) => isNumber(val),
  close: () => true,
  show: () => true
};
const _hoisted_1 = ["src", "loading"];
const _hoisted_2 = { key: 0 };
const __default__$2 = /* @__PURE__ */ defineComponent({
  name: "ElImage",
  inheritAttrs: false
});
const _sfc_main$a = /* @__PURE__ */ defineComponent({
  ...__default__$2,
  props: imageProps,
  emits: imageEmits,
  setup(__props, { emit }) {
    const props = __props;
    let prevOverflow = "";
    const { t } = useLocale();
    const ns = useNamespace("image");
    const rawAttrs = useAttrs();
    const attrs = useAttrs$1();
    const imageSrc = ref();
    const hasLoadError = ref(false);
    const isLoading = ref(true);
    const showViewer = ref(false);
    const container = ref();
    ref();
    let stopWheelListener;
    const containerStyle = computed(() => rawAttrs.style);
    const imageStyle = computed(() => {
      return {};
    });
    const preview = computed(() => {
      const { previewSrcList } = props;
      return Array.isArray(previewSrcList) && previewSrcList.length > 0;
    });
    const imageIndex = computed(() => {
      const { previewSrcList, initialIndex } = props;
      let previewIndex = initialIndex;
      if (initialIndex > previewSrcList.length - 1) {
        previewIndex = 0;
      }
      return previewIndex;
    });
    const isManual = computed(() => {
      if (props.loading === "eager")
        return false;
      return props.loading === "lazy" || props.lazy;
    });
    function handleLoad(event) {
      isLoading.value = false;
      hasLoadError.value = false;
      emit("load", event);
    }
    function handleError(event) {
      isLoading.value = false;
      hasLoadError.value = true;
      emit("error", event);
    }
    async function addLazyLoadListener() {
      return;
    }
    function wheelHandler(e) {
      if (!e.ctrlKey)
        return;
      if (e.deltaY < 0) {
        e.preventDefault();
        return false;
      } else if (e.deltaY > 0) {
        e.preventDefault();
        return false;
      }
    }
    function clickHandler() {
      if (!preview.value)
        return;
      stopWheelListener = useEventListener("wheel", wheelHandler, {
        passive: false
      });
      prevOverflow = document.body.style.overflow;
      document.body.style.overflow = "hidden";
      showViewer.value = true;
      emit("show");
    }
    function closeViewer() {
      stopWheelListener == null ? void 0 : stopWheelListener();
      document.body.style.overflow = prevOverflow;
      showViewer.value = false;
      emit("close");
    }
    function switchViewer(val) {
      emit("switch", val);
    }
    watch(() => props.src, () => {
      if (isManual.value) {
        isLoading.value = true;
        hasLoadError.value = false;
        addLazyLoadListener();
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        ref_key: "container",
        ref: container,
        class: normalizeClass([unref(ns).b(), _ctx.$attrs.class]),
        style: normalizeStyle(unref(containerStyle))
      }, [
        hasLoadError.value ? renderSlot(_ctx.$slots, "error", { key: 0 }, () => [
          createElementVNode("div", {
            class: normalizeClass(unref(ns).e("error"))
          }, toDisplayString(unref(t)("el.image.error")), 3)
        ]) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
          imageSrc.value !== void 0 ? (openBlock(), createElementBlock("img", mergeProps({ key: 0 }, unref(attrs), {
            src: imageSrc.value,
            loading: _ctx.loading,
            style: unref(imageStyle),
            class: [
              unref(ns).e("inner"),
              unref(preview) && unref(ns).e("preview"),
              isLoading.value && unref(ns).is("loading")
            ],
            onClick: clickHandler,
            onLoad: handleLoad,
            onError: handleError
          }), null, 16, _hoisted_1)) : createCommentVNode("v-if", true),
          isLoading.value ? (openBlock(), createElementBlock("div", {
            key: 1,
            class: normalizeClass(unref(ns).e("wrapper"))
          }, [
            renderSlot(_ctx.$slots, "placeholder", {}, () => [
              createElementVNode("div", {
                class: normalizeClass(unref(ns).e("placeholder"))
              }, null, 2)
            ])
          ], 2)) : createCommentVNode("v-if", true)
        ], 64)),
        unref(preview) ? (openBlock(), createElementBlock(Fragment, { key: 2 }, [
          showViewer.value ? (openBlock(), createBlock(unref(ElImageViewer), {
            key: 0,
            "z-index": _ctx.zIndex,
            "initial-index": unref(imageIndex),
            infinite: _ctx.infinite,
            "zoom-rate": _ctx.zoomRate,
            "url-list": _ctx.previewSrcList,
            "hide-on-click-modal": _ctx.hideOnClickModal,
            teleported: _ctx.previewTeleported,
            "close-on-press-escape": _ctx.closeOnPressEscape,
            onClose: closeViewer,
            onSwitch: switchViewer
          }, {
            default: withCtx(() => [
              _ctx.$slots.viewer ? (openBlock(), createElementBlock("div", _hoisted_2, [
                renderSlot(_ctx.$slots, "viewer")
              ])) : createCommentVNode("v-if", true)
            ]),
            _: 3
          }, 8, ["z-index", "initial-index", "infinite", "zoom-rate", "url-list", "hide-on-click-modal", "teleported", "close-on-press-escape"])) : createCommentVNode("v-if", true)
        ], 64)) : createCommentVNode("v-if", true)
      ], 6);
    };
  }
});
var Image = /* @__PURE__ */ _export_sfc$1(_sfc_main$a, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/image/src/image.vue"]]);
const ElImage = withInstall(Image);
const skeletonProps = buildProps({
  animated: {
    type: Boolean,
    default: false
  },
  count: {
    type: Number,
    default: 1
  },
  rows: {
    type: Number,
    default: 3
  },
  loading: {
    type: Boolean,
    default: true
  },
  throttle: {
    type: Number
  }
});
const skeletonItemProps = buildProps({
  variant: {
    type: String,
    values: [
      "circle",
      "rect",
      "h1",
      "h3",
      "text",
      "caption",
      "p",
      "image",
      "button"
    ],
    default: "text"
  }
});
const __default__$1 = /* @__PURE__ */ defineComponent({
  name: "ElSkeletonItem"
});
const _sfc_main$9 = /* @__PURE__ */ defineComponent({
  ...__default__$1,
  props: skeletonItemProps,
  setup(__props) {
    const ns = useNamespace("skeleton");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass([unref(ns).e("item"), unref(ns).e(_ctx.variant)])
      }, [
        _ctx.variant === "image" ? (openBlock(), createBlock(unref(picture_filled_default), { key: 0 })) : createCommentVNode("v-if", true)
      ], 2);
    };
  }
});
var SkeletonItem = /* @__PURE__ */ _export_sfc$1(_sfc_main$9, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/skeleton/src/skeleton-item.vue"]]);
const __default__ = /* @__PURE__ */ defineComponent({
  name: "ElSkeleton"
});
const _sfc_main$8 = /* @__PURE__ */ defineComponent({
  ...__default__,
  props: skeletonProps,
  setup(__props, { expose }) {
    const props = __props;
    const ns = useNamespace("skeleton");
    const uiLoading = useThrottleRender(toRef(props, "loading"), props.throttle);
    expose({
      uiLoading
    });
    return (_ctx, _cache) => {
      return unref(uiLoading) ? (openBlock(), createElementBlock("div", mergeProps({
        key: 0,
        class: [unref(ns).b(), unref(ns).is("animated", _ctx.animated)]
      }, _ctx.$attrs), [
        (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.count, (i) => {
          return openBlock(), createElementBlock(Fragment, { key: i }, [
            _ctx.loading ? renderSlot(_ctx.$slots, "template", { key: i }, () => [
              createVNode(SkeletonItem, {
                class: normalizeClass(unref(ns).is("first")),
                variant: "p"
              }, null, 8, ["class"]),
              (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.rows, (item) => {
                return openBlock(), createBlock(SkeletonItem, {
                  key: item,
                  class: normalizeClass([
                    unref(ns).e("paragraph"),
                    unref(ns).is("last", item === _ctx.rows && _ctx.rows > 1)
                  ]),
                  variant: "p"
                }, null, 8, ["class"]);
              }), 128))
            ]) : createCommentVNode("v-if", true)
          ], 64);
        }), 128))
      ], 16)) : renderSlot(_ctx.$slots, "default", normalizeProps(mergeProps({ key: 1 }, _ctx.$attrs)));
    };
  }
});
var Skeleton = /* @__PURE__ */ _export_sfc$1(_sfc_main$8, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/skeleton/src/skeleton.vue"]]);
const ElSkeleton = withInstall(Skeleton, {
  SkeletonItem
});
const ElSkeletonItem = withNoopInstall(SkeletonItem);
function getGoodsListByPage(page, size, dto) {
  return request({
    method: "POST",
    url: `/goods/list/${page}/${size}`,
    data: { ...dto }
  });
}
const _sfc_main$7 = /* @__PURE__ */ defineComponent({
  __name: "Search",
  __ssrInlineRender: true,
  setup(__props) {
    ref("");
    ref(false);
    ref(false);
    let searchPage = reactive({
      records: [],
      total: 0,
      pages: 0,
      size: 0,
      current: 0
    });
    const searchPageList = reactive([]);
    ref(false);
    ref(1);
    ref(6);
    computed(() => searchPage.total > 0 && searchPageList.length === searchPage.total);
    useStorage("jiwu_index_search", []);
    const app = useNuxtApp();
    let searchInpRef = {};
    app.hook("app:mounted", () => {
      searchInpRef = ref("searchInpRef");
      console.dir(searchInpRef);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ClientOnly = __nuxt_component_0$2;
      _push(ssrRenderComponent(_component_ClientOnly, _attrs, {}, _parent));
    };
  }
});
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Index/Search.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["__scopeId", "data-v-353bbae0"]]);
const _imports_0 = "" + buildAssetsURL("logo_txt.318d9294.png");
const _sfc_main$6 = /* @__PURE__ */ defineComponent({
  __name: "TopMenu",
  __ssrInlineRender: true,
  setup(__props) {
    useUserStore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ClientOnly = __nuxt_component_0$2;
      const _component_IndexSearch = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "top",
        "overflow-hidden": "",
        "flex-row-bt-c": "",
        "flex-col": "",
        "md:flex-row": ""
      }, _attrs))}><img absolute bg-color-indigo-6 z-0 flex-2${ssrRenderAttr("src", _imports_0)} filter-blur-30 w-240px alt="\u6781\u7269\u5708 logo"><div class="title animate__animated animate__fadeInDown" mt-4 mb-8>`);
      _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
      _push(`<h2 tracking-1>\u6B22\u8FCE\u6765\u5230<mark class="mark1 animatejs">\u6781\u7269\u5708\u793E\u533A </mark>\u{1F389}</h2></div><div class="animate__animated animate__pulse" animate-delay-500 p-2>`);
      _push(ssrRenderComponent(_component_IndexSearch, null, null, _parent));
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Index/TopMenu.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
function getGoodsCategoryList() {
  return useHttp.get("/goods/category/list");
}
const _sfc_main$5 = /* @__PURE__ */ defineComponent({
  __name: "Category",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const data = ([__temp, __restore] = withAsyncContext(() => getGoodsCategoryList()), __temp = await __temp, __restore(), __temp);
    const categoryList = ref(data.data || []);
    const router = useRouter();
    const toView = (item) => {
      router.push({
        path: "/search",
        query: {
          categotyId: item.id
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ElScrollbar = ElScrollbar;
      const _component_el_button = ElButton;
      _push(ssrRenderComponent(_component_ElScrollbar, mergeProps({
        "mx-a": "",
        "md:mx-0": "",
        "max-h-400px": "",
        "overflow-scroll": "",
        class: "category animate-delay-100 animate__animated animate__fadeIn",
        "tracking-0.1em": "",
        "w-16vw": "",
        "mr-4": "",
        flex: "col wrap"
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h3${_scopeId}>\u5546\u54C1\u7C7B\u522B</h3><!--[-->`);
            ssrRenderList(unref(categoryList), (p) => {
              _push2(`<p my-4 type="warning"${_scopeId}><h4 class="first" inline-block mr-2 style="${ssrRenderStyle({ "line-height": "100%" })}"${_scopeId}>${ssrInterpolate(p.name)}</h4><div class="second" inline-block my-1${_scopeId}><!--[-->`);
              ssrRenderList(p == null ? void 0 : p.children, (k) => {
                _push2(ssrRenderComponent(_component_el_button, {
                  onClick: ($event) => toView(k),
                  type: "primary",
                  plain: "",
                  key: k.id,
                  style: { "margin": "0 0.3em", "padding": "0 0.8em", "cursor": "pointer" }
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`${ssrInterpolate(k.name)}`);
                    } else {
                      return [
                        createTextVNode(toDisplayString(k.name), 1)
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              });
              _push2(`<!--]--></div></p>`);
            });
            _push2(`<!--]-->`);
          } else {
            return [
              createVNode("h3", null, "\u5546\u54C1\u7C7B\u522B"),
              (openBlock(true), createBlock(Fragment, null, renderList(unref(categoryList), (p) => {
                return openBlock(), createBlock("p", {
                  "my-4": "",
                  type: "warning",
                  key: p.id
                }, [
                  createVNode("h4", {
                    class: "first",
                    onClick: ($event) => toView(_ctx.k),
                    "inline-block": "",
                    "mr-2": "",
                    style: { "line-height": "100%" }
                  }, toDisplayString(p.name), 9, ["onClick"]),
                  createVNode("div", {
                    class: "second",
                    "inline-block": "",
                    "my-1": ""
                  }, [
                    (openBlock(true), createBlock(Fragment, null, renderList(p == null ? void 0 : p.children, (k) => {
                      return openBlock(), createBlock(_component_el_button, {
                        onClick: ($event) => toView(k),
                        type: "primary",
                        plain: "",
                        key: k.id,
                        style: { "margin": "0 0.3em", "padding": "0 0.8em", "cursor": "pointer" }
                      }, {
                        default: withCtx(() => [
                          createTextVNode(toDisplayString(k.name), 1)
                        ]),
                        _: 2
                      }, 1032, ["onClick"]);
                    }), 128))
                  ])
                ]);
              }), 128))
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Index/Category.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
function getEventsLists() {
  return useHttp.get("/api/event/list");
}
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "Swiper",
  __ssrInlineRender: true,
  setup(__props) {
    const eventList = reactive([]);
    const isLoading = ref(true);
    useAsyncData(async () => {
      const data = await getEventsLists();
      if (data.code === StatusCode.SUCCESS) {
        const res = data.data.sort((a, b) => b.status - a.status);
        res.forEach((p) => {
          eventList.push(p);
        });
        if (eventList.length === data.data.length) {
          setTimeout(() => {
            isLoading.value = false;
          }, 500);
        }
      }
    }, "$1w5cfcos8w");
    const toEventDetailView = (eid) => {
      useRouter().push({
        path: "/event/detail",
        query: {
          eid
        }
      });
    };
    const getEndDay = computed(() => {
      return (a, b) => {
        let newDate = (/* @__PURE__ */ new Date()).getTime();
        let start = Date.parse(a);
        let end = Date.parse(b);
        if (start > newDate) {
          return 0;
        }
        if (end < newDate) {
          return -1;
        }
        return +((end - newDate) / (1 * 24 * 60 * 60 * 1e3)).toFixed(0);
      };
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_el_carousel = ElCarousel;
      const _component_el_skeleton = ElSkeleton;
      const _component_el_skeleton_item = ElSkeletonItem;
      const _component_el_carousel_item = ElCarouselItem;
      const _component_ClientOnly = __nuxt_component_0$2;
      const _component_el_image = ElImage;
      const _component_ElIconPicture = picture_default;
      _push(ssrRenderComponent(_component_el_carousel, mergeProps({
        "rounded-6px": "",
        "cursor-pointer": "",
        interval: 8e3,
        arrow: "hover",
        "my-4": "",
        "md:my-0": "",
        "mx-auto": "",
        "md:mx-none": "",
        "md:w": "560px",
        "h-280px": "",
        "md:h": "400px",
        height: "100%",
        class: "w-4/5 swpier",
        trigger: "click"
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_el_skeleton, {
              animated: "",
              loading: unref(isLoading),
              class: "ske"
            }, {
              template: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_el_skeleton_item, {
                    "p-4": "",
                    variant: "image",
                    class: "sk-imgs",
                    "p-2": ""
                  }, null, _parent3, _scopeId2));
                  _push3(`<div p-4 flex-col style="${ssrRenderStyle({ "height": "100%" })}" justify-around data-v-2370c169${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_el_skeleton_item, {
                    variant: "p",
                    "mb-1": "",
                    style: { "width": "70%" }
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_el_skeleton_item, {
                    variant: "p",
                    "mb-1": "",
                    style: { "width": "100%" }
                  }, null, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode(_component_el_skeleton_item, {
                      "p-4": "",
                      variant: "image",
                      class: "sk-imgs",
                      "p-2": ""
                    }),
                    createVNode("div", {
                      "p-4": "",
                      "flex-col": "",
                      style: { "height": "100%" },
                      "justify-around": ""
                    }, [
                      createVNode(_component_el_skeleton_item, {
                        variant: "p",
                        "mb-1": "",
                        style: { "width": "70%" }
                      }),
                      createVNode(_component_el_skeleton_item, {
                        variant: "p",
                        "mb-1": "",
                        style: { "width": "100%" }
                      })
                    ])
                  ];
                }
              }),
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<!--[-->`);
                  ssrRenderList(unref(eventList), (p) => {
                    _push3(ssrRenderComponent(_component_el_carousel_item, {
                      onClick: ($event) => toEventDetailView(p.id),
                      key: p.id,
                      class: "swiper-item"
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(ssrRenderComponent(_component_ClientOnly, null, {}, _parent4, _scopeId3));
                          _push4(`<section class="tip" px-6 py-2 tracking-0.2em text-xs line-height-none md:text-1em md:line-height-normal data-v-2370c169${_scopeId3}><h3 class="title" py-1 data-v-2370c169${_scopeId3}>${ssrInterpolate(p.title)}</h3>`);
                          if (unref(getEndDay)(p.startTime, p.endTime) < 0) {
                            _push4(`<p opacity-80 style="${ssrRenderStyle({ "text-decoration": "line-through" })}" data-v-2370c169${_scopeId3}>\u6D3B\u52A8\u5DF2\u7ECF\u7ED3\u675F</p>`);
                          } else {
                            _push4(`<!---->`);
                          }
                          if (unref(getEndDay)(p.startTime, p.endTime) === 0) {
                            _push4(`<p opacity-80 style="${ssrRenderStyle({ "color": "var(--el-color-success)" })}" data-v-2370c169${_scopeId3}>\u6D3B\u52A8\u5373\u5C06\u5F00\u59CB </p>`);
                          } else if (unref(getEndDay)(p.startTime, p.endTime) > 0) {
                            _push4(`<p opacity-80 data-v-2370c169${_scopeId3}>\u8DDD\u79BB\u7ED3\u675F\u8FD8\u6709\uFF1A<strong text-lg style="${ssrRenderStyle({ "color": "var(--el-color-error)" })}" data-v-2370c169${_scopeId3}>${ssrInterpolate(unref(getEndDay)(p.startTime, p.endTime))}</strong> \u5929 <span cursor-pointer float-right opacity-60 data-v-2370c169${_scopeId3}>\u66F4\u591A</span></p>`);
                          } else {
                            _push4(`<!---->`);
                          }
                          _push4(`</section>`);
                        } else {
                          return [
                            createVNode(_component_ClientOnly, null, {
                              default: withCtx(() => [
                                createVNode(_component_el_image, {
                                  class: [!unref(isLoading) ? " animate__blurIn" : "", "e-img"],
                                  src: ("baseUrlImg" in _ctx ? _ctx.baseUrlImg : unref(baseUrlImg)) + p.images,
                                  alt: p.details,
                                  style: { "width": "100%", "height": "100%" },
                                  fit: "fill"
                                }, {
                                  error: withCtx(() => [
                                    createVNode("div", {
                                      class: "image-slot",
                                      "flex-row-c-c": ""
                                    }, [
                                      createVNode(_component_ElIconPicture, {
                                        "w-sm": "",
                                        "p-30": "",
                                        "pt-20": "",
                                        "opacity-80": "",
                                        "flex-row-c-c": ""
                                      })
                                    ])
                                  ]),
                                  _: 2
                                }, 1032, ["class", "src", "alt"])
                              ]),
                              _: 2
                            }, 1024),
                            createVNode("section", {
                              class: "tip",
                              "px-6": "",
                              "py-2": "",
                              "tracking-0.2em": "",
                              "text-xs": "",
                              "line-height-none": "",
                              "md:text-1em": "",
                              "md:line-height-normal": ""
                            }, [
                              createVNode("h3", {
                                class: "title",
                                "py-1": ""
                              }, toDisplayString(p.title), 1),
                              unref(getEndDay)(p.startTime, p.endTime) < 0 ? (openBlock(), createBlock("p", {
                                key: 0,
                                "opacity-80": "",
                                style: { "text-decoration": "line-through" }
                              }, "\u6D3B\u52A8\u5DF2\u7ECF\u7ED3\u675F")) : createCommentVNode("", true),
                              unref(getEndDay)(p.startTime, p.endTime) === 0 ? (openBlock(), createBlock("p", {
                                key: 1,
                                "opacity-80": "",
                                style: { "color": "var(--el-color-success)" }
                              }, "\u6D3B\u52A8\u5373\u5C06\u5F00\u59CB ")) : unref(getEndDay)(p.startTime, p.endTime) > 0 ? (openBlock(), createBlock("p", {
                                key: 2,
                                "opacity-80": ""
                              }, [
                                createTextVNode("\u8DDD\u79BB\u7ED3\u675F\u8FD8\u6709\uFF1A"),
                                createVNode("strong", {
                                  "text-lg": "",
                                  style: { "color": "var(--el-color-error)" }
                                }, toDisplayString(unref(getEndDay)(p.startTime, p.endTime)), 1),
                                createTextVNode(" \u5929 "),
                                createVNode("span", {
                                  "cursor-pointer": "",
                                  "float-right": "",
                                  "opacity-60": ""
                                }, "\u66F4\u591A")
                              ])) : createCommentVNode("", true)
                            ])
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    (openBlock(true), createBlock(Fragment, null, renderList(unref(eventList), (p) => {
                      return openBlock(), createBlock(_component_el_carousel_item, {
                        onClick: ($event) => toEventDetailView(p.id),
                        key: p.id,
                        class: "swiper-item"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_ClientOnly, null, {
                            default: withCtx(() => [
                              createVNode(_component_el_image, {
                                class: [!unref(isLoading) ? " animate__blurIn" : "", "e-img"],
                                src: ("baseUrlImg" in _ctx ? _ctx.baseUrlImg : unref(baseUrlImg)) + p.images,
                                alt: p.details,
                                style: { "width": "100%", "height": "100%" },
                                fit: "fill"
                              }, {
                                error: withCtx(() => [
                                  createVNode("div", {
                                    class: "image-slot",
                                    "flex-row-c-c": ""
                                  }, [
                                    createVNode(_component_ElIconPicture, {
                                      "w-sm": "",
                                      "p-30": "",
                                      "pt-20": "",
                                      "opacity-80": "",
                                      "flex-row-c-c": ""
                                    })
                                  ])
                                ]),
                                _: 2
                              }, 1032, ["class", "src", "alt"])
                            ]),
                            _: 2
                          }, 1024),
                          createVNode("section", {
                            class: "tip",
                            "px-6": "",
                            "py-2": "",
                            "tracking-0.2em": "",
                            "text-xs": "",
                            "line-height-none": "",
                            "md:text-1em": "",
                            "md:line-height-normal": ""
                          }, [
                            createVNode("h3", {
                              class: "title",
                              "py-1": ""
                            }, toDisplayString(p.title), 1),
                            unref(getEndDay)(p.startTime, p.endTime) < 0 ? (openBlock(), createBlock("p", {
                              key: 0,
                              "opacity-80": "",
                              style: { "text-decoration": "line-through" }
                            }, "\u6D3B\u52A8\u5DF2\u7ECF\u7ED3\u675F")) : createCommentVNode("", true),
                            unref(getEndDay)(p.startTime, p.endTime) === 0 ? (openBlock(), createBlock("p", {
                              key: 1,
                              "opacity-80": "",
                              style: { "color": "var(--el-color-success)" }
                            }, "\u6D3B\u52A8\u5373\u5C06\u5F00\u59CB ")) : unref(getEndDay)(p.startTime, p.endTime) > 0 ? (openBlock(), createBlock("p", {
                              key: 2,
                              "opacity-80": ""
                            }, [
                              createTextVNode("\u8DDD\u79BB\u7ED3\u675F\u8FD8\u6709\uFF1A"),
                              createVNode("strong", {
                                "text-lg": "",
                                style: { "color": "var(--el-color-error)" }
                              }, toDisplayString(unref(getEndDay)(p.startTime, p.endTime)), 1),
                              createTextVNode(" \u5929 "),
                              createVNode("span", {
                                "cursor-pointer": "",
                                "float-right": "",
                                "opacity-60": ""
                              }, "\u66F4\u591A")
                            ])) : createCommentVNode("", true)
                          ])
                        ]),
                        _: 2
                      }, 1032, ["onClick"]);
                    }), 128))
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_el_skeleton, {
                animated: "",
                loading: unref(isLoading),
                class: "ske"
              }, {
                template: withCtx(() => [
                  createVNode(_component_el_skeleton_item, {
                    "p-4": "",
                    variant: "image",
                    class: "sk-imgs",
                    "p-2": ""
                  }),
                  createVNode("div", {
                    "p-4": "",
                    "flex-col": "",
                    style: { "height": "100%" },
                    "justify-around": ""
                  }, [
                    createVNode(_component_el_skeleton_item, {
                      variant: "p",
                      "mb-1": "",
                      style: { "width": "70%" }
                    }),
                    createVNode(_component_el_skeleton_item, {
                      variant: "p",
                      "mb-1": "",
                      style: { "width": "100%" }
                    })
                  ])
                ]),
                default: withCtx(() => [
                  (openBlock(true), createBlock(Fragment, null, renderList(unref(eventList), (p) => {
                    return openBlock(), createBlock(_component_el_carousel_item, {
                      onClick: ($event) => toEventDetailView(p.id),
                      key: p.id,
                      class: "swiper-item"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_ClientOnly, null, {
                          default: withCtx(() => [
                            createVNode(_component_el_image, {
                              class: [!unref(isLoading) ? " animate__blurIn" : "", "e-img"],
                              src: ("baseUrlImg" in _ctx ? _ctx.baseUrlImg : unref(baseUrlImg)) + p.images,
                              alt: p.details,
                              style: { "width": "100%", "height": "100%" },
                              fit: "fill"
                            }, {
                              error: withCtx(() => [
                                createVNode("div", {
                                  class: "image-slot",
                                  "flex-row-c-c": ""
                                }, [
                                  createVNode(_component_ElIconPicture, {
                                    "w-sm": "",
                                    "p-30": "",
                                    "pt-20": "",
                                    "opacity-80": "",
                                    "flex-row-c-c": ""
                                  })
                                ])
                              ]),
                              _: 2
                            }, 1032, ["class", "src", "alt"])
                          ]),
                          _: 2
                        }, 1024),
                        createVNode("section", {
                          class: "tip",
                          "px-6": "",
                          "py-2": "",
                          "tracking-0.2em": "",
                          "text-xs": "",
                          "line-height-none": "",
                          "md:text-1em": "",
                          "md:line-height-normal": ""
                        }, [
                          createVNode("h3", {
                            class: "title",
                            "py-1": ""
                          }, toDisplayString(p.title), 1),
                          unref(getEndDay)(p.startTime, p.endTime) < 0 ? (openBlock(), createBlock("p", {
                            key: 0,
                            "opacity-80": "",
                            style: { "text-decoration": "line-through" }
                          }, "\u6D3B\u52A8\u5DF2\u7ECF\u7ED3\u675F")) : createCommentVNode("", true),
                          unref(getEndDay)(p.startTime, p.endTime) === 0 ? (openBlock(), createBlock("p", {
                            key: 1,
                            "opacity-80": "",
                            style: { "color": "var(--el-color-success)" }
                          }, "\u6D3B\u52A8\u5373\u5C06\u5F00\u59CB ")) : unref(getEndDay)(p.startTime, p.endTime) > 0 ? (openBlock(), createBlock("p", {
                            key: 2,
                            "opacity-80": ""
                          }, [
                            createTextVNode("\u8DDD\u79BB\u7ED3\u675F\u8FD8\u6709\uFF1A"),
                            createVNode("strong", {
                              "text-lg": "",
                              style: { "color": "var(--el-color-error)" }
                            }, toDisplayString(unref(getEndDay)(p.startTime, p.endTime)), 1),
                            createTextVNode(" \u5929 "),
                            createVNode("span", {
                              "cursor-pointer": "",
                              "float-right": "",
                              "opacity-60": ""
                            }, "\u66F4\u591A")
                          ])) : createCommentVNode("", true)
                        ])
                      ]),
                      _: 2
                    }, 1032, ["onClick"]);
                  }), 128))
                ]),
                _: 1
              }, 8, ["loading"])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Index/Swiper.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-2370c169"]]);
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "GoodsLine",
  __ssrInlineRender: true,
  props: {
    goods: {
      type: Object,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    const p = props.goods;
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ClientOnly = __nuxt_component_0$2;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "card",
        "flex-row-bt-c": "",
        "cursor-pointer": "",
        "p-1": ""
      }, _attrs))}>`);
      _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
      _push(`<div px-4 style="${ssrRenderStyle({ "width": "80%", "height": "100%" })}" group flex flex-col items-start justify-between><h3 tracking-1px max-w-12em md:max-w-16em class="overflow-hidden truncate ...">${ssrInterpolate(unref(p).name)}</h3><p color-red mt-2>\u4EF7\u683C\uFF1A\uFFE5${ssrInterpolate(unref(p).price)}</p><p flex-row-bt-c align-end><small opacity-80 pr-3>\u6D4F\u89C8\u91CF\uFF1A${ssrInterpolate(unref(p).views)}</small><small opacity-80 pr-3>\u9500\u91CF\uFF1A${ssrInterpolate(unref(p).sales)}</small>`);
      ssrRenderSlot(_ctx.$slots, "btn", { goods: unref(p) }, null, _push, _parent);
      _push(`</p></div></div>`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/card/GoodsLine.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "HotGoodsList",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a;
    let __temp, __restore;
    let searchPage = reactive({
      records: [],
      total: 0,
      pages: 0,
      size: 0,
      current: 0
    });
    const hotGoodsList = reactive([]);
    const isLoading = ref(false);
    const page = ref(1);
    const size = ref(6);
    computed(() => searchPage.total > 0 && hotGoodsList.length === searchPage.total);
    useStorage("jiwu_index_search", []);
    isLoading.value = true;
    page.value = 1;
    size.value = 8;
    hotGoodsList.splice(0);
    searchPage = toReactive({
      records: [],
      total: 0,
      pages: 0,
      size: 0,
      current: 0
    });
    const { data } = ([__temp, __restore] = withAsyncContext(() => getGoodsListByPage(page.value, size.value, { viewsSort: Sort.DESC, saleSort: Sort.DESC })), __temp = await __temp, __restore(), __temp);
    const pageData = data.data;
    searchPage = toReactive({ ...pageData });
    (_a = pageData.records) == null ? void 0 : _a.forEach((p) => {
      p.images = typeof p.images === "string" ? p.images.split(",") : [];
      hotGoodsList.push(p);
    });
    setTimeout(() => {
      isLoading.value = false;
    }, 500);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ElScrollbar = ElScrollbar;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_CardGoodsLine = _sfc_main$3;
      const _component_el_button = ElButton;
      const _component_nuxt_link = __nuxt_component_0$1;
      const _component_ElDivider = ElDivider;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "hot-list",
        "mx-a": "",
        "md:ma-0": "",
        "pl-4": ""
      }, _attrs))} data-v-aaae1b44><h3 pl-1 pb-3 data-v-aaae1b44>\u70ED\u95E8\u5546\u54C1 <span p-3 bg-red-6 mx-2 i-solar:fire-bold data-v-aaae1b44></span></h3>`);
      _push(ssrRenderComponent(_component_ElScrollbar, { height: "360" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<!--[-->`);
            ssrRenderList(unref(hotGoodsList), (p, i) => {
              _push2(ssrRenderComponent(_component_NuxtLink, {
                to: `/goods/detail?id=${p.id}`,
                class: "mt-2 animate__animated animate__fadeIn",
                key: p.id
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_component_CardGoodsLine, {
                      goods: p,
                      key: p.id,
                      class: "card"
                    }, {
                      btn: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`<div opacity-0 class="item" float-right data-v-aaae1b44${_scopeId3}>`);
                          _push4(ssrRenderComponent(_component_el_button, {
                            "group:hover:block": "",
                            type: "danger",
                            style: { "padding": "0 1em" }
                          }, {
                            default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(ssrRenderComponent(_component_nuxt_link, {
                                  to: "",
                                  style: { "font-size": "10px" }
                                }, {
                                  default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                    if (_push6) {
                                      _push6(`\u524D\u5F80\u8D2D\u4E70`);
                                    } else {
                                      return [
                                        createTextVNode("\u524D\u5F80\u8D2D\u4E70")
                                      ];
                                    }
                                  }),
                                  _: 2
                                }, _parent5, _scopeId4));
                              } else {
                                return [
                                  createVNode(_component_nuxt_link, {
                                    to: "",
                                    style: { "font-size": "10px" }
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("\u524D\u5F80\u8D2D\u4E70")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 2
                          }, _parent4, _scopeId3));
                          _push4(`</div>`);
                        } else {
                          return [
                            createVNode("div", {
                              "opacity-0": "",
                              class: "item",
                              "float-right": ""
                            }, [
                              createVNode(_component_el_button, {
                                "group:hover:block": "",
                                type: "danger",
                                style: { "padding": "0 1em" }
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_nuxt_link, {
                                    to: "",
                                    style: { "font-size": "10px" }
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("\u524D\u5F80\u8D2D\u4E70")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ])
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                    if (i !== unref(hotGoodsList).length - 1) {
                      _push3(ssrRenderComponent(_component_ElDivider, {
                        "dark:opacity-50": "",
                        style: { "width": "100%", "margin": "0.6em auto", "margin-bottom": "0.8em" }
                      }, null, _parent3, _scopeId2));
                    } else {
                      _push3(`<!---->`);
                    }
                  } else {
                    return [
                      (openBlock(), createBlock(_component_CardGoodsLine, {
                        goods: p,
                        key: p.id,
                        class: "card"
                      }, {
                        btn: withCtx(() => [
                          createVNode("div", {
                            "opacity-0": "",
                            class: "item",
                            "float-right": ""
                          }, [
                            createVNode(_component_el_button, {
                              "group:hover:block": "",
                              type: "danger",
                              style: { "padding": "0 1em" }
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_nuxt_link, {
                                  to: "",
                                  style: { "font-size": "10px" }
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("\u524D\u5F80\u8D2D\u4E70")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ])
                        ]),
                        _: 2
                      }, 1032, ["goods"])),
                      i !== unref(hotGoodsList).length - 1 ? (openBlock(), createBlock(_component_ElDivider, {
                        key: 0,
                        "dark:opacity-50": "",
                        style: { "width": "100%", "margin": "0.6em auto", "margin-bottom": "0.8em" }
                      })) : createCommentVNode("", true)
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            });
            _push2(`<!--]-->`);
          } else {
            return [
              (openBlock(true), createBlock(Fragment, null, renderList(unref(hotGoodsList), (p, i) => {
                return openBlock(), createBlock(_component_NuxtLink, {
                  to: `/goods/detail?id=${p.id}`,
                  class: "mt-2 animate__animated animate__fadeIn",
                  key: p.id
                }, {
                  default: withCtx(() => [
                    (openBlock(), createBlock(_component_CardGoodsLine, {
                      goods: p,
                      key: p.id,
                      class: "card"
                    }, {
                      btn: withCtx(() => [
                        createVNode("div", {
                          "opacity-0": "",
                          class: "item",
                          "float-right": ""
                        }, [
                          createVNode(_component_el_button, {
                            "group:hover:block": "",
                            type: "danger",
                            style: { "padding": "0 1em" }
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_nuxt_link, {
                                to: "",
                                style: { "font-size": "10px" }
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("\u524D\u5F80\u8D2D\u4E70")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ])
                      ]),
                      _: 2
                    }, 1032, ["goods"])),
                    i !== unref(hotGoodsList).length - 1 ? (openBlock(), createBlock(_component_ElDivider, {
                      key: 0,
                      "dark:opacity-50": "",
                      style: { "width": "100%", "margin": "0.6em auto", "margin-bottom": "0.8em" }
                    })) : createCommentVNode("", true)
                  ]),
                  _: 2
                }, 1032, ["to"]);
              }), 128))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Index/HotGoodsList.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_4 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-aaae1b44"]]);
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "CategoryLine",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const data = ([__temp, __restore] = withAsyncContext(() => getGoodsCategoryList()), __temp = await __temp, __restore(), __temp);
    const categoryList = ref(data.data || []);
    const router = useRouter();
    const toView = (item) => {
      router.push({
        path: "/search",
        query: {
          categotyName: item.name,
          categotyId: item.id
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ElScrollbar = ElScrollbar;
      const _component_el_button = ElButton;
      _push(`<!--[--><h3>\u70ED\u95E8\u7C7B\u522B</h3><div class="list">`);
      _push(ssrRenderComponent(_component_ElScrollbar, {
        "min-size": 30,
        "overflow-x-scroll": "",
        "tracking-0.1em": "",
        class: "category animate-delay-100 animate__animated animate__fadeIn",
        style: { "width": "100%" }
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="scroll" flex flex-nowrap${_scopeId}><!--[-->`);
            ssrRenderList(unref(categoryList), (p) => {
              _push2(`<div flex flex-row-c-c mr-2 my-4 relative${_scopeId}>`);
              _push2(ssrRenderComponent(_component_el_button, {
                size: "large",
                class: "first",
                onClick: ($event) => toView(_ctx.k),
                "inline-block": "",
                "mr-2": "",
                style: { "position": "relative", "display": "inline-block", "width": "8em", "height": "4em", "line-height": "100%" },
                "flex-row-c-c": ""
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<img${ssrRenderAttr("src", ("baseUrlImg" in _ctx ? _ctx.baseUrlImg : unref(baseUrlImg)) + p.icon)}${ssrRenderAttr("alt", p.name)} opacity-85 rounded-4px style="${ssrRenderStyle({ "width": "8em", "height": "4em", "object-fit": "cover" })}" absolute top-0 left-0 z-0${_scopeId2}><h3 z-1 text-light${_scopeId2}>${ssrInterpolate(p.name)}</h3>`);
                  } else {
                    return [
                      createVNode("img", {
                        src: ("baseUrlImg" in _ctx ? _ctx.baseUrlImg : unref(baseUrlImg)) + p.icon,
                        alt: p.name,
                        "opacity-85": "",
                        "rounded-4px": "",
                        style: { "width": "8em", "height": "4em", "object-fit": "cover" },
                        absolute: "",
                        "top-0": "",
                        "left-0": "",
                        "z-0": ""
                      }, null, 8, ["src", "alt"]),
                      createVNode("h3", {
                        "z-1": "",
                        "text-light": ""
                      }, toDisplayString(p.name), 1)
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`<!--[-->`);
              ssrRenderList(p == null ? void 0 : p.children, (k) => {
                _push2(ssrRenderComponent(_component_el_button, {
                  onClick: ($event) => toView(k),
                  type: "primary",
                  plain: "",
                  key: k.id,
                  style: { "position": "relative", "width": "8em", "height": "4em", "line-height": "100%" },
                  "my-2": "",
                  "mx-0": "",
                  "flex-row-c-c": ""
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`<img${ssrRenderAttr("src", ("baseUrlImg" in _ctx ? _ctx.baseUrlImg : unref(baseUrlImg)) + k.icon)}${ssrRenderAttr("alt", k.name)} opacity-85 rounded-4px style="${ssrRenderStyle({ "width": "100%", "height": "100%", "object-fit": "cover" })}" absolute top-0 left-0 z-0${_scopeId2}><h3 z-1 text-light${_scopeId2}>${ssrInterpolate(k.name)}</h3>`);
                    } else {
                      return [
                        createVNode("img", {
                          src: ("baseUrlImg" in _ctx ? _ctx.baseUrlImg : unref(baseUrlImg)) + k.icon,
                          alt: k.name,
                          "opacity-85": "",
                          "rounded-4px": "",
                          style: { "width": "100%", "height": "100%", "object-fit": "cover" },
                          absolute: "",
                          "top-0": "",
                          "left-0": "",
                          "z-0": ""
                        }, null, 8, ["src", "alt"]),
                        createVNode("h3", {
                          "z-1": "",
                          "text-light": ""
                        }, toDisplayString(k.name), 1)
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              });
              _push2(`<!--]--></div>`);
            });
            _push2(`<!--]--></div>`);
          } else {
            return [
              createVNode("div", {
                class: "scroll",
                flex: "",
                "flex-nowrap": ""
              }, [
                (openBlock(true), createBlock(Fragment, null, renderList(unref(categoryList), (p) => {
                  return openBlock(), createBlock("div", {
                    flex: "",
                    "flex-row-c-c": "",
                    "mr-2": "",
                    "my-4": "",
                    key: p.id,
                    relative: ""
                  }, [
                    createVNode(_component_el_button, {
                      size: "large",
                      class: "first",
                      onClick: ($event) => toView(_ctx.k),
                      "inline-block": "",
                      "mr-2": "",
                      style: { "position": "relative", "display": "inline-block", "width": "8em", "height": "4em", "line-height": "100%" },
                      "flex-row-c-c": ""
                    }, {
                      default: withCtx(() => [
                        createVNode("img", {
                          src: ("baseUrlImg" in _ctx ? _ctx.baseUrlImg : unref(baseUrlImg)) + p.icon,
                          alt: p.name,
                          "opacity-85": "",
                          "rounded-4px": "",
                          style: { "width": "8em", "height": "4em", "object-fit": "cover" },
                          absolute: "",
                          "top-0": "",
                          "left-0": "",
                          "z-0": ""
                        }, null, 8, ["src", "alt"]),
                        createVNode("h3", {
                          "z-1": "",
                          "text-light": ""
                        }, toDisplayString(p.name), 1)
                      ]),
                      _: 2
                    }, 1032, ["onClick"]),
                    (openBlock(true), createBlock(Fragment, null, renderList(p == null ? void 0 : p.children, (k) => {
                      return openBlock(), createBlock(_component_el_button, {
                        onClick: ($event) => toView(k),
                        type: "primary",
                        plain: "",
                        key: k.id,
                        style: { "position": "relative", "width": "8em", "height": "4em", "line-height": "100%" },
                        "my-2": "",
                        "mx-0": "",
                        "flex-row-c-c": ""
                      }, {
                        default: withCtx(() => [
                          createVNode("img", {
                            src: ("baseUrlImg" in _ctx ? _ctx.baseUrlImg : unref(baseUrlImg)) + k.icon,
                            alt: k.name,
                            "opacity-85": "",
                            "rounded-4px": "",
                            style: { "width": "100%", "height": "100%", "object-fit": "cover" },
                            absolute: "",
                            "top-0": "",
                            "left-0": "",
                            "z-0": ""
                          }, null, 8, ["src", "alt"]),
                          createVNode("h3", {
                            "z-1": "",
                            "text-light": ""
                          }, toDisplayString(k.name), 1)
                        ]),
                        _: 2
                      }, 1032, ["onClick"]);
                    }), 128))
                  ]);
                }), 128))
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><!--]-->`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Index/CategoryLine.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLayout = __nuxt_component_0;
      const _component_IndexTopMenu = _sfc_main$6;
      const _component_IndexCategory = _sfc_main$5;
      const _component_IndexSwiper = __nuxt_component_3;
      const _component_IndexHotGoodsList = __nuxt_component_4;
      const _component_IndexCategoryLine = _sfc_main$1;
      _push(ssrRenderComponent(_component_NuxtLayout, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="index" overflow-x-hidden layout-default${_scopeId}>`);
            _push2(ssrRenderComponent(_component_IndexTopMenu, null, null, _parent2, _scopeId));
            _push2(`<div class="center" flex lg:items-start flex-wrap mt-40px${_scopeId}>`);
            _push2(ssrRenderComponent(_component_IndexCategory, null, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_IndexSwiper, null, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_IndexHotGoodsList, null, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_component_IndexCategoryLine, null, null, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", {
                class: "index",
                "overflow-x-hidden": "",
                "layout-default": ""
              }, [
                createVNode(_component_IndexTopMenu),
                createVNode("div", {
                  class: "center",
                  flex: "",
                  "lg:items-start": "",
                  "flex-wrap": "",
                  "mt-40px": ""
                }, [
                  createVNode(_component_IndexCategory),
                  createVNode(_component_IndexSwiper),
                  createVNode(_component_IndexHotGoodsList)
                ]),
                createVNode(_component_IndexCategoryLine)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-6ba18b15.mjs.map
