import { _ as __nuxt_component_0$1 } from './nuxt-link-1d0a99ed.mjs';
import { B as useUserStore, x as __nuxt_component_1$2, _ as _export_sfc } from '../server.mjs';
import { useSSRContext, defineComponent, mergeProps, ref, withCtx, createVNode } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderSlot, ssrRenderAttr, ssrRenderStyle } from 'vue/server-renderer';
import { _ as _imports_0, a as _imports_1 } from './logo_dark-b7cf3e36.mjs';
import 'ufo';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'destr';
import 'h3';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import 'pinia-plugin-persistedstate';
import 'gsap';
import 'lodash-unified';
import 'nprogress';
import '@kangc/v-md-editor';
import 'async-validator';
import '@ctrl/tinycolor';
import 'defu';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'klona';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';

const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "HeaderMenuSe",
  __ssrInlineRender: true,
  props: {
    topClass: {}
  },
  setup(__props) {
    ref("");
    useUserStore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_ClientOnly = __nuxt_component_1$2;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["nav un-select", _ctx.topClass],
        "flex-row-bt-c": "",
        "py-4": "",
        "px-6": "",
        "text-m": "",
        "dark:text": "light"
      }, _attrs))} data-v-1643ae16><div class="left" flex-row-c-c group data-v-1643ae16>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        "mx-2": "",
        to: "/",
        "flex-row-c-c": "",
        class: "group"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img w-42px object-contain group-hover:opacity-85 transition-300 group-hover:filter-blur-2px${ssrRenderAttr("src", _imports_0)} dark:hidden data-v-1643ae16${_scopeId}><img w-42px object-contain group-hover:opacity-85 transition-300 group-hover:filter-blur-2px${ssrRenderAttr("src", _imports_1)} hidden dark:block data-v-1643ae16${_scopeId}><span transition-300 group-hover:block hidden w-32px h-32px i-solar:home-2-bold absolute left-9 style="${ssrRenderStyle({ "color": "var(--el-text-color-primary)" })}" data-v-1643ae16${_scopeId}></span><span tracking-2 m-4 font-700 text-xl hidden md:inline-block data-v-1643ae16${_scopeId}>\u6781\u7269\u5708</span>`);
          } else {
            return [
              createVNode("img", {
                "w-42px": "",
                "object-contain": "",
                "group-hover:opacity-85": "",
                "transition-300": "",
                "group-hover:filter-blur-2px": "",
                src: _imports_0,
                "dark:hidden": ""
              }),
              createVNode("img", {
                "w-42px": "",
                "object-contain": "",
                "group-hover:opacity-85": "",
                "transition-300": "",
                "group-hover:filter-blur-2px": "",
                src: _imports_1,
                hidden: "",
                "dark:block": ""
              }),
              createVNode("span", {
                "transition-300": "",
                "group-hover:block": "",
                hidden: "",
                "w-32px": "",
                "h-32px": "",
                "i-solar:home-2-bold": "",
                absolute: "",
                "left-9": "",
                style: { "color": "var(--el-text-color-primary)" }
              }),
              createVNode("span", {
                "tracking-2": "",
                "m-4": "",
                "font-700": "",
                "text-xl": "",
                hidden: "",
                "md:inline-block": ""
              }, "\u6781\u7269\u5708")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="right" flex-row-c-c hidden md:flex data-v-1643ae16>`);
      _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/menu/HeaderMenuSe.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-1643ae16"]]);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "user",
  __ssrInlineRender: true,
  props: {
    footer: {
      type: Boolean,
      default: true,
      required: false
    },
    leftMenu: {
      type: Boolean,
      default: true,
      required: false
    },
    menu: {
      default: ["shopcart"],
      required: false
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_MenuHeaderMenuSe = __nuxt_component_0;
      const _component_ClientOnly = __nuxt_component_1$2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "defalut min-h-100vh flex flex-col justify-between" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_MenuHeaderMenuSe, null, null, _parent));
      _push(`<div class="flex flex-1">`);
      _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
      _push(`<div class="w-1/1">`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div></div>`);
      _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/user.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=user-3fc23c14.mjs.map
