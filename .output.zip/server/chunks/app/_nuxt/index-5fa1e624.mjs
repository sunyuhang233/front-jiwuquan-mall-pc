import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_0$1 } from './layout-ae7ff3e5.mjs';
import { b as buildProps, a as useNamespace, e as ElIcon, f as arrow_left_default, g as arrow_right_default, w as withInstall, j as withNoopInstall, k as definePropType, m as mutable, l as full_screen_default, s as scale_to_original_default, i as isNumber, n as close_default, z as zoom_out_default, o as zoom_in_default, r as refresh_left_default, p as refresh_right_default, v as useAttrs$1, y as picture_filled_default, _ as _export_sfc, h as _export_sfc$1, q as useEventListener, A as useNuxtApp, C as useUserStore, S as StatusCode, F as baseUrlImg, t as keysOf, B as __nuxt_component_0$2, D as useHttp, G as picture_default } from '../server.mjs';
import { u as useStorage } from './index-5d11cade.mjs';
import { ref, defineComponent, computed, unref, openBlock, createElementBlock, normalizeClass, withModifiers, createElementVNode, normalizeStyle, createBlock, Transition, withCtx, withDirectives, createVNode, vShow, createCommentVNode, renderSlot, Fragment, renderList, toDisplayString, markRaw, effectScope, shallowRef, watch, nextTick, Teleport, resolveDynamicComponent, useAttrs, mergeProps, toRef, normalizeProps, useSSRContext, inject, getCurrentInstance, provide, onUnmounted, reactive, withAsyncContext, createTextVNode, isRef, isVNode } from 'vue';
import { ssrRenderComponent, ssrRenderAttrs, ssrRenderAttr, ssrInterpolate, ssrRenderStyle, ssrRenderList } from 'vue/server-renderer';
import { throttle, get } from 'lodash-unified';
import { isString, isArray } from '@vue/shared';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'vue-router';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'cookie-es';
import 'pinia-plugin-persistedstate';
import 'nprogress';
import 'async-validator';
import '@ctrl/tinycolor';
import 'axios';
import 'lodash';

const flattedChildren = (children) => {
  const vNodes = isArray(children) ? children : [children];
  const result = [];
  vNodes.forEach((child) => {
    var _a;
    if (isArray(child)) {
      result.push(...flattedChildren(child));
    } else if (isVNode(child) && isArray(child.children)) {
      result.push(...flattedChildren(child.children));
    } else {
      result.push(child);
      if (isVNode(child) && ((_a = child.component) == null ? void 0 : _a.subTree)) {
        result.push(...flattedChildren(child.component.subTree));
      }
    }
  });
  return result;
};
var English = {
  name: "en",
  el: {
    colorpicker: {
      confirm: "OK",
      clear: "Clear",
      defaultLabel: "color picker",
      description: "current color is {color}. press enter to select a new color."
    },
    datepicker: {
      now: "Now",
      today: "Today",
      cancel: "Cancel",
      clear: "Clear",
      confirm: "OK",
      dateTablePrompt: "Use the arrow keys and enter to select the day of the month",
      monthTablePrompt: "Use the arrow keys and enter to select the month",
      yearTablePrompt: "Use the arrow keys and enter to select the year",
      selectedDate: "Selected date",
      selectDate: "Select date",
      selectTime: "Select time",
      startDate: "Start Date",
      startTime: "Start Time",
      endDate: "End Date",
      endTime: "End Time",
      prevYear: "Previous Year",
      nextYear: "Next Year",
      prevMonth: "Previous Month",
      nextMonth: "Next Month",
      year: "",
      month1: "January",
      month2: "February",
      month3: "March",
      month4: "April",
      month5: "May",
      month6: "June",
      month7: "July",
      month8: "August",
      month9: "September",
      month10: "October",
      month11: "November",
      month12: "December",
      week: "week",
      weeks: {
        sun: "Sun",
        mon: "Mon",
        tue: "Tue",
        wed: "Wed",
        thu: "Thu",
        fri: "Fri",
        sat: "Sat"
      },
      weeksFull: {
        sun: "Sunday",
        mon: "Monday",
        tue: "Tuesday",
        wed: "Wednesday",
        thu: "Thursday",
        fri: "Friday",
        sat: "Saturday"
      },
      months: {
        jan: "Jan",
        feb: "Feb",
        mar: "Mar",
        apr: "Apr",
        may: "May",
        jun: "Jun",
        jul: "Jul",
        aug: "Aug",
        sep: "Sep",
        oct: "Oct",
        nov: "Nov",
        dec: "Dec"
      }
    },
    inputNumber: {
      decrease: "decrease number",
      increase: "increase number"
    },
    select: {
      loading: "Loading",
      noMatch: "No matching data",
      noData: "No data",
      placeholder: "Select"
    },
    dropdown: {
      toggleDropdown: "Toggle Dropdown"
    },
    cascader: {
      noMatch: "No matching data",
      loading: "Loading",
      placeholder: "Select",
      noData: "No data"
    },
    pagination: {
      goto: "Go to",
      pagesize: "/page",
      total: "Total {total}",
      pageClassifier: "",
      page: "Page",
      prev: "Go to previous page",
      next: "Go to next page",
      currentPage: "page {pager}",
      prevPages: "Previous {pager} pages",
      nextPages: "Next {pager} pages",
      deprecationWarning: "Deprecated usages detected, please refer to the el-pagination documentation for more details"
    },
    dialog: {
      close: "Close this dialog"
    },
    drawer: {
      close: "Close this dialog"
    },
    messagebox: {
      title: "Message",
      confirm: "OK",
      cancel: "Cancel",
      error: "Illegal input",
      close: "Close this dialog"
    },
    upload: {
      deleteTip: "press delete to remove",
      delete: "Delete",
      preview: "Preview",
      continue: "Continue"
    },
    slider: {
      defaultLabel: "slider between {min} and {max}",
      defaultRangeStartLabel: "pick start value",
      defaultRangeEndLabel: "pick end value"
    },
    table: {
      emptyText: "No Data",
      confirmFilter: "Confirm",
      resetFilter: "Reset",
      clearFilter: "All",
      sumText: "Sum"
    },
    tree: {
      emptyText: "No Data"
    },
    transfer: {
      noMatch: "No matching data",
      noData: "No data",
      titles: ["List 1", "List 2"],
      filterPlaceholder: "Enter keyword",
      noCheckedFormat: "{total} items",
      hasCheckedFormat: "{checked}/{total} checked"
    },
    image: {
      error: "FAILED"
    },
    pageHeader: {
      title: "Back"
    },
    popconfirm: {
      confirmButtonText: "Yes",
      cancelButtonText: "No"
    }
  }
};
const buildTranslator = (locale) => (path, option) => translate(path, option, unref(locale));
const translate = (path, option, locale) => get(locale, path, path).replace(/\{(\w+)\}/g, (_, key) => {
  var _a;
  return `${(_a = option == null ? void 0 : option[key]) != null ? _a : `{${key}}`}`;
});
const buildLocaleContext = (locale) => {
  const lang = computed(() => unref(locale).name);
  const localeRef = isRef(locale) ? locale : ref(locale);
  return {
    lang,
    locale: localeRef,
    t: buildTranslator(locale)
  };
};
const localeContextKey = Symbol("localeContextKey");
const useLocale = (localeOverrides) => {
  const locale = localeOverrides || inject(localeContextKey, ref());
  return buildLocaleContext(computed(() => locale.value || English));
};
const useThrottleRender = (loading, throttle2 = 0) => {
  if (throttle2 === 0)
    return loading;
  const throttled = ref(false);
  let timeoutHandle = 0;
  const dispatchThrottling = () => {
    if (timeoutHandle) {
      clearTimeout(timeoutHandle);
    }
    timeoutHandle = window.setTimeout(() => {
      throttled.value = loading.value;
    }, throttle2);
  };
  watch(() => loading.value, (val) => {
    if (val) {
      dispatchThrottling();
    } else {
      throttled.value = val;
    }
  });
  return throttled;
};
const zIndex = ref(0);
const defaultInitialZIndex = 2e3;
const zIndexContextKey = Symbol("zIndexContextKey");
const useZIndex = (zIndexOverrides) => {
  const zIndexInjection = zIndexOverrides || inject(zIndexContextKey, void 0);
  const initialZIndex = computed(() => {
    const zIndexFromInjection = unref(zIndexInjection);
    return isNumber(zIndexFromInjection) ? zIndexFromInjection : defaultInitialZIndex;
  });
  const currentZIndex = computed(() => initialZIndex.value + zIndex.value);
  const nextZIndex = () => {
    zIndex.value++;
    return currentZIndex.value;
  };
  return {
    initialZIndex,
    currentZIndex,
    nextZIndex
  };
};
const getOrderedChildren = (vm, childComponentName, children) => {
  const nodes = flattedChildren(vm.subTree).filter((n) => {
    var _a;
    return isVNode(n) && ((_a = n.type) == null ? void 0 : _a.name) === childComponentName && !!n.component;
  });
  const uids = nodes.map((n) => n.component.uid);
  return uids.map((uid) => children[uid]).filter((p) => !!p);
};
const useOrderedChildren = (vm, childComponentName) => {
  const children = {};
  const orderedChildren = shallowRef([]);
  const addChild = (child) => {
    children[child.uid] = child;
    orderedChildren.value = getOrderedChildren(vm, childComponentName, children);
  };
  const removeChild = (uid) => {
    delete children[uid];
    orderedChildren.value = orderedChildren.value.filter((children2) => children2.uid !== uid);
  };
  return {
    children: orderedChildren,
    addChild,
    removeChild
  };
};
const carouselProps = buildProps({
  initialIndex: {
    type: Number,
    default: 0
  },
  height: {
    type: String,
    default: ""
  },
  trigger: {
    type: String,
    values: ["hover", "click"],
    default: "hover"
  },
  autoplay: {
    type: Boolean,
    default: true
  },
  interval: {
    type: Number,
    default: 3e3
  },
  indicatorPosition: {
    type: String,
    values: ["", "none", "outside"],
    default: ""
  },
  arrow: {
    type: String,
    values: ["always", "hover", "never"],
    default: "hover"
  },
  type: {
    type: String,
    values: ["", "card"],
    default: ""
  },
  loop: {
    type: Boolean,
    default: true
  },
  direction: {
    type: String,
    values: ["horizontal", "vertical"],
    default: "horizontal"
  },
  pauseOnHover: {
    type: Boolean,
    default: true
  }
});
const carouselEmits = {
  change: (current, prev) => [current, prev].every(isNumber)
};
const carouselContextKey = Symbol("carouselContextKey");
const THROTTLE_TIME = 300;
const useCarousel = (props, emit, componentName) => {
  const {
    children: items,
    addChild: addItem,
    removeChild: removeItem
  } = useOrderedChildren(getCurrentInstance(), "ElCarouselItem");
  const activeIndex = ref(-1);
  const timer = ref(null);
  const hover = ref(false);
  const root = ref();
  const containerHeight = ref(0);
  const arrowDisplay = computed(() => props.arrow !== "never" && !unref(isVertical));
  const hasLabel = computed(() => {
    return items.value.some((item) => item.props.label.toString().length > 0);
  });
  const isCardType = computed(() => props.type === "card");
  const isVertical = computed(() => props.direction === "vertical");
  const containerStyle = computed(() => {
    if (props.height !== "auto") {
      return {
        height: props.height
      };
    }
    return {
      height: `${containerHeight.value}px`,
      overflow: "hidden"
    };
  });
  const throttledArrowClick = throttle((index2) => {
    setActiveItem(index2);
  }, THROTTLE_TIME, { trailing: true });
  const throttledIndicatorHover = throttle((index2) => {
    handleIndicatorHover(index2);
  }, THROTTLE_TIME);
  function pauseTimer() {
    if (timer.value) {
      clearInterval(timer.value);
      timer.value = null;
    }
  }
  function startTimer() {
    if (props.interval <= 0 || !props.autoplay || timer.value)
      return;
    timer.value = setInterval(() => playSlides(), props.interval);
  }
  const playSlides = () => {
    if (activeIndex.value < items.value.length - 1) {
      activeIndex.value = activeIndex.value + 1;
    } else if (props.loop) {
      activeIndex.value = 0;
    }
  };
  function setActiveItem(index2) {
    if (isString(index2)) {
      const filteredItems = items.value.filter((item) => item.props.name === index2);
      if (filteredItems.length > 0) {
        index2 = items.value.indexOf(filteredItems[0]);
      }
    }
    index2 = Number(index2);
    if (Number.isNaN(index2) || index2 !== Math.floor(index2)) {
      return;
    }
    const itemCount = items.value.length;
    const oldIndex = activeIndex.value;
    if (index2 < 0) {
      activeIndex.value = props.loop ? itemCount - 1 : 0;
    } else if (index2 >= itemCount) {
      activeIndex.value = props.loop ? 0 : itemCount - 1;
    } else {
      activeIndex.value = index2;
    }
    if (oldIndex === activeIndex.value) {
      resetItemPosition(oldIndex);
    }
    resetTimer();
  }
  function resetItemPosition(oldIndex) {
    items.value.forEach((item, index2) => {
      item.translateItem(index2, activeIndex.value, oldIndex);
    });
  }
  function itemInStage(item, index2) {
    var _a, _b, _c, _d;
    const _items = unref(items);
    const itemCount = _items.length;
    if (itemCount === 0 || !item.states.inStage)
      return false;
    const nextItemIndex = index2 + 1;
    const prevItemIndex = index2 - 1;
    const lastItemIndex = itemCount - 1;
    const isLastItemActive = _items[lastItemIndex].states.active;
    const isFirstItemActive = _items[0].states.active;
    const isNextItemActive = (_b = (_a = _items[nextItemIndex]) == null ? void 0 : _a.states) == null ? void 0 : _b.active;
    const isPrevItemActive = (_d = (_c = _items[prevItemIndex]) == null ? void 0 : _c.states) == null ? void 0 : _d.active;
    if (index2 === lastItemIndex && isFirstItemActive || isNextItemActive) {
      return "left";
    } else if (index2 === 0 && isLastItemActive || isPrevItemActive) {
      return "right";
    }
    return false;
  }
  function handleMouseEnter() {
    hover.value = true;
    if (props.pauseOnHover) {
      pauseTimer();
    }
  }
  function handleMouseLeave() {
    hover.value = false;
    startTimer();
  }
  function handleButtonEnter(arrow) {
    if (unref(isVertical))
      return;
    items.value.forEach((item, index2) => {
      if (arrow === itemInStage(item, index2)) {
        item.states.hover = true;
      }
    });
  }
  function handleButtonLeave() {
    if (unref(isVertical))
      return;
    items.value.forEach((item) => {
      item.states.hover = false;
    });
  }
  function handleIndicatorClick(index2) {
    activeIndex.value = index2;
  }
  function handleIndicatorHover(index2) {
    if (props.trigger === "hover" && index2 !== activeIndex.value) {
      activeIndex.value = index2;
    }
  }
  function prev() {
    setActiveItem(activeIndex.value - 1);
  }
  function next() {
    setActiveItem(activeIndex.value + 1);
  }
  function resetTimer() {
    pauseTimer();
    startTimer();
  }
  function setContainerHeight(height) {
    if (props.height !== "auto")
      return;
    containerHeight.value = height;
  }
  watch(() => activeIndex.value, (current, prev2) => {
    resetItemPosition(prev2);
    if (prev2 > -1) {
      emit("change", current, prev2);
    }
  });
  watch(() => props.autoplay, (autoplay) => {
    autoplay ? startTimer() : pauseTimer();
  });
  watch(() => props.loop, () => {
    setActiveItem(activeIndex.value);
  });
  watch(() => props.interval, () => {
    resetTimer();
  });
  watch(() => items.value, () => {
    if (items.value.length > 0)
      setActiveItem(props.initialIndex);
  });
  shallowRef();
  provide(carouselContextKey, {
    root,
    isCardType,
    isVertical,
    items,
    loop: props.loop,
    addItem,
    removeItem,
    setActiveItem,
    setContainerHeight
  });
  return {
    root,
    activeIndex,
    arrowDisplay,
    hasLabel,
    hover,
    isCardType,
    items,
    isVertical,
    containerStyle,
    handleButtonEnter,
    handleButtonLeave,
    handleIndicatorClick,
    handleMouseEnter,
    handleMouseLeave,
    setActiveItem,
    prev,
    next,
    throttledArrowClick,
    throttledIndicatorHover
  };
};
const _hoisted_1$2 = ["onMouseenter", "onClick"];
const _hoisted_2$1 = { key: 0 };
const COMPONENT_NAME$1 = "ElCarousel";
const __default__$5 = /* @__PURE__ */ defineComponent({
  name: COMPONENT_NAME$1
});
const _sfc_main$a = /* @__PURE__ */ defineComponent({
  ...__default__$5,
  props: carouselProps,
  emits: carouselEmits,
  setup(__props, { expose, emit }) {
    const props = __props;
    const {
      root,
      activeIndex,
      arrowDisplay,
      hasLabel,
      hover,
      isCardType,
      items,
      isVertical,
      containerStyle,
      handleButtonEnter,
      handleButtonLeave,
      handleIndicatorClick,
      handleMouseEnter,
      handleMouseLeave,
      setActiveItem,
      prev,
      next,
      throttledArrowClick,
      throttledIndicatorHover
    } = useCarousel(props, emit);
    const ns = useNamespace("carousel");
    const carouselClasses = computed(() => {
      const classes = [ns.b(), ns.m(props.direction)];
      if (unref(isCardType)) {
        classes.push(ns.m("card"));
      }
      return classes;
    });
    const indicatorsClasses = computed(() => {
      const classes = [ns.e("indicators"), ns.em("indicators", props.direction)];
      if (unref(hasLabel)) {
        classes.push(ns.em("indicators", "labels"));
      }
      if (props.indicatorPosition === "outside") {
        classes.push(ns.em("indicators", "outside"));
      }
      if (unref(isVertical)) {
        classes.push(ns.em("indicators", "right"));
      }
      return classes;
    });
    expose({
      setActiveItem,
      prev,
      next
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        ref_key: "root",
        ref: root,
        class: normalizeClass(unref(carouselClasses)),
        onMouseenter: _cache[6] || (_cache[6] = withModifiers((...args) => unref(handleMouseEnter) && unref(handleMouseEnter)(...args), ["stop"])),
        onMouseleave: _cache[7] || (_cache[7] = withModifiers((...args) => unref(handleMouseLeave) && unref(handleMouseLeave)(...args), ["stop"]))
      }, [
        createElementVNode("div", {
          class: normalizeClass(unref(ns).e("container")),
          style: normalizeStyle(unref(containerStyle))
        }, [
          unref(arrowDisplay) ? (openBlock(), createBlock(Transition, {
            key: 0,
            name: "carousel-arrow-left",
            persisted: ""
          }, {
            default: withCtx(() => [
              withDirectives(createElementVNode("button", {
                type: "button",
                class: normalizeClass([unref(ns).e("arrow"), unref(ns).em("arrow", "left")]),
                onMouseenter: _cache[0] || (_cache[0] = ($event) => unref(handleButtonEnter)("left")),
                onMouseleave: _cache[1] || (_cache[1] = (...args) => unref(handleButtonLeave) && unref(handleButtonLeave)(...args)),
                onClick: _cache[2] || (_cache[2] = withModifiers(($event) => unref(throttledArrowClick)(unref(activeIndex) - 1), ["stop"]))
              }, [
                createVNode(unref(ElIcon), null, {
                  default: withCtx(() => [
                    createVNode(unref(arrow_left_default))
                  ]),
                  _: 1
                })
              ], 34), [
                [
                  vShow,
                  (_ctx.arrow === "always" || unref(hover)) && (props.loop || unref(activeIndex) > 0)
                ]
              ])
            ]),
            _: 1
          })) : createCommentVNode("v-if", true),
          unref(arrowDisplay) ? (openBlock(), createBlock(Transition, {
            key: 1,
            name: "carousel-arrow-right",
            persisted: ""
          }, {
            default: withCtx(() => [
              withDirectives(createElementVNode("button", {
                type: "button",
                class: normalizeClass([unref(ns).e("arrow"), unref(ns).em("arrow", "right")]),
                onMouseenter: _cache[3] || (_cache[3] = ($event) => unref(handleButtonEnter)("right")),
                onMouseleave: _cache[4] || (_cache[4] = (...args) => unref(handleButtonLeave) && unref(handleButtonLeave)(...args)),
                onClick: _cache[5] || (_cache[5] = withModifiers(($event) => unref(throttledArrowClick)(unref(activeIndex) + 1), ["stop"]))
              }, [
                createVNode(unref(ElIcon), null, {
                  default: withCtx(() => [
                    createVNode(unref(arrow_right_default))
                  ]),
                  _: 1
                })
              ], 34), [
                [
                  vShow,
                  (_ctx.arrow === "always" || unref(hover)) && (props.loop || unref(activeIndex) < unref(items).length - 1)
                ]
              ])
            ]),
            _: 1
          })) : createCommentVNode("v-if", true),
          renderSlot(_ctx.$slots, "default")
        ], 6),
        _ctx.indicatorPosition !== "none" ? (openBlock(), createElementBlock("ul", {
          key: 0,
          class: normalizeClass(unref(indicatorsClasses))
        }, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(unref(items), (item, index2) => {
            return openBlock(), createElementBlock("li", {
              key: index2,
              class: normalizeClass([
                unref(ns).e("indicator"),
                unref(ns).em("indicator", _ctx.direction),
                unref(ns).is("active", index2 === unref(activeIndex))
              ]),
              onMouseenter: ($event) => unref(throttledIndicatorHover)(index2),
              onClick: withModifiers(($event) => unref(handleIndicatorClick)(index2), ["stop"])
            }, [
              createElementVNode("button", {
                class: normalizeClass(unref(ns).e("button"))
              }, [
                unref(hasLabel) ? (openBlock(), createElementBlock("span", _hoisted_2$1, toDisplayString(item.props.label), 1)) : createCommentVNode("v-if", true)
              ], 2)
            ], 42, _hoisted_1$2);
          }), 128))
        ], 2)) : createCommentVNode("v-if", true)
      ], 34);
    };
  }
});
var Carousel = /* @__PURE__ */ _export_sfc$1(_sfc_main$a, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/carousel/src/carousel.vue"]]);
const carouselItemProps = buildProps({
  name: { type: String, default: "" },
  label: {
    type: [String, Number],
    default: ""
  }
});
const useCarouselItem = (props, componentName) => {
  const carouselContext = inject(carouselContextKey);
  const instance = getCurrentInstance();
  const carouselItemRef = ref();
  const hover = ref(false);
  const translate2 = ref(0);
  const scale = ref(1);
  const active = ref(false);
  const ready = ref(false);
  const inStage = ref(false);
  const animating = ref(false);
  const { isCardType, isVertical } = carouselContext;
  function handleItemClick() {
    if (carouselContext && unref(isCardType)) {
      const index2 = carouselContext.items.value.findIndex(({ uid }) => uid === instance.uid);
      carouselContext.setActiveItem(index2);
    }
  }
  onUnmounted(() => {
    carouselContext.removeItem(instance.uid);
  });
  return {
    carouselItemRef,
    active,
    animating,
    hover,
    inStage,
    isVertical,
    translate: translate2,
    isCardType,
    scale,
    ready,
    handleItemClick
  };
};
const __default__$4 = /* @__PURE__ */ defineComponent({
  name: "ElCarouselItem"
});
const _sfc_main$9 = /* @__PURE__ */ defineComponent({
  ...__default__$4,
  props: carouselItemProps,
  setup(__props) {
    const ns = useNamespace("carousel");
    const {
      carouselItemRef,
      active,
      animating,
      hover,
      inStage,
      isVertical,
      translate: translate2,
      isCardType,
      scale,
      ready,
      handleItemClick
    } = useCarouselItem();
    const itemStyle = computed(() => {
      const translateType = `translate${unref(isVertical) ? "Y" : "X"}`;
      const _translate = `${translateType}(${unref(translate2)}px)`;
      const _scale = `scale(${unref(scale)})`;
      const transform = [_translate, _scale].join(" ");
      return {
        transform
      };
    });
    return (_ctx, _cache) => {
      return withDirectives((openBlock(), createElementBlock("div", {
        ref_key: "carouselItemRef",
        ref: carouselItemRef,
        class: normalizeClass([
          unref(ns).e("item"),
          unref(ns).is("active", unref(active)),
          unref(ns).is("in-stage", unref(inStage)),
          unref(ns).is("hover", unref(hover)),
          unref(ns).is("animating", unref(animating)),
          {
            [unref(ns).em("item", "card")]: unref(isCardType),
            [unref(ns).em("item", "card-vertical")]: unref(isCardType) && unref(isVertical)
          }
        ]),
        style: normalizeStyle(unref(itemStyle)),
        onClick: _cache[0] || (_cache[0] = (...args) => unref(handleItemClick) && unref(handleItemClick)(...args))
      }, [
        unref(isCardType) ? withDirectives((openBlock(), createElementBlock("div", {
          key: 0,
          class: normalizeClass(unref(ns).e("mask"))
        }, null, 2)), [
          [vShow, !unref(active)]
        ]) : createCommentVNode("v-if", true),
        renderSlot(_ctx.$slots, "default")
      ], 6)), [
        [vShow, unref(ready)]
      ]);
    };
  }
});
var CarouselItem = /* @__PURE__ */ _export_sfc$1(_sfc_main$9, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/carousel/src/carousel-item.vue"]]);
const ElCarousel = withInstall(Carousel, {
  CarouselItem
});
const ElCarouselItem = withNoopInstall(CarouselItem);
const imageViewerProps = buildProps({
  urlList: {
    type: definePropType(Array),
    default: () => mutable([])
  },
  zIndex: {
    type: Number
  },
  initialIndex: {
    type: Number,
    default: 0
  },
  infinite: {
    type: Boolean,
    default: true
  },
  hideOnClickModal: {
    type: Boolean,
    default: false
  },
  teleported: {
    type: Boolean,
    default: false
  },
  closeOnPressEscape: {
    type: Boolean,
    default: true
  },
  zoomRate: {
    type: Number,
    default: 1.2
  }
});
const imageViewerEmits = {
  close: () => true,
  switch: (index2) => isNumber(index2)
};
const _hoisted_1$1 = ["src"];
const __default__$3 = /* @__PURE__ */ defineComponent({
  name: "ElImageViewer"
});
const _sfc_main$8 = /* @__PURE__ */ defineComponent({
  ...__default__$3,
  props: imageViewerProps,
  emits: imageViewerEmits,
  setup(__props, { expose, emit }) {
    const props = __props;
    const modes = {
      CONTAIN: {
        name: "contain",
        icon: markRaw(full_screen_default)
      },
      ORIGINAL: {
        name: "original",
        icon: markRaw(scale_to_original_default)
      }
    };
    const { t } = useLocale();
    const ns = useNamespace("image-viewer");
    const { nextZIndex } = useZIndex();
    const wrapper = ref();
    const imgRefs = ref([]);
    const scopeEventListener = effectScope();
    const loading = ref(true);
    const activeIndex = ref(props.initialIndex);
    const mode = shallowRef(modes.CONTAIN);
    const transform = ref({
      scale: 1,
      deg: 0,
      offsetX: 0,
      offsetY: 0,
      enableTransition: false
    });
    const isSingle = computed(() => {
      const { urlList } = props;
      return urlList.length <= 1;
    });
    const isFirst = computed(() => {
      return activeIndex.value === 0;
    });
    const isLast = computed(() => {
      return activeIndex.value === props.urlList.length - 1;
    });
    const currentImg = computed(() => {
      return props.urlList[activeIndex.value];
    });
    const imgStyle = computed(() => {
      const { scale, deg, offsetX, offsetY, enableTransition } = transform.value;
      let translateX = offsetX / scale;
      let translateY = offsetY / scale;
      switch (deg % 360) {
        case 90:
        case -270:
          [translateX, translateY] = [translateY, -translateX];
          break;
        case 180:
        case -180:
          [translateX, translateY] = [-translateX, -translateY];
          break;
        case 270:
        case -90:
          [translateX, translateY] = [-translateY, translateX];
          break;
      }
      const style = {
        transform: `scale(${scale}) rotate(${deg}deg) translate(${translateX}px, ${translateY}px)`,
        transition: enableTransition ? "transform .3s" : ""
      };
      if (mode.value.name === modes.CONTAIN.name) {
        style.maxWidth = style.maxHeight = "100%";
      }
      return style;
    });
    const computedZIndex = computed(() => {
      return isNumber(props.zIndex) ? props.zIndex : nextZIndex();
    });
    function hide() {
      unregisterEventListener();
      emit("close");
    }
    function unregisterEventListener() {
      scopeEventListener.stop();
    }
    function handleImgLoad() {
      loading.value = false;
    }
    function handleImgError(e) {
      loading.value = false;
      e.target.alt = t("el.image.error");
    }
    function handleMouseDown(e) {
      if (loading.value || e.button !== 0 || !wrapper.value)
        return;
      transform.value.enableTransition = false;
      const { offsetX, offsetY } = transform.value;
      const startX = e.pageX;
      const startY = e.pageY;
      const dragHandler = throttle((ev) => {
        transform.value = {
          ...transform.value,
          offsetX: offsetX + ev.pageX - startX,
          offsetY: offsetY + ev.pageY - startY
        };
      });
      const removeMousemove = useEventListener(document, "mousemove", dragHandler);
      useEventListener(document, "mouseup", () => {
        removeMousemove();
      });
      e.preventDefault();
    }
    function reset() {
      transform.value = {
        scale: 1,
        deg: 0,
        offsetX: 0,
        offsetY: 0,
        enableTransition: false
      };
    }
    function toggleMode() {
      if (loading.value)
        return;
      const modeNames = keysOf(modes);
      const modeValues = Object.values(modes);
      const currentMode = mode.value.name;
      const index2 = modeValues.findIndex((i) => i.name === currentMode);
      const nextIndex = (index2 + 1) % modeNames.length;
      mode.value = modes[modeNames[nextIndex]];
      reset();
    }
    function setActiveItem(index2) {
      const len = props.urlList.length;
      activeIndex.value = (index2 + len) % len;
    }
    function prev() {
      if (isFirst.value && !props.infinite)
        return;
      setActiveItem(activeIndex.value - 1);
    }
    function next() {
      if (isLast.value && !props.infinite)
        return;
      setActiveItem(activeIndex.value + 1);
    }
    function handleActions(action, options = {}) {
      if (loading.value)
        return;
      const { zoomRate, rotateDeg, enableTransition } = {
        zoomRate: props.zoomRate,
        rotateDeg: 90,
        enableTransition: true,
        ...options
      };
      switch (action) {
        case "zoomOut":
          if (transform.value.scale > 0.2) {
            transform.value.scale = Number.parseFloat((transform.value.scale / zoomRate).toFixed(3));
          }
          break;
        case "zoomIn":
          if (transform.value.scale < 7) {
            transform.value.scale = Number.parseFloat((transform.value.scale * zoomRate).toFixed(3));
          }
          break;
        case "clockwise":
          transform.value.deg += rotateDeg;
          break;
        case "anticlockwise":
          transform.value.deg -= rotateDeg;
          break;
      }
      transform.value.enableTransition = enableTransition;
    }
    watch(currentImg, () => {
      nextTick(() => {
        const $img = imgRefs.value[0];
        if (!($img == null ? void 0 : $img.complete)) {
          loading.value = true;
        }
      });
    });
    watch(activeIndex, (val) => {
      reset();
      emit("switch", val);
    });
    expose({
      setActiveItem
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(Teleport, {
        to: "body",
        disabled: !_ctx.teleported
      }, [
        createVNode(Transition, {
          name: "viewer-fade",
          appear: ""
        }, {
          default: withCtx(() => [
            createElementVNode("div", {
              ref_key: "wrapper",
              ref: wrapper,
              tabindex: -1,
              class: normalizeClass(unref(ns).e("wrapper")),
              style: normalizeStyle({ zIndex: unref(computedZIndex) })
            }, [
              createElementVNode("div", {
                class: normalizeClass(unref(ns).e("mask")),
                onClick: _cache[0] || (_cache[0] = withModifiers(($event) => _ctx.hideOnClickModal && hide(), ["self"]))
              }, null, 2),
              createCommentVNode(" CLOSE "),
              createElementVNode("span", {
                class: normalizeClass([unref(ns).e("btn"), unref(ns).e("close")]),
                onClick: hide
              }, [
                createVNode(unref(ElIcon), null, {
                  default: withCtx(() => [
                    createVNode(unref(close_default))
                  ]),
                  _: 1
                })
              ], 2),
              createCommentVNode(" ARROW "),
              !unref(isSingle) ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                createElementVNode("span", {
                  class: normalizeClass([
                    unref(ns).e("btn"),
                    unref(ns).e("prev"),
                    unref(ns).is("disabled", !_ctx.infinite && unref(isFirst))
                  ]),
                  onClick: prev
                }, [
                  createVNode(unref(ElIcon), null, {
                    default: withCtx(() => [
                      createVNode(unref(arrow_left_default))
                    ]),
                    _: 1
                  })
                ], 2),
                createElementVNode("span", {
                  class: normalizeClass([
                    unref(ns).e("btn"),
                    unref(ns).e("next"),
                    unref(ns).is("disabled", !_ctx.infinite && unref(isLast))
                  ]),
                  onClick: next
                }, [
                  createVNode(unref(ElIcon), null, {
                    default: withCtx(() => [
                      createVNode(unref(arrow_right_default))
                    ]),
                    _: 1
                  })
                ], 2)
              ], 64)) : createCommentVNode("v-if", true),
              createCommentVNode(" ACTIONS "),
              createElementVNode("div", {
                class: normalizeClass([unref(ns).e("btn"), unref(ns).e("actions")])
              }, [
                createElementVNode("div", {
                  class: normalizeClass(unref(ns).e("actions__inner"))
                }, [
                  createVNode(unref(ElIcon), {
                    onClick: _cache[1] || (_cache[1] = ($event) => handleActions("zoomOut"))
                  }, {
                    default: withCtx(() => [
                      createVNode(unref(zoom_out_default))
                    ]),
                    _: 1
                  }),
                  createVNode(unref(ElIcon), {
                    onClick: _cache[2] || (_cache[2] = ($event) => handleActions("zoomIn"))
                  }, {
                    default: withCtx(() => [
                      createVNode(unref(zoom_in_default))
                    ]),
                    _: 1
                  }),
                  createElementVNode("i", {
                    class: normalizeClass(unref(ns).e("actions__divider"))
                  }, null, 2),
                  createVNode(unref(ElIcon), { onClick: toggleMode }, {
                    default: withCtx(() => [
                      (openBlock(), createBlock(resolveDynamicComponent(unref(mode).icon)))
                    ]),
                    _: 1
                  }),
                  createElementVNode("i", {
                    class: normalizeClass(unref(ns).e("actions__divider"))
                  }, null, 2),
                  createVNode(unref(ElIcon), {
                    onClick: _cache[3] || (_cache[3] = ($event) => handleActions("anticlockwise"))
                  }, {
                    default: withCtx(() => [
                      createVNode(unref(refresh_left_default))
                    ]),
                    _: 1
                  }),
                  createVNode(unref(ElIcon), {
                    onClick: _cache[4] || (_cache[4] = ($event) => handleActions("clockwise"))
                  }, {
                    default: withCtx(() => [
                      createVNode(unref(refresh_right_default))
                    ]),
                    _: 1
                  })
                ], 2)
              ], 2),
              createCommentVNode(" CANVAS "),
              createElementVNode("div", {
                class: normalizeClass(unref(ns).e("canvas"))
              }, [
                (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.urlList, (url, i) => {
                  return withDirectives((openBlock(), createElementBlock("img", {
                    ref_for: true,
                    ref: (el) => imgRefs.value[i] = el,
                    key: url,
                    src: url,
                    style: normalizeStyle(unref(imgStyle)),
                    class: normalizeClass(unref(ns).e("img")),
                    onLoad: handleImgLoad,
                    onError: handleImgError,
                    onMousedown: handleMouseDown
                  }, null, 46, _hoisted_1$1)), [
                    [vShow, i === activeIndex.value]
                  ]);
                }), 128))
              ], 2),
              renderSlot(_ctx.$slots, "default")
            ], 6)
          ]),
          _: 3
        })
      ], 8, ["disabled"]);
    };
  }
});
var ImageViewer = /* @__PURE__ */ _export_sfc$1(_sfc_main$8, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/image-viewer/src/image-viewer.vue"]]);
const ElImageViewer = withInstall(ImageViewer);
const imageProps = buildProps({
  hideOnClickModal: {
    type: Boolean,
    default: false
  },
  src: {
    type: String,
    default: ""
  },
  fit: {
    type: String,
    values: ["", "contain", "cover", "fill", "none", "scale-down"],
    default: ""
  },
  loading: {
    type: String,
    values: ["eager", "lazy"]
  },
  lazy: {
    type: Boolean,
    default: false
  },
  scrollContainer: {
    type: definePropType([String, Object])
  },
  previewSrcList: {
    type: definePropType(Array),
    default: () => mutable([])
  },
  previewTeleported: {
    type: Boolean,
    default: false
  },
  zIndex: {
    type: Number
  },
  initialIndex: {
    type: Number,
    default: 0
  },
  infinite: {
    type: Boolean,
    default: true
  },
  closeOnPressEscape: {
    type: Boolean,
    default: true
  },
  zoomRate: {
    type: Number,
    default: 1.2
  }
});
const imageEmits = {
  load: (evt) => evt instanceof Event,
  error: (evt) => evt instanceof Event,
  switch: (val) => isNumber(val),
  close: () => true,
  show: () => true
};
const _hoisted_1 = ["src", "loading"];
const _hoisted_2 = { key: 0 };
const __default__$2 = /* @__PURE__ */ defineComponent({
  name: "ElImage",
  inheritAttrs: false
});
const _sfc_main$7 = /* @__PURE__ */ defineComponent({
  ...__default__$2,
  props: imageProps,
  emits: imageEmits,
  setup(__props, { emit }) {
    const props = __props;
    let prevOverflow = "";
    const { t } = useLocale();
    const ns = useNamespace("image");
    const rawAttrs = useAttrs();
    const attrs = useAttrs$1();
    const imageSrc = ref();
    const hasLoadError = ref(false);
    const isLoading = ref(true);
    const showViewer = ref(false);
    const container = ref();
    ref();
    let stopWheelListener;
    const containerStyle = computed(() => rawAttrs.style);
    const imageStyle = computed(() => {
      return {};
    });
    const preview = computed(() => {
      const { previewSrcList } = props;
      return Array.isArray(previewSrcList) && previewSrcList.length > 0;
    });
    const imageIndex = computed(() => {
      const { previewSrcList, initialIndex } = props;
      let previewIndex = initialIndex;
      if (initialIndex > previewSrcList.length - 1) {
        previewIndex = 0;
      }
      return previewIndex;
    });
    const isManual = computed(() => {
      if (props.loading === "eager")
        return false;
      return props.loading === "lazy" || props.lazy;
    });
    function handleLoad(event) {
      isLoading.value = false;
      hasLoadError.value = false;
      emit("load", event);
    }
    function handleError(event) {
      isLoading.value = false;
      hasLoadError.value = true;
      emit("error", event);
    }
    async function addLazyLoadListener() {
      return;
    }
    function wheelHandler(e) {
      if (!e.ctrlKey)
        return;
      if (e.deltaY < 0) {
        e.preventDefault();
        return false;
      } else if (e.deltaY > 0) {
        e.preventDefault();
        return false;
      }
    }
    function clickHandler() {
      if (!preview.value)
        return;
      stopWheelListener = useEventListener("wheel", wheelHandler, {
        passive: false
      });
      prevOverflow = document.body.style.overflow;
      document.body.style.overflow = "hidden";
      showViewer.value = true;
      emit("show");
    }
    function closeViewer() {
      stopWheelListener == null ? void 0 : stopWheelListener();
      document.body.style.overflow = prevOverflow;
      showViewer.value = false;
      emit("close");
    }
    function switchViewer(val) {
      emit("switch", val);
    }
    watch(() => props.src, () => {
      if (isManual.value) {
        isLoading.value = true;
        hasLoadError.value = false;
        addLazyLoadListener();
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        ref_key: "container",
        ref: container,
        class: normalizeClass([unref(ns).b(), _ctx.$attrs.class]),
        style: normalizeStyle(unref(containerStyle))
      }, [
        hasLoadError.value ? renderSlot(_ctx.$slots, "error", { key: 0 }, () => [
          createElementVNode("div", {
            class: normalizeClass(unref(ns).e("error"))
          }, toDisplayString(unref(t)("el.image.error")), 3)
        ]) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
          imageSrc.value !== void 0 ? (openBlock(), createElementBlock("img", mergeProps({ key: 0 }, unref(attrs), {
            src: imageSrc.value,
            loading: _ctx.loading,
            style: unref(imageStyle),
            class: [
              unref(ns).e("inner"),
              unref(preview) && unref(ns).e("preview"),
              isLoading.value && unref(ns).is("loading")
            ],
            onClick: clickHandler,
            onLoad: handleLoad,
            onError: handleError
          }), null, 16, _hoisted_1)) : createCommentVNode("v-if", true),
          isLoading.value ? (openBlock(), createElementBlock("div", {
            key: 1,
            class: normalizeClass(unref(ns).e("wrapper"))
          }, [
            renderSlot(_ctx.$slots, "placeholder", {}, () => [
              createElementVNode("div", {
                class: normalizeClass(unref(ns).e("placeholder"))
              }, null, 2)
            ])
          ], 2)) : createCommentVNode("v-if", true)
        ], 64)),
        unref(preview) ? (openBlock(), createElementBlock(Fragment, { key: 2 }, [
          showViewer.value ? (openBlock(), createBlock(unref(ElImageViewer), {
            key: 0,
            "z-index": _ctx.zIndex,
            "initial-index": unref(imageIndex),
            infinite: _ctx.infinite,
            "zoom-rate": _ctx.zoomRate,
            "url-list": _ctx.previewSrcList,
            "hide-on-click-modal": _ctx.hideOnClickModal,
            teleported: _ctx.previewTeleported,
            "close-on-press-escape": _ctx.closeOnPressEscape,
            onClose: closeViewer,
            onSwitch: switchViewer
          }, {
            default: withCtx(() => [
              _ctx.$slots.viewer ? (openBlock(), createElementBlock("div", _hoisted_2, [
                renderSlot(_ctx.$slots, "viewer")
              ])) : createCommentVNode("v-if", true)
            ]),
            _: 3
          }, 8, ["z-index", "initial-index", "infinite", "zoom-rate", "url-list", "hide-on-click-modal", "teleported", "close-on-press-escape"])) : createCommentVNode("v-if", true)
        ], 64)) : createCommentVNode("v-if", true)
      ], 6);
    };
  }
});
var Image = /* @__PURE__ */ _export_sfc$1(_sfc_main$7, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/image/src/image.vue"]]);
const ElImage = withInstall(Image);
const skeletonProps = buildProps({
  animated: {
    type: Boolean,
    default: false
  },
  count: {
    type: Number,
    default: 1
  },
  rows: {
    type: Number,
    default: 3
  },
  loading: {
    type: Boolean,
    default: true
  },
  throttle: {
    type: Number
  }
});
const skeletonItemProps = buildProps({
  variant: {
    type: String,
    values: [
      "circle",
      "rect",
      "h1",
      "h3",
      "text",
      "caption",
      "p",
      "image",
      "button"
    ],
    default: "text"
  }
});
const __default__$1 = /* @__PURE__ */ defineComponent({
  name: "ElSkeletonItem"
});
const _sfc_main$6 = /* @__PURE__ */ defineComponent({
  ...__default__$1,
  props: skeletonItemProps,
  setup(__props) {
    const ns = useNamespace("skeleton");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass([unref(ns).e("item"), unref(ns).e(_ctx.variant)])
      }, [
        _ctx.variant === "image" ? (openBlock(), createBlock(unref(picture_filled_default), { key: 0 })) : createCommentVNode("v-if", true)
      ], 2);
    };
  }
});
var SkeletonItem = /* @__PURE__ */ _export_sfc$1(_sfc_main$6, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/skeleton/src/skeleton-item.vue"]]);
const __default__ = /* @__PURE__ */ defineComponent({
  name: "ElSkeleton"
});
const _sfc_main$5 = /* @__PURE__ */ defineComponent({
  ...__default__,
  props: skeletonProps,
  setup(__props, { expose }) {
    const props = __props;
    const ns = useNamespace("skeleton");
    const uiLoading = useThrottleRender(toRef(props, "loading"), props.throttle);
    expose({
      uiLoading
    });
    return (_ctx, _cache) => {
      return unref(uiLoading) ? (openBlock(), createElementBlock("div", mergeProps({
        key: 0,
        class: [unref(ns).b(), unref(ns).is("animated", _ctx.animated)]
      }, _ctx.$attrs), [
        (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.count, (i) => {
          return openBlock(), createElementBlock(Fragment, { key: i }, [
            _ctx.loading ? renderSlot(_ctx.$slots, "template", { key: i }, () => [
              createVNode(SkeletonItem, {
                class: normalizeClass(unref(ns).is("first")),
                variant: "p"
              }, null, 8, ["class"]),
              (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.rows, (item) => {
                return openBlock(), createBlock(SkeletonItem, {
                  key: item,
                  class: normalizeClass([
                    unref(ns).e("paragraph"),
                    unref(ns).is("last", item === _ctx.rows && _ctx.rows > 1)
                  ]),
                  variant: "p"
                }, null, 8, ["class"]);
              }), 128))
            ]) : createCommentVNode("v-if", true)
          ], 64);
        }), 128))
      ], 16)) : renderSlot(_ctx.$slots, "default", normalizeProps(mergeProps({ key: 1 }, _ctx.$attrs)));
    };
  }
});
var Skeleton = /* @__PURE__ */ _export_sfc$1(_sfc_main$5, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/skeleton/src/skeleton.vue"]]);
const ElSkeleton = withInstall(Skeleton, {
  SkeletonItem
});
const ElSkeletonItem = withNoopInstall(SkeletonItem);
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "Search",
  __ssrInlineRender: true,
  setup(__props) {
    ref("");
    ref(false);
    ref(false);
    let searchPage = reactive({});
    reactive([]);
    ref(false);
    ref(1);
    ref(8);
    const count = ref(0);
    computed(() => (searchPage == null ? void 0 : searchPage.total) && searchPage.total > 0 && count.value === searchPage.total);
    useStorage("jiwu_index_search", []);
    const app = useNuxtApp();
    let searchInpRef = {};
    app.hook("app:mounted", () => {
      searchInpRef = ref("searchInpRef");
      console.dir(searchInpRef);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ClientOnly = __nuxt_component_0$2;
      _push(ssrRenderComponent(_component_ClientOnly, mergeProps({ class: "right" }, _attrs), {}, _parent));
    };
  }
});
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Index/Search.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-61705c66"]]);
const useNowDateText = (date) => {
  const hours = (/* @__PURE__ */ new Date()).getHours();
  let res = "";
  if (hours > 0 && hours < 6) {
    res = "\u51CC\u6668";
  } else if (hours < 12) {
    res = "\u65E9\u4E0A";
  } else if (hours === 12) {
    res = "\u4E2D\u5348";
  } else if (hours > 12) {
    res = "\u4E0B\u5348";
  } else {
    res = "\u665A\u4E0A";
  }
  return res;
};
const _imports_0 = "" + buildAssetsURL("logo_txt.318d9294.png");
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "TopMenu",
  __ssrInlineRender: true,
  setup(__props) {
    const state = useUserStore();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b;
      const _component_IndexSearch = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "top animate__animated animate-fadeIn",
        "overflow-hidden": "",
        "flex-row-bt-c": "",
        "flex-col": "",
        "md:flex-row": ""
      }, _attrs))}><img absolute bg-color-indigo-6 z-0 flex-2${ssrRenderAttr("src", _imports_0)} filter-blur-40 w-240px alt="\u6781\u7269\u5708 logo"><div class="title" mt-4 mb-8><p text-lg py-2 tracking-1 opacity-80>${ssrInterpolate(("useNowDateText" in _ctx ? _ctx.useNowDateText : unref(useNowDateText))( new Date()))}\u597D\uFF0C${ssrInterpolate(((_b = (_a = unref(state)) == null ? void 0 : _a.user) == null ? void 0 : _b.nickName) || "\u4F60\u8FD8\u672A\u767B\u5F55\uFF01")}</p><h2 tracking-1>\u6B22\u8FCE\u6765\u5230\u6781\u7269\u5708\u5546\u57CE</h2></div>`);
      _push(ssrRenderComponent(_component_IndexSearch, null, null, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Index/TopMenu.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
function getEventsLists() {
  return useHttp.get("/api/event/list");
}
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "Swiper",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const eventList = reactive([]);
    const isLoading = ref(true);
    const data = ([__temp, __restore] = withAsyncContext(() => getEventsLists()), __temp = await __temp, __restore(), __temp);
    if (data.code === StatusCode.SUCCESS) {
      const res = data.data.sort((a, b) => b.status - a.status);
      res.forEach((p) => {
        eventList.push(p);
      });
      if (eventList.length === data.data.length) {
        setTimeout(() => {
          isLoading.value = false;
        }, 500);
      }
    }
    const getEndDay = computed(() => {
      return (a, b) => {
        let newDate = (/* @__PURE__ */ new Date()).getTime();
        let start = Date.parse(a);
        let end = Date.parse(b);
        if (start > newDate) {
          return 0;
        }
        if (end < newDate) {
          return -1;
        }
        return +((end - newDate) / (1 * 24 * 60 * 60 * 1e3)).toFixed(0);
      };
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_el_carousel = ElCarousel;
      const _component_el_skeleton = ElSkeleton;
      const _component_el_skeleton_item = ElSkeletonItem;
      const _component_el_carousel_item = ElCarouselItem;
      const _component_ClientOnly = __nuxt_component_0$2;
      const _component_el_image = ElImage;
      const _component_ElIconPicture = picture_default;
      _push(ssrRenderComponent(_component_el_carousel, mergeProps({
        "rounded-6px": "",
        "cursor-pointer": "",
        interval: 8e3,
        arrow: "hover",
        "md:w": "520px",
        "h-280px": "",
        "md:h": "360px",
        height: "100%",
        class: "swpier",
        trigger: "click"
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_el_skeleton, {
              animated: "",
              loading: unref(isLoading),
              class: "ske"
            }, {
              template: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_el_skeleton_item, {
                    "p-4": "",
                    variant: "image",
                    class: "sk-imgs",
                    "p-2": ""
                  }, null, _parent3, _scopeId2));
                  _push3(`<div p-4 flex-col style="${ssrRenderStyle({ "height": "100%" })}" justify-around data-v-9d0ef2a7${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_el_skeleton_item, {
                    variant: "p",
                    "mb-1": "",
                    style: { "width": "70%" }
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_el_skeleton_item, {
                    variant: "p",
                    "mb-1": "",
                    style: { "width": "100%" }
                  }, null, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode(_component_el_skeleton_item, {
                      "p-4": "",
                      variant: "image",
                      class: "sk-imgs",
                      "p-2": ""
                    }),
                    createVNode("div", {
                      "p-4": "",
                      "flex-col": "",
                      style: { "height": "100%" },
                      "justify-around": ""
                    }, [
                      createVNode(_component_el_skeleton_item, {
                        variant: "p",
                        "mb-1": "",
                        style: { "width": "70%" }
                      }),
                      createVNode(_component_el_skeleton_item, {
                        variant: "p",
                        "mb-1": "",
                        style: { "width": "100%" }
                      })
                    ])
                  ];
                }
              }),
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<!--[-->`);
                  ssrRenderList(unref(eventList), (p) => {
                    _push3(ssrRenderComponent(_component_el_carousel_item, {
                      onClick: ($event) => _ctx.toEventDetailView(p.id),
                      key: p.id,
                      class: "swiper-item"
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(ssrRenderComponent(_component_ClientOnly, null, {}, _parent4, _scopeId3));
                          _push4(`<section class="tip" px-6 py-2 tracking-0.2em text-xs line-height-none md:text-1em md:line-height-normal data-v-9d0ef2a7${_scopeId3}><h3 class="title" py-1 data-v-9d0ef2a7${_scopeId3}>${ssrInterpolate(p.title)}</h3>`);
                          if (unref(getEndDay)(p.startTime, p.endTime) < 0) {
                            _push4(`<p opacity-80 style="${ssrRenderStyle({ "text-decoration": "line-through" })}" data-v-9d0ef2a7${_scopeId3}>\u6D3B\u52A8\u5DF2\u7ECF\u7ED3\u675F</p>`);
                          } else {
                            _push4(`<!---->`);
                          }
                          if (unref(getEndDay)(p.startTime, p.endTime) === 0) {
                            _push4(`<p opacity-80 style="${ssrRenderStyle({ "color": "var(--el-color-success)" })}" data-v-9d0ef2a7${_scopeId3}>\u6D3B\u52A8\u5373\u5C06\u5F00\u59CB </p>`);
                          } else if (unref(getEndDay)(p.startTime, p.endTime) > 0) {
                            _push4(`<p opacity-80 data-v-9d0ef2a7${_scopeId3}>\u8DDD\u79BB\u7ED3\u675F\u8FD8\u6709\uFF1A<strong text-lg style="${ssrRenderStyle({ "color": "var(--el-color-error)" })}" data-v-9d0ef2a7${_scopeId3}>${ssrInterpolate(unref(getEndDay)(p.startTime, p.endTime))}</strong> \u5929 <span cursor-pointer float-right opacity-60 data-v-9d0ef2a7${_scopeId3}>\u66F4\u591A</span></p>`);
                          } else {
                            _push4(`<!---->`);
                          }
                          _push4(`</section>`);
                        } else {
                          return [
                            createVNode(_component_ClientOnly, null, {
                              default: withCtx(() => [
                                createVNode(_component_el_image, {
                                  src: ("baseUrlImg" in _ctx ? _ctx.baseUrlImg : unref(baseUrlImg)) + p.images,
                                  alt: p.details,
                                  class: "e-img",
                                  style: { "width": "100%", "height": "100%" },
                                  fit: "fill"
                                }, {
                                  error: withCtx(() => [
                                    createVNode("div", {
                                      class: "image-slot",
                                      "flex-row-c-c": ""
                                    }, [
                                      createVNode(_component_ElIconPicture, {
                                        "w-sm": "",
                                        "p-30": "",
                                        "pt-20": "",
                                        "opacity-80": "",
                                        "flex-row-c-c": ""
                                      })
                                    ])
                                  ]),
                                  _: 2
                                }, 1032, ["src", "alt"])
                              ]),
                              _: 2
                            }, 1024),
                            createVNode("section", {
                              class: "tip",
                              "px-6": "",
                              "py-2": "",
                              "tracking-0.2em": "",
                              "text-xs": "",
                              "line-height-none": "",
                              "md:text-1em": "",
                              "md:line-height-normal": ""
                            }, [
                              createVNode("h3", {
                                class: "title",
                                "py-1": ""
                              }, toDisplayString(p.title), 1),
                              unref(getEndDay)(p.startTime, p.endTime) < 0 ? (openBlock(), createBlock("p", {
                                key: 0,
                                "opacity-80": "",
                                style: { "text-decoration": "line-through" }
                              }, "\u6D3B\u52A8\u5DF2\u7ECF\u7ED3\u675F")) : createCommentVNode("", true),
                              unref(getEndDay)(p.startTime, p.endTime) === 0 ? (openBlock(), createBlock("p", {
                                key: 1,
                                "opacity-80": "",
                                style: { "color": "var(--el-color-success)" }
                              }, "\u6D3B\u52A8\u5373\u5C06\u5F00\u59CB ")) : unref(getEndDay)(p.startTime, p.endTime) > 0 ? (openBlock(), createBlock("p", {
                                key: 2,
                                "opacity-80": ""
                              }, [
                                createTextVNode("\u8DDD\u79BB\u7ED3\u675F\u8FD8\u6709\uFF1A"),
                                createVNode("strong", {
                                  "text-lg": "",
                                  style: { "color": "var(--el-color-error)" }
                                }, toDisplayString(unref(getEndDay)(p.startTime, p.endTime)), 1),
                                createTextVNode(" \u5929 "),
                                createVNode("span", {
                                  "cursor-pointer": "",
                                  "float-right": "",
                                  "opacity-60": ""
                                }, "\u66F4\u591A")
                              ])) : createCommentVNode("", true)
                            ])
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    (openBlock(true), createBlock(Fragment, null, renderList(unref(eventList), (p) => {
                      return openBlock(), createBlock(_component_el_carousel_item, {
                        onClick: ($event) => _ctx.toEventDetailView(p.id),
                        key: p.id,
                        class: "swiper-item"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_ClientOnly, null, {
                            default: withCtx(() => [
                              createVNode(_component_el_image, {
                                src: ("baseUrlImg" in _ctx ? _ctx.baseUrlImg : unref(baseUrlImg)) + p.images,
                                alt: p.details,
                                class: "e-img",
                                style: { "width": "100%", "height": "100%" },
                                fit: "fill"
                              }, {
                                error: withCtx(() => [
                                  createVNode("div", {
                                    class: "image-slot",
                                    "flex-row-c-c": ""
                                  }, [
                                    createVNode(_component_ElIconPicture, {
                                      "w-sm": "",
                                      "p-30": "",
                                      "pt-20": "",
                                      "opacity-80": "",
                                      "flex-row-c-c": ""
                                    })
                                  ])
                                ]),
                                _: 2
                              }, 1032, ["src", "alt"])
                            ]),
                            _: 2
                          }, 1024),
                          createVNode("section", {
                            class: "tip",
                            "px-6": "",
                            "py-2": "",
                            "tracking-0.2em": "",
                            "text-xs": "",
                            "line-height-none": "",
                            "md:text-1em": "",
                            "md:line-height-normal": ""
                          }, [
                            createVNode("h3", {
                              class: "title",
                              "py-1": ""
                            }, toDisplayString(p.title), 1),
                            unref(getEndDay)(p.startTime, p.endTime) < 0 ? (openBlock(), createBlock("p", {
                              key: 0,
                              "opacity-80": "",
                              style: { "text-decoration": "line-through" }
                            }, "\u6D3B\u52A8\u5DF2\u7ECF\u7ED3\u675F")) : createCommentVNode("", true),
                            unref(getEndDay)(p.startTime, p.endTime) === 0 ? (openBlock(), createBlock("p", {
                              key: 1,
                              "opacity-80": "",
                              style: { "color": "var(--el-color-success)" }
                            }, "\u6D3B\u52A8\u5373\u5C06\u5F00\u59CB ")) : unref(getEndDay)(p.startTime, p.endTime) > 0 ? (openBlock(), createBlock("p", {
                              key: 2,
                              "opacity-80": ""
                            }, [
                              createTextVNode("\u8DDD\u79BB\u7ED3\u675F\u8FD8\u6709\uFF1A"),
                              createVNode("strong", {
                                "text-lg": "",
                                style: { "color": "var(--el-color-error)" }
                              }, toDisplayString(unref(getEndDay)(p.startTime, p.endTime)), 1),
                              createTextVNode(" \u5929 "),
                              createVNode("span", {
                                "cursor-pointer": "",
                                "float-right": "",
                                "opacity-60": ""
                              }, "\u66F4\u591A")
                            ])) : createCommentVNode("", true)
                          ])
                        ]),
                        _: 2
                      }, 1032, ["onClick"]);
                    }), 128))
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_el_skeleton, {
                animated: "",
                loading: unref(isLoading),
                class: "ske"
              }, {
                template: withCtx(() => [
                  createVNode(_component_el_skeleton_item, {
                    "p-4": "",
                    variant: "image",
                    class: "sk-imgs",
                    "p-2": ""
                  }),
                  createVNode("div", {
                    "p-4": "",
                    "flex-col": "",
                    style: { "height": "100%" },
                    "justify-around": ""
                  }, [
                    createVNode(_component_el_skeleton_item, {
                      variant: "p",
                      "mb-1": "",
                      style: { "width": "70%" }
                    }),
                    createVNode(_component_el_skeleton_item, {
                      variant: "p",
                      "mb-1": "",
                      style: { "width": "100%" }
                    })
                  ])
                ]),
                default: withCtx(() => [
                  (openBlock(true), createBlock(Fragment, null, renderList(unref(eventList), (p) => {
                    return openBlock(), createBlock(_component_el_carousel_item, {
                      onClick: ($event) => _ctx.toEventDetailView(p.id),
                      key: p.id,
                      class: "swiper-item"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_ClientOnly, null, {
                          default: withCtx(() => [
                            createVNode(_component_el_image, {
                              src: ("baseUrlImg" in _ctx ? _ctx.baseUrlImg : unref(baseUrlImg)) + p.images,
                              alt: p.details,
                              class: "e-img",
                              style: { "width": "100%", "height": "100%" },
                              fit: "fill"
                            }, {
                              error: withCtx(() => [
                                createVNode("div", {
                                  class: "image-slot",
                                  "flex-row-c-c": ""
                                }, [
                                  createVNode(_component_ElIconPicture, {
                                    "w-sm": "",
                                    "p-30": "",
                                    "pt-20": "",
                                    "opacity-80": "",
                                    "flex-row-c-c": ""
                                  })
                                ])
                              ]),
                              _: 2
                            }, 1032, ["src", "alt"])
                          ]),
                          _: 2
                        }, 1024),
                        createVNode("section", {
                          class: "tip",
                          "px-6": "",
                          "py-2": "",
                          "tracking-0.2em": "",
                          "text-xs": "",
                          "line-height-none": "",
                          "md:text-1em": "",
                          "md:line-height-normal": ""
                        }, [
                          createVNode("h3", {
                            class: "title",
                            "py-1": ""
                          }, toDisplayString(p.title), 1),
                          unref(getEndDay)(p.startTime, p.endTime) < 0 ? (openBlock(), createBlock("p", {
                            key: 0,
                            "opacity-80": "",
                            style: { "text-decoration": "line-through" }
                          }, "\u6D3B\u52A8\u5DF2\u7ECF\u7ED3\u675F")) : createCommentVNode("", true),
                          unref(getEndDay)(p.startTime, p.endTime) === 0 ? (openBlock(), createBlock("p", {
                            key: 1,
                            "opacity-80": "",
                            style: { "color": "var(--el-color-success)" }
                          }, "\u6D3B\u52A8\u5373\u5C06\u5F00\u59CB ")) : unref(getEndDay)(p.startTime, p.endTime) > 0 ? (openBlock(), createBlock("p", {
                            key: 2,
                            "opacity-80": ""
                          }, [
                            createTextVNode("\u8DDD\u79BB\u7ED3\u675F\u8FD8\u6709\uFF1A"),
                            createVNode("strong", {
                              "text-lg": "",
                              style: { "color": "var(--el-color-error)" }
                            }, toDisplayString(unref(getEndDay)(p.startTime, p.endTime)), 1),
                            createTextVNode(" \u5929 "),
                            createVNode("span", {
                              "cursor-pointer": "",
                              "float-right": "",
                              "opacity-60": ""
                            }, "\u66F4\u591A")
                          ])) : createCommentVNode("", true)
                        ])
                      ]),
                      _: 2
                    }, 1032, ["onClick"]);
                  }), 128))
                ]),
                _: 1
              }, 8, ["loading"])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Index/Swiper.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-9d0ef2a7"]]);
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "Category",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ClientOnly = __nuxt_component_0$2;
      _push(ssrRenderComponent(_component_ClientOnly, mergeProps({ class: "category" }, _attrs), null, _parent));
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Index/Category.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-2ab9d5c8"]]);
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_NuxtLayout = __nuxt_component_0$1;
  const _component_IndexTopMenu = _sfc_main$3;
  const _component_IndexSwiper = __nuxt_component_2;
  const _component_IndexCategory = __nuxt_component_3;
  _push(ssrRenderComponent(_component_NuxtLayout, _attrs, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<div class="index" transition-300 w-90vw md:w-70vw p="y-6 x-4" data-v-c9e1e292${_scopeId}>`);
        _push2(ssrRenderComponent(_component_IndexTopMenu, null, null, _parent2, _scopeId));
        _push2(`<div class="center" flex lg:items-start data-v-c9e1e292${_scopeId}>`);
        _push2(ssrRenderComponent(_component_IndexSwiper, null, null, _parent2, _scopeId));
        _push2(`</div>`);
        _push2(ssrRenderComponent(_component_IndexCategory, null, null, _parent2, _scopeId));
        _push2(`</div>`);
      } else {
        return [
          createVNode("div", {
            class: "index",
            "transition-300": "",
            "w-90vw": "",
            "md:w-70vw": "",
            p: "y-6 x-4"
          }, [
            createVNode(_component_IndexTopMenu),
            createVNode("div", {
              class: "center",
              flex: "",
              "lg:items-start": ""
            }, [
              createVNode(_component_IndexSwiper)
            ]),
            createVNode(_component_IndexCategory)
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-c9e1e292"]]);

export { index as default };
//# sourceMappingURL=index-5fa1e624.mjs.map
