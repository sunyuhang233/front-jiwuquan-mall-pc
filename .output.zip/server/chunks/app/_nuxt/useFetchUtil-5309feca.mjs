import { aG as getBaseUrl } from '../server.mjs';

const BaseUrl = getBaseUrl();
const BaseUrlImg = BaseUrl + "/res/image/";
const BaseUrlVideo = BaseUrl + "/res/video/";

export { BaseUrlImg as B, BaseUrlVideo as a, BaseUrl as b };
//# sourceMappingURL=useFetchUtil-5309feca.mjs.map
