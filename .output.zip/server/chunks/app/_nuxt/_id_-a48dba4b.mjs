import { _ as __nuxt_component_0 } from './layout-9cd450dc.mjs';
import { d as buildProps, e as definePropType, m as mutable, f as useNamespace, h as ElIcon, j as arrow_right_default, w as withInstall, k as withNoopInstall, s as star_filled_default, l as iconPropType, n as star_default, o as useSizeProp, p as formContextKey, q as formItemContextKey, r as useFormSize, t as useFormItemInputId, U as UPDATE_MODEL_EVENT, _ as _export_sfc, C as CHANGE_EVENT, g as _export_sfc$1, i as isNumber, v as hasClass, B as useUserStore, D as useShopStore, u as useRouter, a as useRoute, F as useAsyncData, G as navigateTo, b as useHead, x as __nuxt_component_1$2, y as picture_default, z as arrow_left_bold_default, A as arrow_right_bold_default } from '../server.mjs';
import { defineComponent, openBlock, createElementBlock, normalizeClass, unref, renderSlot, createBlock, Transition, mergeProps, toHandlers, withCtx, createElementVNode, withKeys, withModifiers, createTextVNode, toDisplayString, createVNode, withDirectives, vShow, inject, ref, computed, markRaw, watch, normalizeStyle, Fragment, renderList, resolveDynamicComponent, createCommentVNode, useSSRContext, provide, withAsyncContext, reactive, resolveDirective, isRef, toRef } from 'vue';
import { ssrRenderComponent, ssrRenderAttrs, ssrRenderList, ssrRenderTeleport, ssrRenderAttr, ssrInterpolate, ssrRenderStyle } from 'vue/server-renderer';
import { g as getGoodsCategoryByGid, E as ElCarousel, a as ElCarouselItem, b as ElTabs, c as ElTabPane } from './tab-pane-26e79501.mjs';
import { ElImage } from './index-5245db1b.mjs';
import { B as BaseUrlImg, a as BaseUrlVideo, b as BaseUrl } from './useFetchUtil-5309feca.mjs';
import currency from 'currency.js';
import { g as generateId, E as ElText } from './text-338b238d.mjs';
import { isArray, isObject, isString } from '@vue/shared';
import { E as EVENT_CODE } from './index-968ae5e9.mjs';
import { E as ElTag } from './index-d9c790e5.mjs';
import { E as ElScrollbar } from './index-8520e97d.mjs';
import { u as useFetch } from './fetch-da5935af.mjs';
import { castArray } from 'lodash-unified';
import { g as getGoodsInfoById, a as addGoodsViewsById, _ as __nuxt_component_6 } from './GoodsList-c08a2c38.mjs';
import { g as getGoodsSkuByGid } from './sku-fbef5eec.mjs';
import 'vue-router';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'destr';
import 'h3';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'ufo';
import 'cookie-es';
import 'ohash';
import 'pinia-plugin-persistedstate';
import 'gsap';
import 'nprogress';
import '@kangc/v-md-editor';
import 'async-validator';
import '@ctrl/tinycolor';
import 'defu';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'klona';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import './vnode-f2ede823.mjs';
import './index-5453207f.mjs';

const emitChangeFn = (value) => typeof isNumber(value);
const collapseProps = buildProps({
  accordion: Boolean,
  modelValue: {
    type: definePropType([Array, String, Number]),
    default: () => mutable([])
  }
});
const collapseEmits = {
  [UPDATE_MODEL_EVENT]: emitChangeFn,
  [CHANGE_EVENT]: emitChangeFn
};
const collapseContextKey = Symbol("collapseContextKey");
const useCollapse = (props, emit) => {
  const activeNames = ref(castArray(props.modelValue));
  const setActiveNames = (_activeNames) => {
    activeNames.value = _activeNames;
    const value = props.accordion ? activeNames.value[0] : activeNames.value;
    emit(UPDATE_MODEL_EVENT, value);
    emit(CHANGE_EVENT, value);
  };
  const handleItemClick = (name) => {
    if (props.accordion) {
      setActiveNames([activeNames.value[0] === name ? "" : name]);
    } else {
      const _activeNames = [...activeNames.value];
      const index = _activeNames.indexOf(name);
      if (index > -1) {
        _activeNames.splice(index, 1);
      } else {
        _activeNames.push(name);
      }
      setActiveNames(_activeNames);
    }
  };
  watch(() => props.modelValue, () => activeNames.value = castArray(props.modelValue), { deep: true });
  provide(collapseContextKey, {
    activeNames,
    handleItemClick
  });
  return {
    activeNames,
    setActiveNames
  };
};
const useCollapseDOM = () => {
  const ns = useNamespace("collapse");
  const rootKls = computed(() => ns.b());
  return {
    rootKls
  };
};
const __default__$3 = /* @__PURE__ */ defineComponent({
  name: "ElCollapse"
});
const _sfc_main$b = /* @__PURE__ */ defineComponent({
  ...__default__$3,
  props: collapseProps,
  emits: collapseEmits,
  setup(__props, { expose, emit }) {
    const props = __props;
    const { activeNames, setActiveNames } = useCollapse(props, emit);
    const { rootKls } = useCollapseDOM();
    expose({
      activeNames,
      setActiveNames
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(unref(rootKls)),
        role: "tablist",
        "aria-multiselectable": "true"
      }, [
        renderSlot(_ctx.$slots, "default")
      ], 2);
    };
  }
});
var Collapse = /* @__PURE__ */ _export_sfc$1(_sfc_main$b, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/collapse/src/collapse.vue"]]);
const __default__$2 = /* @__PURE__ */ defineComponent({
  name: "ElCollapseTransition"
});
const _sfc_main$a = /* @__PURE__ */ defineComponent({
  ...__default__$2,
  setup(__props) {
    const ns = useNamespace("collapse-transition");
    const on = {
      beforeEnter(el) {
        if (!el.dataset)
          el.dataset = {};
        el.dataset.oldPaddingTop = el.style.paddingTop;
        el.dataset.oldPaddingBottom = el.style.paddingBottom;
        el.style.maxHeight = 0;
        el.style.paddingTop = 0;
        el.style.paddingBottom = 0;
      },
      enter(el) {
        el.dataset.oldOverflow = el.style.overflow;
        if (el.scrollHeight !== 0) {
          el.style.maxHeight = `${el.scrollHeight}px`;
          el.style.paddingTop = el.dataset.oldPaddingTop;
          el.style.paddingBottom = el.dataset.oldPaddingBottom;
        } else {
          el.style.maxHeight = 0;
          el.style.paddingTop = el.dataset.oldPaddingTop;
          el.style.paddingBottom = el.dataset.oldPaddingBottom;
        }
        el.style.overflow = "hidden";
      },
      afterEnter(el) {
        el.style.maxHeight = "";
        el.style.overflow = el.dataset.oldOverflow;
      },
      beforeLeave(el) {
        if (!el.dataset)
          el.dataset = {};
        el.dataset.oldPaddingTop = el.style.paddingTop;
        el.dataset.oldPaddingBottom = el.style.paddingBottom;
        el.dataset.oldOverflow = el.style.overflow;
        el.style.maxHeight = `${el.scrollHeight}px`;
        el.style.overflow = "hidden";
      },
      leave(el) {
        if (el.scrollHeight !== 0) {
          el.style.maxHeight = 0;
          el.style.paddingTop = 0;
          el.style.paddingBottom = 0;
        }
      },
      afterLeave(el) {
        el.style.maxHeight = "";
        el.style.overflow = el.dataset.oldOverflow;
        el.style.paddingTop = el.dataset.oldPaddingTop;
        el.style.paddingBottom = el.dataset.oldPaddingBottom;
      }
    };
    return (_ctx, _cache) => {
      return openBlock(), createBlock(Transition, mergeProps({
        name: unref(ns).b()
      }, toHandlers(on)), {
        default: withCtx(() => [
          renderSlot(_ctx.$slots, "default")
        ]),
        _: 3
      }, 16, ["name"]);
    };
  }
});
var CollapseTransition = /* @__PURE__ */ _export_sfc$1(_sfc_main$a, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/collapse-transition/src/collapse-transition.vue"]]);
CollapseTransition.install = (app) => {
  app.component(CollapseTransition.name, CollapseTransition);
};
const _CollapseTransition = CollapseTransition;
const collapseItemProps = buildProps({
  title: {
    type: String,
    default: ""
  },
  name: {
    type: definePropType([String, Number]),
    default: () => generateId()
  },
  disabled: Boolean
});
const useCollapseItem = (props) => {
  const collapse2 = inject(collapseContextKey);
  const focusing = ref(false);
  const isClick = ref(false);
  const id = ref(generateId());
  const isActive = computed(() => collapse2 == null ? void 0 : collapse2.activeNames.value.includes(props.name));
  const handleFocus = () => {
    setTimeout(() => {
      if (!isClick.value) {
        focusing.value = true;
      } else {
        isClick.value = false;
      }
    }, 50);
  };
  const handleHeaderClick = () => {
    if (props.disabled)
      return;
    collapse2 == null ? void 0 : collapse2.handleItemClick(props.name);
    focusing.value = false;
    isClick.value = true;
  };
  const handleEnterClick = () => {
    collapse2 == null ? void 0 : collapse2.handleItemClick(props.name);
  };
  return {
    focusing,
    id,
    isActive,
    handleFocus,
    handleHeaderClick,
    handleEnterClick
  };
};
const useCollapseItemDOM = (props, { focusing, isActive, id }) => {
  const ns = useNamespace("collapse");
  const rootKls = computed(() => [
    ns.b("item"),
    ns.is("active", unref(isActive)),
    ns.is("disabled", props.disabled)
  ]);
  const headKls = computed(() => [
    ns.be("item", "header"),
    ns.is("active", unref(isActive)),
    { focusing: unref(focusing) && !props.disabled }
  ]);
  const arrowKls = computed(() => [
    ns.be("item", "arrow"),
    ns.is("active", unref(isActive))
  ]);
  const itemWrapperKls = computed(() => ns.be("item", "wrap"));
  const itemContentKls = computed(() => ns.be("item", "content"));
  const scopedContentId = computed(() => ns.b(`content-${unref(id)}`));
  const scopedHeadId = computed(() => ns.b(`head-${unref(id)}`));
  return {
    arrowKls,
    headKls,
    rootKls,
    itemWrapperKls,
    itemContentKls,
    scopedContentId,
    scopedHeadId
  };
};
const _hoisted_1$1 = ["aria-expanded", "aria-controls", "aria-describedby"];
const _hoisted_2$1 = ["id", "tabindex"];
const _hoisted_3 = ["id", "aria-hidden", "aria-labelledby"];
const __default__$1 = /* @__PURE__ */ defineComponent({
  name: "ElCollapseItem"
});
const _sfc_main$9 = /* @__PURE__ */ defineComponent({
  ...__default__$1,
  props: collapseItemProps,
  setup(__props, { expose }) {
    const props = __props;
    const {
      focusing,
      id,
      isActive,
      handleFocus,
      handleHeaderClick,
      handleEnterClick
    } = useCollapseItem(props);
    const {
      arrowKls,
      headKls,
      rootKls,
      itemWrapperKls,
      itemContentKls,
      scopedContentId,
      scopedHeadId
    } = useCollapseItemDOM(props, { focusing, isActive, id });
    expose({
      isActive
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(unref(rootKls))
      }, [
        createElementVNode("div", {
          role: "tab",
          "aria-expanded": unref(isActive),
          "aria-controls": unref(scopedContentId),
          "aria-describedby": unref(scopedContentId)
        }, [
          createElementVNode("div", {
            id: unref(scopedHeadId),
            class: normalizeClass(unref(headKls)),
            role: "button",
            tabindex: _ctx.disabled ? -1 : 0,
            onClick: _cache[0] || (_cache[0] = (...args) => unref(handleHeaderClick) && unref(handleHeaderClick)(...args)),
            onKeypress: _cache[1] || (_cache[1] = withKeys(withModifiers((...args) => unref(handleEnterClick) && unref(handleEnterClick)(...args), ["stop", "prevent"]), ["space", "enter"])),
            onFocus: _cache[2] || (_cache[2] = (...args) => unref(handleFocus) && unref(handleFocus)(...args)),
            onBlur: _cache[3] || (_cache[3] = ($event) => focusing.value = false)
          }, [
            renderSlot(_ctx.$slots, "title", {}, () => [
              createTextVNode(toDisplayString(_ctx.title), 1)
            ]),
            createVNode(unref(ElIcon), {
              class: normalizeClass(unref(arrowKls))
            }, {
              default: withCtx(() => [
                createVNode(unref(arrow_right_default))
              ]),
              _: 1
            }, 8, ["class"])
          ], 42, _hoisted_2$1)
        ], 8, _hoisted_1$1),
        createVNode(unref(_CollapseTransition), null, {
          default: withCtx(() => [
            withDirectives(createElementVNode("div", {
              id: unref(scopedContentId),
              class: normalizeClass(unref(itemWrapperKls)),
              role: "tabpanel",
              "aria-hidden": !unref(isActive),
              "aria-labelledby": unref(scopedHeadId)
            }, [
              createElementVNode("div", {
                class: normalizeClass(unref(itemContentKls))
              }, [
                renderSlot(_ctx.$slots, "default")
              ], 2)
            ], 10, _hoisted_3), [
              [vShow, unref(isActive)]
            ])
          ]),
          _: 3
        })
      ], 2);
    };
  }
});
var CollapseItem = /* @__PURE__ */ _export_sfc$1(_sfc_main$9, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/collapse/src/collapse-item.vue"]]);
const ElCollapse = withInstall(Collapse, {
  CollapseItem
});
const ElCollapseItem = withNoopInstall(CollapseItem);
const rateProps = buildProps({
  modelValue: {
    type: Number,
    default: 0
  },
  id: {
    type: String,
    default: void 0
  },
  lowThreshold: {
    type: Number,
    default: 2
  },
  highThreshold: {
    type: Number,
    default: 4
  },
  max: {
    type: Number,
    default: 5
  },
  colors: {
    type: definePropType([Array, Object]),
    default: () => mutable(["", "", ""])
  },
  voidColor: {
    type: String,
    default: ""
  },
  disabledVoidColor: {
    type: String,
    default: ""
  },
  icons: {
    type: definePropType([Array, Object]),
    default: () => [star_filled_default, star_filled_default, star_filled_default]
  },
  voidIcon: {
    type: iconPropType,
    default: () => star_default
  },
  disabledVoidIcon: {
    type: iconPropType,
    default: () => star_filled_default
  },
  disabled: Boolean,
  allowHalf: Boolean,
  showText: Boolean,
  showScore: Boolean,
  textColor: {
    type: String,
    default: ""
  },
  texts: {
    type: definePropType(Array),
    default: () => mutable([
      "Extremely bad",
      "Disappointed",
      "Fair",
      "Satisfied",
      "Surprise"
    ])
  },
  scoreTemplate: {
    type: String,
    default: "{value}"
  },
  size: useSizeProp,
  label: {
    type: String,
    default: void 0
  },
  clearable: {
    type: Boolean,
    default: false
  }
});
const rateEmits = {
  [CHANGE_EVENT]: (value) => isNumber(value),
  [UPDATE_MODEL_EVENT]: (value) => isNumber(value)
};
const _hoisted_1 = ["id", "aria-label", "aria-labelledby", "aria-valuenow", "aria-valuetext", "aria-valuemax"];
const _hoisted_2 = ["onMousemove", "onClick"];
const __default__ = /* @__PURE__ */ defineComponent({
  name: "ElRate"
});
const _sfc_main$8 = /* @__PURE__ */ defineComponent({
  ...__default__,
  props: rateProps,
  emits: rateEmits,
  setup(__props, { expose, emit }) {
    const props = __props;
    function getValueFromMap(value, map) {
      const isExcludedObject = (val) => isObject(val);
      const matchedKeys = Object.keys(map).map((key) => +key).filter((key) => {
        const val = map[key];
        const excluded = isExcludedObject(val) ? val.excluded : false;
        return excluded ? value < key : value <= key;
      }).sort((a, b) => a - b);
      const matchedValue = map[matchedKeys[0]];
      return isExcludedObject(matchedValue) && matchedValue.value || matchedValue;
    }
    const formContext = inject(formContextKey, void 0);
    const formItemContext = inject(formItemContextKey, void 0);
    const rateSize = useFormSize();
    const ns = useNamespace("rate");
    const { inputId, isLabeledByFormItem } = useFormItemInputId(props, {
      formItemContext
    });
    const currentValue = ref(props.modelValue);
    const hoverIndex = ref(-1);
    const pointerAtLeftHalf = ref(true);
    const rateClasses = computed(() => [ns.b(), ns.m(rateSize.value)]);
    const rateDisabled = computed(() => props.disabled || (formContext == null ? void 0 : formContext.disabled));
    const rateStyles = computed(() => {
      return ns.cssVarBlock({
        "void-color": props.voidColor,
        "disabled-void-color": props.disabledVoidColor,
        "fill-color": activeColor.value
      });
    });
    const text = computed(() => {
      let result = "";
      if (props.showScore) {
        result = props.scoreTemplate.replace(/\{\s*value\s*\}/, rateDisabled.value ? `${props.modelValue}` : `${currentValue.value}`);
      } else if (props.showText) {
        result = props.texts[Math.ceil(currentValue.value) - 1];
      }
      return result;
    });
    const valueDecimal = computed(() => props.modelValue * 100 - Math.floor(props.modelValue) * 100);
    const colorMap = computed(() => isArray(props.colors) ? {
      [props.lowThreshold]: props.colors[0],
      [props.highThreshold]: { value: props.colors[1], excluded: true },
      [props.max]: props.colors[2]
    } : props.colors);
    const activeColor = computed(() => {
      const color = getValueFromMap(currentValue.value, colorMap.value);
      return isObject(color) ? "" : color;
    });
    const decimalStyle = computed(() => {
      let width = "";
      if (rateDisabled.value) {
        width = `${valueDecimal.value}%`;
      } else if (props.allowHalf) {
        width = "50%";
      }
      return {
        color: activeColor.value,
        width
      };
    });
    const componentMap = computed(() => {
      let icons = isArray(props.icons) ? [...props.icons] : { ...props.icons };
      icons = markRaw(icons);
      return isArray(icons) ? {
        [props.lowThreshold]: icons[0],
        [props.highThreshold]: {
          value: icons[1],
          excluded: true
        },
        [props.max]: icons[2]
      } : icons;
    });
    const decimalIconComponent = computed(() => getValueFromMap(props.modelValue, componentMap.value));
    const voidComponent = computed(() => rateDisabled.value ? isString(props.disabledVoidIcon) ? props.disabledVoidIcon : markRaw(props.disabledVoidIcon) : isString(props.voidIcon) ? props.voidIcon : markRaw(props.voidIcon));
    const activeComponent = computed(() => getValueFromMap(currentValue.value, componentMap.value));
    function showDecimalIcon(item) {
      const showWhenDisabled = rateDisabled.value && valueDecimal.value > 0 && item - 1 < props.modelValue && item > props.modelValue;
      const showWhenAllowHalf = props.allowHalf && pointerAtLeftHalf.value && item - 0.5 <= currentValue.value && item > currentValue.value;
      return showWhenDisabled || showWhenAllowHalf;
    }
    function emitValue(value) {
      if (props.clearable && value === props.modelValue) {
        value = 0;
      }
      emit(UPDATE_MODEL_EVENT, value);
      if (props.modelValue !== value) {
        emit("change", value);
      }
    }
    function selectValue(value) {
      if (rateDisabled.value) {
        return;
      }
      if (props.allowHalf && pointerAtLeftHalf.value) {
        emitValue(currentValue.value);
      } else {
        emitValue(value);
      }
    }
    function handleKey(e) {
      if (rateDisabled.value) {
        return;
      }
      let _currentValue = currentValue.value;
      const code = e.code;
      if (code === EVENT_CODE.up || code === EVENT_CODE.right) {
        if (props.allowHalf) {
          _currentValue += 0.5;
        } else {
          _currentValue += 1;
        }
        e.stopPropagation();
        e.preventDefault();
      } else if (code === EVENT_CODE.left || code === EVENT_CODE.down) {
        if (props.allowHalf) {
          _currentValue -= 0.5;
        } else {
          _currentValue -= 1;
        }
        e.stopPropagation();
        e.preventDefault();
      }
      _currentValue = _currentValue < 0 ? 0 : _currentValue;
      _currentValue = _currentValue > props.max ? props.max : _currentValue;
      emit(UPDATE_MODEL_EVENT, _currentValue);
      emit("change", _currentValue);
      return _currentValue;
    }
    function setCurrentValue(value, event) {
      if (rateDisabled.value) {
        return;
      }
      if (props.allowHalf && event) {
        let target = event.target;
        if (hasClass(target, ns.e("item"))) {
          target = target.querySelector(`.${ns.e("icon")}`);
        }
        if (target.clientWidth === 0 || hasClass(target, ns.e("decimal"))) {
          target = target.parentNode;
        }
        pointerAtLeftHalf.value = event.offsetX * 2 <= target.clientWidth;
        currentValue.value = pointerAtLeftHalf.value ? value - 0.5 : value;
      } else {
        currentValue.value = value;
      }
      hoverIndex.value = value;
    }
    function resetCurrentValue() {
      if (rateDisabled.value) {
        return;
      }
      if (props.allowHalf) {
        pointerAtLeftHalf.value = props.modelValue !== Math.floor(props.modelValue);
      }
      currentValue.value = props.modelValue;
      hoverIndex.value = -1;
    }
    watch(() => props.modelValue, (val) => {
      currentValue.value = val;
      pointerAtLeftHalf.value = props.modelValue !== Math.floor(props.modelValue);
    });
    if (!props.modelValue) {
      emit(UPDATE_MODEL_EVENT, 0);
    }
    expose({
      setCurrentValue,
      resetCurrentValue
    });
    return (_ctx, _cache) => {
      var _a;
      return openBlock(), createElementBlock("div", {
        id: unref(inputId),
        class: normalizeClass([unref(rateClasses), unref(ns).is("disabled", unref(rateDisabled))]),
        role: "slider",
        "aria-label": !unref(isLabeledByFormItem) ? _ctx.label || "rating" : void 0,
        "aria-labelledby": unref(isLabeledByFormItem) ? (_a = unref(formItemContext)) == null ? void 0 : _a.labelId : void 0,
        "aria-valuenow": currentValue.value,
        "aria-valuetext": unref(text) || void 0,
        "aria-valuemin": "0",
        "aria-valuemax": _ctx.max,
        tabindex: "0",
        style: normalizeStyle(unref(rateStyles)),
        onKeydown: handleKey
      }, [
        (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.max, (item, key) => {
          return openBlock(), createElementBlock("span", {
            key,
            class: normalizeClass(unref(ns).e("item")),
            onMousemove: ($event) => setCurrentValue(item, $event),
            onMouseleave: resetCurrentValue,
            onClick: ($event) => selectValue(item)
          }, [
            createVNode(unref(ElIcon), {
              class: normalizeClass([
                unref(ns).e("icon"),
                { hover: hoverIndex.value === item },
                unref(ns).is("active", item <= currentValue.value)
              ])
            }, {
              default: withCtx(() => [
                !showDecimalIcon(item) ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                  withDirectives((openBlock(), createBlock(resolveDynamicComponent(unref(activeComponent)), null, null, 512)), [
                    [vShow, item <= currentValue.value]
                  ]),
                  withDirectives((openBlock(), createBlock(resolveDynamicComponent(unref(voidComponent)), null, null, 512)), [
                    [vShow, !(item <= currentValue.value)]
                  ])
                ], 64)) : createCommentVNode("v-if", true),
                showDecimalIcon(item) ? (openBlock(), createBlock(unref(ElIcon), {
                  key: 1,
                  style: normalizeStyle(unref(decimalStyle)),
                  class: normalizeClass([unref(ns).e("icon"), unref(ns).e("decimal")])
                }, {
                  default: withCtx(() => [
                    (openBlock(), createBlock(resolveDynamicComponent(unref(decimalIconComponent))))
                  ]),
                  _: 1
                }, 8, ["style", "class"])) : createCommentVNode("v-if", true)
              ]),
              _: 2
            }, 1032, ["class"])
          ], 42, _hoisted_2);
        }), 128)),
        _ctx.showText || _ctx.showScore ? (openBlock(), createElementBlock("span", {
          key: 0,
          class: normalizeClass(unref(ns).e("text"))
        }, toDisplayString(unref(text)), 3)) : createCommentVNode("v-if", true)
      ], 46, _hoisted_1);
    };
  }
});
var Rate = /* @__PURE__ */ _export_sfc$1(_sfc_main$8, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/rate/src/rate.vue"]]);
const ElRate = withInstall(Rate);
const _sfc_main$7 = /* @__PURE__ */ defineComponent({
  __name: "CategoryTree",
  __ssrInlineRender: true,
  props: {
    gid: {},
    name: {}
  },
  async setup(__props) {
    var _a;
    let __temp, __restore;
    const { gid } = __props;
    const { data } = ([__temp, __restore] = withAsyncContext(() => getGoodsCategoryByGid(gid.toString())), __temp = await __temp, __restore(), __temp);
    ref(((_a = data.value) == null ? void 0 : _a.data) || null);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ClientOnly = __nuxt_component_1$2;
      _push(ssrRenderComponent(_component_ClientOnly, _attrs, {}, _parent));
    };
  }
});
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Goods/CategoryTree.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const _sfc_main$6 = /* @__PURE__ */ defineComponent({
  __name: "PreSwiper",
  __ssrInlineRender: true,
  props: {
    goodsName: {},
    images: {},
    video: {}
  },
  setup(__props, { expose: __expose }) {
    const { goodsName, images, video } = __props;
    const isOpenVideo = ref(false);
    const getImagesPreview = computed(() => {
      return images.map((p) => p = BaseUrlImg + p);
    });
    const swiper = ref();
    const activeSmall = ref(images[0]);
    const setActiveItem = (name) => {
      var _a;
      (_a = swiper.value) == null ? void 0 : _a.setActiveItem(name);
      activeSmall.value = name;
    };
    const changeSwiper = (current) => {
      activeSmall.value = images[current];
    };
    const nextSwiper = () => {
      var _a;
      return (_a = swiper.value) == null ? void 0 : _a.next();
    };
    const prevSwiper = () => {
      var _a;
      return (_a = swiper.value) == null ? void 0 : _a.prev();
    };
    __expose({
      setActiveItem,
      nextSwiper,
      prevSwiper,
      activeSmall
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_el_carousel = ElCarousel;
      const _component_el_carousel_item = ElCarouselItem;
      const _component_el_image = ElImage;
      const _component_ElIconPicture = picture_default;
      const _component_ElIconArrowLeftBold = arrow_left_bold_default;
      const _component_ElIconArrowRightBold = arrow_right_bold_default;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "swiper" }, _attrs))} data-v-b70bbf3f>`);
      _push(ssrRenderComponent(_component_el_carousel, {
        ref_key: "swiper",
        ref: swiper,
        "indicator-position": "none",
        onChange: changeSwiper,
        "rounded-4px": "",
        "cursor-pointer": "",
        interval: 6e3,
        arrow: "hover",
        "h-400px": "",
        height: "100%",
        trigger: "click"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<!--[-->`);
            ssrRenderList(_ctx.images, (p, i) => {
              _push2(ssrRenderComponent(_component_el_carousel_item, {
                key: p,
                name: p,
                class: "swiper-item",
                style: { "width": "100%" }
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_component_el_image, {
                      "preview-teleported": true,
                      "preview-src-list": unref(getImagesPreview),
                      "initial-index": +i,
                      src: ("BaseUrlImg" in _ctx ? _ctx.BaseUrlImg : unref(BaseUrlImg)) + p,
                      alt: _ctx.goodsName || "Design By Kiwi23333",
                      class: "e-img",
                      style: { "width": "100%", "height": "100%" },
                      fit: "scale-down"
                    }, {
                      error: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`<div class="image-slot" flex-row-c-c data-v-b70bbf3f${_scopeId3}>`);
                          _push4(ssrRenderComponent(_component_ElIconPicture, {
                            "w-sm": "",
                            "p-30": "",
                            "pt-20": "",
                            "opacity-80": "",
                            "flex-row-c-c": ""
                          }, null, _parent4, _scopeId3));
                          _push4(`</div>`);
                        } else {
                          return [
                            createVNode("div", {
                              class: "image-slot",
                              "flex-row-c-c": ""
                            }, [
                              createVNode(_component_ElIconPicture, {
                                "w-sm": "",
                                "p-30": "",
                                "pt-20": "",
                                "opacity-80": "",
                                "flex-row-c-c": ""
                              })
                            ])
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(_component_el_image, {
                        "preview-teleported": true,
                        "preview-src-list": unref(getImagesPreview),
                        "initial-index": +i,
                        src: ("BaseUrlImg" in _ctx ? _ctx.BaseUrlImg : unref(BaseUrlImg)) + p,
                        alt: _ctx.goodsName || "Design By Kiwi23333",
                        class: "e-img",
                        style: { "width": "100%", "height": "100%" },
                        fit: "scale-down"
                      }, {
                        error: withCtx(() => [
                          createVNode("div", {
                            class: "image-slot",
                            "flex-row-c-c": ""
                          }, [
                            createVNode(_component_ElIconPicture, {
                              "w-sm": "",
                              "p-30": "",
                              "pt-20": "",
                              "opacity-80": "",
                              "flex-row-c-c": ""
                            })
                          ])
                        ]),
                        _: 2
                      }, 1032, ["preview-src-list", "initial-index", "src", "alt"])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            });
            _push2(`<!--]-->`);
          } else {
            return [
              (openBlock(true), createBlock(Fragment, null, renderList(_ctx.images, (p, i) => {
                return openBlock(), createBlock(_component_el_carousel_item, {
                  key: p,
                  name: p,
                  class: "swiper-item",
                  style: { "width": "100%" }
                }, {
                  default: withCtx(() => [
                    createVNode(_component_el_image, {
                      "preview-teleported": true,
                      "preview-src-list": unref(getImagesPreview),
                      "initial-index": +i,
                      src: ("BaseUrlImg" in _ctx ? _ctx.BaseUrlImg : unref(BaseUrlImg)) + p,
                      alt: _ctx.goodsName || "Design By Kiwi23333",
                      class: "e-img",
                      style: { "width": "100%", "height": "100%" },
                      fit: "scale-down"
                    }, {
                      error: withCtx(() => [
                        createVNode("div", {
                          class: "image-slot",
                          "flex-row-c-c": ""
                        }, [
                          createVNode(_component_ElIconPicture, {
                            "w-sm": "",
                            "p-30": "",
                            "pt-20": "",
                            "opacity-80": "",
                            "flex-row-c-c": ""
                          })
                        ])
                      ]),
                      _: 2
                    }, 1032, ["preview-src-list", "initial-index", "src", "alt"])
                  ]),
                  _: 2
                }, 1032, ["name"]);
              }), 128))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="scale-imgs" mt-4 flex-row-c-c data-v-b70bbf3f>`);
      _push(ssrRenderComponent(_component_ElIconArrowLeftBold, {
        onClick: prevSwiper,
        class: "w-2em h-2em opacity-60 cursor-pointer flex-row-c-c mx-1"
      }, null, _parent));
      _push(`<!--[-->`);
      ssrRenderList(_ctx.images, (p, i) => {
        _push(ssrRenderComponent(_component_el_image, {
          onMouseenter: ($event) => setActiveItem(p),
          class: [{ active: unref(activeSmall) === p }, "scale-img"],
          key: i,
          src: ("BaseUrlImg" in _ctx ? _ctx.BaseUrlImg : unref(BaseUrlImg)) + p,
          alt: _ctx.goodsName || "Design by Kiwi2333",
          style: { "max-width": "6em", "max-height": "4em", "margin": "0 0.4em", "padding": "0", "border-radius": "4px" },
          fit: "contain",
          "transition-300": "",
          "hover:scale-110": ""
        }, {
          error: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="image-slot" flex-row-c-c data-v-b70bbf3f${_scopeId}>`);
              _push2(ssrRenderComponent(_component_ElIconPicture, { style: { "opacity": "0.8" } }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              return [
                createVNode("div", {
                  class: "image-slot",
                  "flex-row-c-c": ""
                }, [
                  createVNode(_component_ElIconPicture, { style: { "opacity": "0.8" } })
                ])
              ];
            }
          }),
          _: 2
        }, _parent));
      });
      _push(`<!--]-->`);
      _push(ssrRenderComponent(_component_ElIconArrowRightBold, {
        onClick: nextSwiper,
        class: "w-2em h-2em opacity-60 cursor-pointer flex-row-c-c mx-1"
      }, null, _parent));
      _push(`</div>`);
      if (_ctx.video) {
        _push(`<small cursor-pointer mx-a mt-2 leading-1.2em bg-gray-200 dark:bg-dark-200 shadow-md p-2 transition-200 hover:scale-110 flex-row-c-c w-6em rounded-2em data-v-b70bbf3f><i i-solar:clapperboard-play-bold p-2.4 mr-1 data-v-b70bbf3f></i> \u89C6\u9891</small>`);
      } else {
        _push(`<!---->`);
      }
      ssrRenderTeleport(_push, (_push2) => {
        if (unref(isOpenVideo)) {
          _push2(`<div class="mock" data-v-b70bbf3f><video class="videoRef"${ssrRenderAttr("src", ("BaseUrlVideo" in _ctx ? _ctx.BaseUrlVideo : unref(BaseUrlVideo)) + _ctx.video)}${ssrRenderAttr("alt", _ctx.goodsName || " By Kiwi23333")}${ssrRenderAttr("name", _ctx.video)} controls data-v-b70bbf3f></video></div>`);
        } else {
          _push2(`<!---->`);
        }
      }, "body", false, _parent);
      _push(`</div>`);
    };
  }
});
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Goods/PreSwiper.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["__scopeId", "data-v-b70bbf3f"]]);
const _sfc_main$5 = /* @__PURE__ */ defineComponent({
  __name: "SkuCard",
  __ssrInlineRender: true,
  props: {
    goodsInfo: {},
    goodsSku: {}
  },
  emits: ["setActiveItem"],
  setup(__props, { emit }) {
    const { goodsInfo, goodsSku } = __props;
    useUserStore();
    useShopStore();
    useRouter();
    ref(false);
    const isAllCheckSku = ref(false);
    ref();
    const form = reactive({
      skuId: "",
      quantity: 1,
      size: "",
      color: "",
      combo: ""
    });
    const sizeList = ref([]);
    const colorList = ref([]);
    const comboList = ref([]);
    const initSku = () => {
      goodsSku == null ? void 0 : goodsSku.map((p) => {
        var _a, _b, _c;
        if (p.size && !sizeList.value.find((k) => k.name === p.size)) {
          (_a = sizeList.value) == null ? void 0 : _a.push({
            id: p.id,
            name: p.size
          });
        }
        if (p.color && !colorList.value.find((k) => k.name === p.color)) {
          (_b = colorList.value) == null ? void 0 : _b.push({
            id: p.id,
            name: p.color,
            image: p.image
          });
        }
        if (p.combo && !comboList.value.find((k) => k.name === p.combo)) {
          (_c = comboList.value) == null ? void 0 : _c.push({
            id: p.id,
            name: p.combo
          });
        }
      });
    };
    initSku();
    watch(
      form,
      (dto) => {
        const item = goodsSku == null ? void 0 : goodsSku.find((p) => {
          return dto.color === (p.color || "") && dto.combo === (p.combo || "") && dto.size === (p.size || "");
        });
        if (item && (item == null ? void 0 : item.id)) {
          isAllCheckSku.value = true;
          form.skuId = item == null ? void 0 : item.id;
        }
      },
      { immediate: true, deep: true }
    );
    computed(() => {
      let count = 0;
      goodsSku == null ? void 0 : goodsSku.forEach((p) => {
        count += p.stock;
      });
      return count;
    });
    computed(() => {
      if (goodsSku) {
        for (const p of goodsSku) {
          if (p.id === form.skuId) {
            return currency(p.price).multiply(form.quantity).value;
          }
        }
      }
      return 0;
    });
    computed(() => {
      var _a;
      return ((_a = goodsSku == null ? void 0 : goodsSku.find((p) => p.id === form.skuId)) == null ? void 0 : _a.stock) || 0;
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ClientOnly = __nuxt_component_1$2;
      resolveDirective("incre-up");
      _push(ssrRenderComponent(_component_ClientOnly, _attrs, {}, _parent));
    };
  }
});
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Goods/SkuCard.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["__scopeId", "data-v-3f05c5cf"]]);
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "GoodsComment",
  __ssrInlineRender: true,
  props: {
    comment: {},
    skuItem: {}
  },
  setup(__props) {
    const { comment, skuItem } = __props;
    const getPreImages = computed(() => {
      return [...comment.images.map((p) => p = BaseUrlImg + p)];
    });
    const getRateComm = (rate2) => {
      let msg = ["\u5F88\u5DEE", "\u5DEE", "\u4E00\u822C", "\u8F83\u6EE1\u610F", "\u5F3A\u70C8\u63A8\u8350"];
      return msg[Math.floor(rate2 - 1)];
    };
    const getProps = (p) => {
      return ((p == null ? void 0 : p.size) || "") + ((p == null ? void 0 : p.color) || "") + ((p == null ? void 0 : p.combo) || "");
    };
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b;
      const _component_ElImage = ElImage;
      const _component_el_rate = ElRate;
      const _component_el_text = ElText;
      const _component_el_tag = ElTag;
      const _component_el_scrollbar = ElScrollbar;
      _push(`<div${ssrRenderAttrs(mergeProps({
        "animate-fade-in": "",
        class: "card w-1/1",
        "border-default-dashed": "",
        "border-2px": "",
        "transition-300": "",
        "hover:shadow-md": "",
        "hover:border": "solid purple-5",
        "rounded-6px": "",
        "p-5": ""
      }, _attrs))}><div class="top flex justify-between">`);
      _push(ssrRenderComponent(_component_ElImage, {
        lazy: "",
        "hover:transform-scale-110": "",
        "transition-300": "",
        src: ("BaseUrlImg" in _ctx ? _ctx.BaseUrlImg : unref(BaseUrlImg)) + _ctx.comment.avatar,
        style: { "width": "3em", "height": "3em" },
        class: "rounded-10em mr-2 border-default-dashed border-1px avatar",
        fit: "cover"
      }, null, _parent));
      _push(`<div flex flex-col justify-around flex-1><p text-0.9em>${ssrInterpolate(_ctx.comment.isAnonymous ? "\u533F\u540D\u7528\u6237" : _ctx.comment.nickName)}</p><div flex-row-c-c justify-start><small mr-4 opacity-80>${ssrInterpolate(_ctx.comment.createTime)}</small>`);
      _push(ssrRenderComponent(_component_el_rate, {
        modelValue: _ctx.comment.rate,
        "onUpdate:modelValue": ($event) => _ctx.comment.rate = $event,
        disabled: "",
        "allow-half": ""
      }, null, _parent));
      _push(ssrRenderComponent(_component_el_text, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(getRateComm(_ctx.comment.rate))}`);
          } else {
            return [
              createTextVNode(toDisplayString(getRateComm(_ctx.comment.rate)), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="right" float-right>`);
      if (_ctx.comment.isRecommend) {
        _push(ssrRenderComponent(_component_el_tag, null, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<i i-solar:like-bold-duotone p-2 mr-1${_scopeId}></i> \u4E70\u5BB6\u63A8\u8350`);
            } else {
              return [
                createVNode("i", {
                  "i-solar:like-bold-duotone": "",
                  "p-2": "",
                  "mr-1": ""
                }),
                createTextVNode(" \u4E70\u5BB6\u63A8\u8350")
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><p class="text text-overflow-2" px-2 mt-2 text-0.9em>${ssrInterpolate(_ctx.comment.content)}</p>`);
      _push(ssrRenderComponent(_component_el_scrollbar, { class: "scroll flex flex-nowrap m-4" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (_ctx.comment.video && _ctx.comment.video !== "default.mp4") {
              _push2(`<video hover:transform-scale-110 transition-300${ssrRenderAttr("src", ("BaseUrlVideo" in _ctx ? _ctx.BaseUrlVideo : unref(BaseUrlVideo)) + _ctx.comment.video)} style="${ssrRenderStyle({ "width": "6em", "height": "6em" })}" class="rounded-4px mr-2 border-default-dashed border-1px" fit="cover"${_scopeId}></video>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<!--[-->`);
            ssrRenderList(_ctx.comment.images, (p, i) => {
              _push2(ssrRenderComponent(_component_ElImage, {
                lazy: "",
                key: p,
                "preview-teleported": "",
                "preview-src-list": unref(getPreImages),
                "hover:transform-scale-110": "",
                "transition-300": "",
                src: ("BaseUrlImg" in _ctx ? _ctx.BaseUrlImg : unref(BaseUrlImg)) + p,
                style: { "width": "6em", "height": "6em" },
                class: "rounded-4px mr-2 border-default-dashed border-1px",
                fit: "cover"
              }, null, _parent2, _scopeId));
            });
            _push2(`<!--]-->`);
          } else {
            return [
              _ctx.comment.video && _ctx.comment.video !== "default.mp4" ? (openBlock(), createBlock("video", {
                key: 0,
                "hover:transform-scale-110": "",
                "transition-300": "",
                src: ("BaseUrlVideo" in _ctx ? _ctx.BaseUrlVideo : unref(BaseUrlVideo)) + _ctx.comment.video,
                style: { "width": "6em", "height": "6em" },
                class: "rounded-4px mr-2 border-default-dashed border-1px",
                fit: "cover"
              }, null, 8, ["src"])) : createCommentVNode("", true),
              (openBlock(true), createBlock(Fragment, null, renderList(_ctx.comment.images, (p, i) => {
                return openBlock(), createBlock(_component_ElImage, {
                  lazy: "",
                  key: p,
                  "preview-teleported": "",
                  "preview-src-list": unref(getPreImages),
                  "hover:transform-scale-110": "",
                  "transition-300": "",
                  src: ("BaseUrlImg" in _ctx ? _ctx.BaseUrlImg : unref(BaseUrlImg)) + p,
                  style: { "width": "6em", "height": "6em" },
                  class: "rounded-4px mr-2 border-default-dashed border-1px",
                  fit: "cover"
                }, null, 8, ["preview-src-list", "src"]);
              }), 128))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="comment-sku" border-default-dashed bg-gray-200 dark:bg-dark-5 border-2px rounded-6px inline-flex items-center ml-4 pr-4 backdrop-blur-3px>`);
      _push(ssrRenderComponent(_component_ElImage, {
        style: [
          ((_a = _ctx.skuItem) == null ? void 0 : _a.image) ? null : { display: "none" },
          { "width": "3em", "height": "3em" }
        ],
        "hover:transform-scale-110": "",
        "transition-300": "",
        src: ("BaseUrlImg" in _ctx ? _ctx.BaseUrlImg : unref(BaseUrlImg)) + ((_b = _ctx.skuItem) == null ? void 0 : _b.image),
        class: "rounded-4px mr-2 border-default-dashed border-1px",
        fit: "cover"
      }, null, _parent));
      _push(`<small>${ssrInterpolate(getProps(_ctx.skuItem))}</small></div><div class="bottom" px-2 flex-row-bt-c><span></span>`);
      _push(ssrRenderComponent(_component_el_text, {
        type: "primary",
        class: "text text-overflow-2",
        "px-2": "",
        "text-0.9em": ""
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` \u56DE\u590D `);
          } else {
            return [
              createTextVNode(" \u56DE\u590D ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/card/GoodsComment.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
function getGoodsCommentPage(page, size, gid) {
  return useFetch(() => BaseUrl + `/goods/comments/${page}/${size}/${gid}`, "$fogQwoeqNq");
}
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "Comments",
  __ssrInlineRender: true,
  props: {
    goodsId: {},
    skuList: {}
  },
  setup(__props) {
    const { goodsId, skuList } = __props;
    useRouter();
    const isLoading = ref(false);
    const commentList = ref([]);
    const page = ref(0);
    const size = ref(10);
    let pageInfo = reactive({
      records: [],
      total: -1,
      pages: -1,
      size: -1,
      current: -1
    });
    const isNoMore = computed(() => commentList.value.length === (pageInfo == null ? void 0 : pageInfo.total));
    const skuMap = reactive(/* @__PURE__ */ new Map());
    skuList == null ? void 0 : skuList.forEach((p) => {
      skuMap.set(p.id, p);
    });
    const loadGoodsPage = async () => {
      var _a;
      if (isLoading.value)
        return;
      isLoading.value = true;
      page.value++;
      const res = await getGoodsCommentPage(page.value, size.value, goodsId);
      let data = (_a = res.data.value) == null ? void 0 : _a.data;
      if (isNoMore.value || (data == null ? void 0 : data.total) === -1) {
        return isLoading.value = false;
      }
      pageInfo = data;
      let timer;
      if (!(data == null ? void 0 : data.records))
        return;
      for await (const p of data.records) {
        await new Promise((resolve) => {
          timer = setTimeout(() => {
            p.images = p.images.split(",");
            commentList.value.push(p);
            clearTimeout(timer ?? void 0);
            timer = null;
            isLoading.value = false;
            return resolve(true);
          }, 50);
        });
      }
    };
    loadGoodsPage();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CardGoodsComment = _sfc_main$4;
      _push(`<!--[--><!--[-->`);
      ssrRenderList(unref(commentList), (p, i) => {
        _push(`<div class="comment-list" style="${ssrRenderStyle({ "width": "100%" })}">`);
        _push(ssrRenderComponent(_component_CardGoodsComment, {
          comment: p,
          "sku-item": unref(skuMap).get(p.skuId)
        }, null, _parent));
        _push(`</div>`);
      });
      _push(`<!--]-->`);
      if (!unref(commentList).length) {
        _push(`<div class="comment-list"><small>\u6682\u65F6\u6CA1\u6709\u8BC4\u8BBA</small></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Goods/Comments.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_el_collapse = ElCollapse;
  const _component_el_collapse_item = ElCollapseItem;
  _push(`<div${ssrRenderAttrs(_attrs)}>`);
  _push(ssrRenderComponent(_component_el_collapse, { accordion: "" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_el_collapse_item, { name: "1" }, {
          title: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(`<li text-4 my-2 font-700 style="${ssrRenderStyle({ "list-style": "circle" })}"${_scopeId2}> \u5E38\u89C1\u95EE\u9898\uFF1F <i i-solar:question-circle-broken p-2${_scopeId2}></i></li>`);
            } else {
              return [
                createVNode("li", {
                  "text-4": "",
                  "my-2": "",
                  "font-700": "",
                  style: { "list-style": "circle" }
                }, [
                  createTextVNode(" \u5E38\u89C1\u95EE\u9898\uFF1F "),
                  createVNode("i", {
                    "i-solar:question-circle-broken": "",
                    "p-2": ""
                  })
                ])
              ];
            }
          }),
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(`<div${_scopeId2}> 1\u3001\u5982\u4F55\u4E0B\u5355\u8D2D\u4E70\u5546\u54C1\uFF1F<br${_scopeId2}> \u7B54\uFF1A\u5728\u60A8\u6D4F\u89C8\u5546\u54C1\u65F6\uFF0C\u70B9\u51FB\u201C\u52A0\u5165\u8D2D\u7269\u8F66\u201D\uFF0C\u786E\u8BA4\u8D2D\u7269\u8F66\u4E2D\u7684\u5546\u54C1\uFF0C\u7136\u540E\u70B9\u51FB\u201C\u7ED3\u7B97\u5E76\u4ED8\u6B3E\u201D\uFF0C\u9009\u62E9\u4ED8\u6B3E\u65B9\u5F0F\u548C\u6536\u8D27\u5730\u5740\u5373\u53EF\u4E0B\u5355\u8D2D\u4E70\u3002 </div><div${_scopeId2}> 2\u3001\u5546\u54C1\u53D1\u8D27\u65F6\u95F4\u662F\u591A\u4E45\uFF1F<br${_scopeId2}> \u7B54\uFF1A\u901A\u5E38\u60C5\u51B5\u4E0B\uFF0C\u6211\u4EEC\u5C06\u572824\u5C0F\u65F6\u5185\u53D1\u8D27\u3002\u5982\u679C\u51FA\u73B0\u7279\u6B8A\u60C5\u51B5\uFF0C\u4F8B\u5982\u8282\u5047\u65E5\u7B49\uFF0C\u6211\u4EEC\u5C06\u63D0\u524D\u5728\u7F51\u7AD9\u4E0A\u8FDB\u884C\u901A\u77E5\u3002 </div><div${_scopeId2}> 3\u3001\u5982\u4F55\u67E5\u8BE2\u6211\u7684\u8BA2\u5355\u72B6\u6001\uFF1F<br${_scopeId2}> \u7B54\uFF1A\u60A8\u53EF\u4EE5\u5728\u201C\u6211\u7684\u8BA2\u5355\u201D\u4E2D\u67E5\u770B\u6240\u6709\u8BA2\u5355\u7684\u72B6\u6001\uFF0C\u5305\u62EC\u5F85\u4ED8\u6B3E\u3001\u5F85\u53D1\u8D27\u3001\u5DF2\u53D1\u8D27\u7B49\u72B6\u6001\u3002 </div><div${_scopeId2}> 4\u3001\u662F\u5426\u652F\u6301\u8D27\u5230\u4ED8\u6B3E\uFF1F<br${_scopeId2}> \u7B54\uFF1A\u76EE\u524D\u6211\u4EEC\u6682\u65F6\u4E0D\u652F\u6301\u8D27\u5230\u4ED8\u6B3E\uFF0C\u4EC5\u652F\u6301\u5728\u7EBF\u652F\u4ED8\u3002 </div>`);
            } else {
              return [
                createVNode("div", null, [
                  createTextVNode(" 1\u3001\u5982\u4F55\u4E0B\u5355\u8D2D\u4E70\u5546\u54C1\uFF1F"),
                  createVNode("br"),
                  createTextVNode(" \u7B54\uFF1A\u5728\u60A8\u6D4F\u89C8\u5546\u54C1\u65F6\uFF0C\u70B9\u51FB\u201C\u52A0\u5165\u8D2D\u7269\u8F66\u201D\uFF0C\u786E\u8BA4\u8D2D\u7269\u8F66\u4E2D\u7684\u5546\u54C1\uFF0C\u7136\u540E\u70B9\u51FB\u201C\u7ED3\u7B97\u5E76\u4ED8\u6B3E\u201D\uFF0C\u9009\u62E9\u4ED8\u6B3E\u65B9\u5F0F\u548C\u6536\u8D27\u5730\u5740\u5373\u53EF\u4E0B\u5355\u8D2D\u4E70\u3002 ")
                ]),
                createVNode("div", null, [
                  createTextVNode(" 2\u3001\u5546\u54C1\u53D1\u8D27\u65F6\u95F4\u662F\u591A\u4E45\uFF1F"),
                  createVNode("br"),
                  createTextVNode(" \u7B54\uFF1A\u901A\u5E38\u60C5\u51B5\u4E0B\uFF0C\u6211\u4EEC\u5C06\u572824\u5C0F\u65F6\u5185\u53D1\u8D27\u3002\u5982\u679C\u51FA\u73B0\u7279\u6B8A\u60C5\u51B5\uFF0C\u4F8B\u5982\u8282\u5047\u65E5\u7B49\uFF0C\u6211\u4EEC\u5C06\u63D0\u524D\u5728\u7F51\u7AD9\u4E0A\u8FDB\u884C\u901A\u77E5\u3002 ")
                ]),
                createVNode("div", null, [
                  createTextVNode(" 3\u3001\u5982\u4F55\u67E5\u8BE2\u6211\u7684\u8BA2\u5355\u72B6\u6001\uFF1F"),
                  createVNode("br"),
                  createTextVNode(" \u7B54\uFF1A\u60A8\u53EF\u4EE5\u5728\u201C\u6211\u7684\u8BA2\u5355\u201D\u4E2D\u67E5\u770B\u6240\u6709\u8BA2\u5355\u7684\u72B6\u6001\uFF0C\u5305\u62EC\u5F85\u4ED8\u6B3E\u3001\u5F85\u53D1\u8D27\u3001\u5DF2\u53D1\u8D27\u7B49\u72B6\u6001\u3002 ")
                ]),
                createVNode("div", null, [
                  createTextVNode(" 4\u3001\u662F\u5426\u652F\u6301\u8D27\u5230\u4ED8\u6B3E\uFF1F"),
                  createVNode("br"),
                  createTextVNode(" \u7B54\uFF1A\u76EE\u524D\u6211\u4EEC\u6682\u65F6\u4E0D\u652F\u6301\u8D27\u5230\u4ED8\u6B3E\uFF0C\u4EC5\u652F\u6301\u5728\u7EBF\u652F\u4ED8\u3002 ")
                ])
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_el_collapse_item, { name: "1" }, {
            title: withCtx(() => [
              createVNode("li", {
                "text-4": "",
                "my-2": "",
                "font-700": "",
                style: { "list-style": "circle" }
              }, [
                createTextVNode(" \u5E38\u89C1\u95EE\u9898\uFF1F "),
                createVNode("i", {
                  "i-solar:question-circle-broken": "",
                  "p-2": ""
                })
              ])
            ]),
            default: withCtx(() => [
              createVNode("div", null, [
                createTextVNode(" 1\u3001\u5982\u4F55\u4E0B\u5355\u8D2D\u4E70\u5546\u54C1\uFF1F"),
                createVNode("br"),
                createTextVNode(" \u7B54\uFF1A\u5728\u60A8\u6D4F\u89C8\u5546\u54C1\u65F6\uFF0C\u70B9\u51FB\u201C\u52A0\u5165\u8D2D\u7269\u8F66\u201D\uFF0C\u786E\u8BA4\u8D2D\u7269\u8F66\u4E2D\u7684\u5546\u54C1\uFF0C\u7136\u540E\u70B9\u51FB\u201C\u7ED3\u7B97\u5E76\u4ED8\u6B3E\u201D\uFF0C\u9009\u62E9\u4ED8\u6B3E\u65B9\u5F0F\u548C\u6536\u8D27\u5730\u5740\u5373\u53EF\u4E0B\u5355\u8D2D\u4E70\u3002 ")
              ]),
              createVNode("div", null, [
                createTextVNode(" 2\u3001\u5546\u54C1\u53D1\u8D27\u65F6\u95F4\u662F\u591A\u4E45\uFF1F"),
                createVNode("br"),
                createTextVNode(" \u7B54\uFF1A\u901A\u5E38\u60C5\u51B5\u4E0B\uFF0C\u6211\u4EEC\u5C06\u572824\u5C0F\u65F6\u5185\u53D1\u8D27\u3002\u5982\u679C\u51FA\u73B0\u7279\u6B8A\u60C5\u51B5\uFF0C\u4F8B\u5982\u8282\u5047\u65E5\u7B49\uFF0C\u6211\u4EEC\u5C06\u63D0\u524D\u5728\u7F51\u7AD9\u4E0A\u8FDB\u884C\u901A\u77E5\u3002 ")
              ]),
              createVNode("div", null, [
                createTextVNode(" 3\u3001\u5982\u4F55\u67E5\u8BE2\u6211\u7684\u8BA2\u5355\u72B6\u6001\uFF1F"),
                createVNode("br"),
                createTextVNode(" \u7B54\uFF1A\u60A8\u53EF\u4EE5\u5728\u201C\u6211\u7684\u8BA2\u5355\u201D\u4E2D\u67E5\u770B\u6240\u6709\u8BA2\u5355\u7684\u72B6\u6001\uFF0C\u5305\u62EC\u5F85\u4ED8\u6B3E\u3001\u5F85\u53D1\u8D27\u3001\u5DF2\u53D1\u8D27\u7B49\u72B6\u6001\u3002 ")
              ]),
              createVNode("div", null, [
                createTextVNode(" 4\u3001\u662F\u5426\u652F\u6301\u8D27\u5230\u4ED8\u6B3E\uFF1F"),
                createVNode("br"),
                createTextVNode(" \u7B54\uFF1A\u76EE\u524D\u6211\u4EEC\u6682\u65F6\u4E0D\u652F\u6301\u8D27\u5230\u4ED8\u6B3E\uFF0C\u4EC5\u652F\u6301\u5728\u7EBF\u652F\u4ED8\u3002 ")
              ])
            ]),
            _: 1
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<li text-4 my-2 mb-4 font-700 style="${ssrRenderStyle({ "list-style": "circle" })}">\u8D2D\u4E70\u987B\u77E5\uFF1A</li><p style="${ssrRenderStyle({ "text-indent": "2em", "line-height": "1.4em" })}" opacity-80 animate-head-shake> \u5546\u54C1\u5C55\u793A\u7684\u5212\u7EBF\u4EF7\u6216\u6307\u5BFC\u4EF7\u53EF\u80FD\u662F\u5546\u54C1\u5236\u9020\u5382\u5546\u7684\u96F6\u552E\u5E02\u573A\u6307\u5BFC\u4EF7\u3001\u54C1\u724C\u4E13\u67DC\u4EF7\u3001\u5546\u54C1\u540A\u724C\u4EF7\u6216\u8BE5\u5546\u54C1\u5728\u6781\u7269\u5708\u4E0A\u66FE\u7ECF\u5C55\u793A\u8FC7\u7684\u9500\u552E\u4EF7\uFF1B\u7531\u4E8E\u5730\u533A\u3001\u65F6\u95F4\u7684\u4E0D\u540C\u548C\u5E02\u573A\u6CE2\u52A8\uFF0C\u54C1\u724C\u4E13\u67DC\u6807\u4EF7\u3001\u5546\u54C1\u540A\u724C\u4EF7\u7B49\u53EF\u80FD\u4F1A\u4E0E\u60A8\u8D2D\u7269\u65F6\u5C55\u793A\u7684\u4E0D\u4E00\u81F4\uFF0C\u8BE5\u4EF7\u683C\u4EC5\u4F9B\u60A8\u53C2\u8003\u3002 \u56E0\u7CFB\u7EDF\u7F13\u5B58\u66F4\u65B0\u5EF6\u8FDF\u7B49\u4E0D\u786E\u5B9A\u6027\u60C5\u51B5\uFF0C\u53EF\u80FD\u5BFC\u81F4\u4EF7\u683C\u663E\u793A\u5F02\u5E38\uFF0C\u5546\u54C1\u5177\u4F53\u552E\u4EF7\u8BF7\u4EE5\u8BA2\u5355\u7ED3\u7B97\u9875\u4EF7\u683C\u4E3A\u51C6\u3002 \u82E5\u60A8\u5BF9\u5546\u54C1\u5C55\u793A\u6709\u7591\u95EE\uFF0C\u6B22\u8FCE\u54A8\u8BE2\u5BA2\u670D\u3002 \u4E3A\u4FDD\u62A4\u5E7F\u5927\u6D88\u8D39\u8005\u7684\u5229\u76CA\uFF0C\u6781\u7269\u5708\u62B5\u5236\u56E4\u79EF\u5C45\u5947\u7B49\u6270\u4E71\u5E02\u573A\u7684\u884C\u4E3A\uFF0C\u6211\u4EEC\u4F1A\u5BF9\u5546\u54C1\u7684\u4E0B\u5355\u8FDB\u884C\u98CE\u9669\u63A7\u5236\uFF0C\u5E76\u4FDD\u7559\u53D6\u6D88\u975E\u6B63\u5E38\u8D2D\u4E70\u8BA2\u5355\u4E4B\u6743\u5229\u3002 </p></div>`);
}
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Goods/OtherTmp.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_5 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "DetailTabs",
  __ssrInlineRender: true,
  props: {
    goodsInfo: {},
    skuList: {}
  },
  setup(__props) {
    const activeMenu = ref("detail");
    return (_ctx, _push, _parent, _attrs) => {
      const _component_el_tabs = ElTabs;
      const _component_el_tab_pane = ElTabPane;
      const _component_el_text = ElText;
      const _component_el_image = ElImage;
      const _component_GoodsComments = _sfc_main$3;
      const _component_GoodsOtherTmp = __nuxt_component_5;
      _push(ssrRenderComponent(_component_el_tabs, mergeProps({
        class: "goods-tabs min-h-50vh",
        "tab-position": "top",
        modelValue: unref(activeMenu),
        "onUpdate:modelValue": ($event) => isRef(activeMenu) ? activeMenu.value = $event : null
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_el_tab_pane, {
              name: "detail",
              class: "animate__animated animate__fadeIn mt-2",
              label: "\u8BE6 \u60C5"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l;
                if (_push3) {
                  _push3(`<h3 px-4 mb-2 data-v-222be6b0${_scopeId2}>${ssrInterpolate((_a = _ctx.goodsInfo) == null ? void 0 : _a.name)}</h3><div class="text" leading-2em px-4 border-default-dashed rounded-6px mb-4 data-v-222be6b0${_scopeId2}><small data-v-222be6b0${_scopeId2}> \u53D1\u8D27\u5730\uFF1A${ssrInterpolate((((_b = _ctx.goodsInfo) == null ? void 0 : _b.province) || "") + (((_c = _ctx.goodsInfo) == null ? void 0 : _c.city) || "") + ((_d = _ctx.goodsInfo) == null ? void 0 : _d.district))}</small><br data-v-222be6b0${_scopeId2}><small data-v-222be6b0${_scopeId2}> \u4FDD\u969C\uFF1A `);
                  if ((_e = _ctx.goodsInfo) == null ? void 0 : _e.refundTime) {
                    _push3(ssrRenderComponent(_component_el_text, null, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        var _a2, _b2;
                        if (_push4) {
                          _push4(`${ssrInterpolate((_a2 = _ctx.goodsInfo) == null ? void 0 : _a2.refundTime)}\u65E5\u65E0\u7406\u7531\u9000\u6362\u8D27`);
                        } else {
                          return [
                            createTextVNode(toDisplayString((_b2 = _ctx.goodsInfo) == null ? void 0 : _b2.refundTime) + "\u65E5\u65E0\u7406\u7531\u9000\u6362\u8D27", 1)
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</small></div><div class="imgs" flex flex-col data-v-222be6b0${_scopeId2}><!--[-->`);
                  ssrRenderList((_f = _ctx.goodsInfo) == null ? void 0 : _f.images, (p, i) => {
                    _push3(ssrRenderComponent(_component_el_image, {
                      style: { "width": "80%", "margin": "0.4em 0" },
                      src: ("BaseUrlImg" in _ctx ? _ctx.BaseUrlImg : unref(BaseUrlImg)) + p,
                      key: p
                    }, null, _parent3, _scopeId2));
                  });
                  _push3(`<!--]--></div>`);
                } else {
                  return [
                    createVNode("h3", {
                      "px-4": "",
                      "mb-2": ""
                    }, toDisplayString((_g = _ctx.goodsInfo) == null ? void 0 : _g.name), 1),
                    createVNode("div", {
                      class: "text",
                      "leading-2em": "",
                      "px-4": "",
                      "border-default-dashed": "",
                      "rounded-6px": "",
                      "mb-4": ""
                    }, [
                      createVNode("small", null, " \u53D1\u8D27\u5730\uFF1A" + toDisplayString((((_h = _ctx.goodsInfo) == null ? void 0 : _h.province) || "") + (((_i = _ctx.goodsInfo) == null ? void 0 : _i.city) || "") + ((_j = _ctx.goodsInfo) == null ? void 0 : _j.district)), 1),
                      createVNode("br"),
                      createVNode("small", null, [
                        createTextVNode(" \u4FDD\u969C\uFF1A "),
                        ((_k = _ctx.goodsInfo) == null ? void 0 : _k.refundTime) ? (openBlock(), createBlock(_component_el_text, { key: 0 }, {
                          default: withCtx(() => {
                            var _a2;
                            return [
                              createTextVNode(toDisplayString((_a2 = _ctx.goodsInfo) == null ? void 0 : _a2.refundTime) + "\u65E5\u65E0\u7406\u7531\u9000\u6362\u8D27", 1)
                            ];
                          }),
                          _: 1
                        })) : createCommentVNode("", true)
                      ])
                    ]),
                    createVNode("div", {
                      class: "imgs",
                      flex: "",
                      "flex-col": ""
                    }, [
                      (openBlock(true), createBlock(Fragment, null, renderList((_l = _ctx.goodsInfo) == null ? void 0 : _l.images, (p, i) => {
                        return openBlock(), createBlock(_component_el_image, {
                          style: { "width": "80%", "margin": "0.4em 0" },
                          src: ("BaseUrlImg" in _ctx ? _ctx.BaseUrlImg : unref(BaseUrlImg)) + p,
                          key: p
                        }, null, 8, ["src"]);
                      }), 128))
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_el_tab_pane, {
              name: "omments",
              lazy: "",
              class: "animate__animated animate__fadeIn mt-2",
              label: "\u8BC4 \u4EF7"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                var _a, _b;
                if (_push3) {
                  _push3(ssrRenderComponent(_component_GoodsComments, {
                    "goods-id": ((_a = _ctx.goodsInfo) == null ? void 0 : _a.id) || "",
                    "sku-list": _ctx.skuList
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_GoodsComments, {
                      "goods-id": ((_b = _ctx.goodsInfo) == null ? void 0 : _b.id) || "",
                      "sku-list": _ctx.skuList
                    }, null, 8, ["goods-id", "sku-list"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_el_tab_pane, {
              name: "other",
              lazy: "",
              class: "animate__animated animate__fadeIn mt-2",
              label: "\u5176 \u4ED6"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_GoodsOtherTmp, null, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_GoodsOtherTmp)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_el_tab_pane, {
                name: "detail",
                class: "animate__animated animate__fadeIn mt-2",
                label: "\u8BE6 \u60C5"
              }, {
                default: withCtx(() => {
                  var _a, _b, _c, _d, _e, _f;
                  return [
                    createVNode("h3", {
                      "px-4": "",
                      "mb-2": ""
                    }, toDisplayString((_a = _ctx.goodsInfo) == null ? void 0 : _a.name), 1),
                    createVNode("div", {
                      class: "text",
                      "leading-2em": "",
                      "px-4": "",
                      "border-default-dashed": "",
                      "rounded-6px": "",
                      "mb-4": ""
                    }, [
                      createVNode("small", null, " \u53D1\u8D27\u5730\uFF1A" + toDisplayString((((_b = _ctx.goodsInfo) == null ? void 0 : _b.province) || "") + (((_c = _ctx.goodsInfo) == null ? void 0 : _c.city) || "") + ((_d = _ctx.goodsInfo) == null ? void 0 : _d.district)), 1),
                      createVNode("br"),
                      createVNode("small", null, [
                        createTextVNode(" \u4FDD\u969C\uFF1A "),
                        ((_e = _ctx.goodsInfo) == null ? void 0 : _e.refundTime) ? (openBlock(), createBlock(_component_el_text, { key: 0 }, {
                          default: withCtx(() => {
                            var _a2;
                            return [
                              createTextVNode(toDisplayString((_a2 = _ctx.goodsInfo) == null ? void 0 : _a2.refundTime) + "\u65E5\u65E0\u7406\u7531\u9000\u6362\u8D27", 1)
                            ];
                          }),
                          _: 1
                        })) : createCommentVNode("", true)
                      ])
                    ]),
                    createVNode("div", {
                      class: "imgs",
                      flex: "",
                      "flex-col": ""
                    }, [
                      (openBlock(true), createBlock(Fragment, null, renderList((_f = _ctx.goodsInfo) == null ? void 0 : _f.images, (p, i) => {
                        return openBlock(), createBlock(_component_el_image, {
                          style: { "width": "80%", "margin": "0.4em 0" },
                          src: ("BaseUrlImg" in _ctx ? _ctx.BaseUrlImg : unref(BaseUrlImg)) + p,
                          key: p
                        }, null, 8, ["src"]);
                      }), 128))
                    ])
                  ];
                }),
                _: 1
              }),
              createVNode(_component_el_tab_pane, {
                name: "omments",
                lazy: "",
                class: "animate__animated animate__fadeIn mt-2",
                label: "\u8BC4 \u4EF7"
              }, {
                default: withCtx(() => {
                  var _a;
                  return [
                    createVNode(_component_GoodsComments, {
                      "goods-id": ((_a = _ctx.goodsInfo) == null ? void 0 : _a.id) || "",
                      "sku-list": _ctx.skuList
                    }, null, 8, ["goods-id", "sku-list"])
                  ];
                }),
                _: 1
              }),
              createVNode(_component_el_tab_pane, {
                name: "other",
                lazy: "",
                class: "animate__animated animate__fadeIn mt-2",
                label: "\u5176 \u4ED6"
              }, {
                default: withCtx(() => [
                  createVNode(_component_GoodsOtherTmp)
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Goods/DetailTabs.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_4 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-222be6b0"]]);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "[id]",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a, _b, _c, _d, _e, _f;
    let __temp, __restore;
    const route = useRoute();
    const user = useUserStore();
    const goodsId = route.params.id;
    const isLoading = ref(true);
    const reqGoodsInfo = getGoodsInfoById(goodsId.toString());
    let goodsInfo = ref();
    useAsyncData(async () => {
      if (user.isLogin) {
        await addGoodsViewsById(goodsId.toString(), user.getToken);
      }
    }, "$3uEUgPC4sJ");
    const reqGoodsSku = getGoodsSkuByGid(goodsId.toString());
    let goodsSku = ref();
    const goodsImages = ref(/* @__PURE__ */ new Set());
    const reqArr = ([__temp, __restore] = withAsyncContext(() => Promise.all([reqGoodsInfo, reqGoodsSku])), __temp = await __temp, __restore(), __temp);
    const goodsInfoRaw = (_a = reqArr[0].data.value) == null ? void 0 : _a.data;
    const goodsSkuRaw = (_b = reqArr[1].data.value) == null ? void 0 : _b.data;
    if (!goodsInfoRaw || !goodsSkuRaw) {
      navigateTo("/");
    }
    if (goodsInfoRaw) {
      if (goodsInfoRaw.images) {
        goodsInfoRaw.images = goodsInfoRaw == null ? void 0 : goodsInfoRaw.images.toString().split(",");
      }
      goodsInfo = toRef(goodsInfoRaw);
      (_c = goodsInfoRaw == null ? void 0 : goodsInfoRaw.images) == null ? void 0 : _c.forEach((p) => {
        goodsImages.value.add(p);
      });
      goodsSku = toRef(goodsSkuRaw);
      goodsSkuRaw == null ? void 0 : goodsSkuRaw.forEach((p) => {
        goodsImages.value.add(p.image);
      });
    }
    isLoading.value = false;
    const goodsSwiper = ref();
    const setActive = (name) => {
      var _a2;
      (_a2 = goodsSwiper == null ? void 0 : goodsSwiper.value) == null ? void 0 : _a2.setActiveItem(name);
    };
    useHead({
      title: "\u6781\u7269 " + ((_d = goodsInfo.value) == null ? void 0 : _d.name),
      meta: [
        {
          name: "description",
          content: ((_e = goodsInfo.value) == null ? void 0 : _e.name) + " " + ((_f = goodsInfo.value) == null ? void 0 : _f.description)
        }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLayout = __nuxt_component_0;
      const _component_GoodsCategoryTree = _sfc_main$7;
      const _component_GoodsPreSwiper = __nuxt_component_2;
      const _component_GoodsSkuCard = __nuxt_component_3;
      const _component_GoodsDetailTabs = __nuxt_component_4;
      const _component_ListGoodsList = __nuxt_component_6;
      _push(ssrRenderComponent(_component_NuxtLayout, mergeProps({
        menu: ["shopcart", "back"],
        "left-menu": false
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a2, _b2, _c2, _d2, _e2, _f2, _g, _h;
          if (_push2) {
            _push2(`<div layout-default class="goods-detail" data-v-8e9053af${_scopeId}><div class="top" flex items-center data-v-8e9053af${_scopeId}>`);
            _push2(ssrRenderComponent(_component_GoodsCategoryTree, {
              class: "left",
              gid: unref(goodsId).toString(),
              name: (_a2 = unref(goodsInfo)) == null ? void 0 : _a2.name
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="center" mt-2.2em flex justify-around items-center data-v-8e9053af${_scopeId}>`);
            _push2(ssrRenderComponent(_component_GoodsPreSwiper, {
              class: "swiper ml-0em flex-2 animate__animated animate__fadeIn",
              "w-600px": "",
              images: [...unref(goodsImages)],
              video: (_b2 = unref(goodsInfo)) == null ? void 0 : _b2.video,
              "goods-name": (_c2 = unref(goodsInfo)) == null ? void 0 : _c2.name,
              ref_key: "goodsSwiper",
              ref: goodsSwiper
            }, null, _parent2, _scopeId));
            _push2(`<div class="card flex-1 animate__animated animate__fadeIn" pl-20em pr-4em data-v-8e9053af${_scopeId}>`);
            _push2(ssrRenderComponent(_component_GoodsSkuCard, {
              "goods-info": unref(goodsInfo),
              "goods-sku": unref(goodsSku),
              onSetActiveItem: setActive
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div flex justify-between mt-5em border-default border-0 border-t="2px solid" py-3em class="bottom" data-v-8e9053af${_scopeId}><div class="left" data-v-8e9053af${_scopeId}><h2 tracking-0.1em data-v-8e9053af${_scopeId}><i i-solar:bolt-outline bg-amber p-3.5 mr-2 data-v-8e9053af${_scopeId}></i>\u5546\u54C1\u4ECB\u7ECD</h2>`);
            _push2(ssrRenderComponent(_component_GoodsDetailTabs, {
              class: "w-640px detail",
              "goods-info": unref(goodsInfo),
              "sku-list": unref(goodsSku),
              "py-1em": "",
              "rounded-10px": "",
              "dark:opacity-90": "",
              "min-h-700px": "",
              "shadow-sm": ""
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="w-2/5" data-v-8e9053af${_scopeId}><h2 tracking-0.1em mb-0.8em data-v-8e9053af${_scopeId}><i i-solar:bomb-emoji-outline bg-lime p-4 mr-2 data-v-8e9053af${_scopeId}></i> \u731C\u4F60\u559C\u6B22 </h2>`);
            _push2(ssrRenderComponent(_component_ListGoodsList, {
              class: "w-1/1",
              dto: { name: (_d2 = unref(goodsInfo)) == null ? void 0 : _d2.name[Math.floor(Math.random())] },
              limit: 10
            }, null, _parent2, _scopeId));
            _push2(`</div></div></div>`);
          } else {
            return [
              createVNode("div", {
                "layout-default": "",
                class: "goods-detail"
              }, [
                createVNode("div", {
                  class: "top",
                  flex: "",
                  "items-center": ""
                }, [
                  createVNode(_component_GoodsCategoryTree, {
                    class: "left",
                    gid: unref(goodsId).toString(),
                    name: (_e2 = unref(goodsInfo)) == null ? void 0 : _e2.name
                  }, null, 8, ["gid", "name"])
                ]),
                createVNode("div", {
                  class: "center",
                  "mt-2.2em": "",
                  flex: "",
                  "justify-around": "",
                  "items-center": ""
                }, [
                  createVNode(_component_GoodsPreSwiper, {
                    class: "swiper ml-0em flex-2 animate__animated animate__fadeIn",
                    "w-600px": "",
                    images: [...unref(goodsImages)],
                    video: (_f2 = unref(goodsInfo)) == null ? void 0 : _f2.video,
                    "goods-name": (_g = unref(goodsInfo)) == null ? void 0 : _g.name,
                    ref_key: "goodsSwiper",
                    ref: goodsSwiper
                  }, null, 8, ["images", "video", "goods-name"]),
                  createVNode("div", {
                    class: "card flex-1 animate__animated animate__fadeIn",
                    "pl-20em": "",
                    "pr-4em": ""
                  }, [
                    createVNode(_component_GoodsSkuCard, {
                      "goods-info": unref(goodsInfo),
                      "goods-sku": unref(goodsSku),
                      onSetActiveItem: setActive
                    }, null, 8, ["goods-info", "goods-sku"])
                  ])
                ]),
                createVNode("div", {
                  flex: "",
                  "justify-between": "",
                  "mt-5em": "",
                  "border-default": "",
                  "border-0": "",
                  "border-t": "2px solid",
                  "py-3em": "",
                  class: "bottom"
                }, [
                  createVNode("div", { class: "left" }, [
                    createVNode("h2", { "tracking-0.1em": "" }, [
                      createVNode("i", {
                        "i-solar:bolt-outline": "",
                        "bg-amber": "",
                        "p-3.5": "",
                        "mr-2": ""
                      }),
                      createTextVNode("\u5546\u54C1\u4ECB\u7ECD")
                    ]),
                    createVNode(_component_GoodsDetailTabs, {
                      class: "w-640px detail",
                      "goods-info": unref(goodsInfo),
                      "sku-list": unref(goodsSku),
                      "py-1em": "",
                      "rounded-10px": "",
                      "dark:opacity-90": "",
                      "min-h-700px": "",
                      "shadow-sm": ""
                    }, null, 8, ["goods-info", "sku-list"])
                  ]),
                  createVNode("div", { class: "w-2/5" }, [
                    createVNode("h2", {
                      "tracking-0.1em": "",
                      "mb-0.8em": ""
                    }, [
                      createVNode("i", {
                        "i-solar:bomb-emoji-outline": "",
                        "bg-lime": "",
                        "p-4": "",
                        "mr-2": ""
                      }),
                      createTextVNode(" \u731C\u4F60\u559C\u6B22 ")
                    ]),
                    createVNode(_component_ListGoodsList, {
                      class: "w-1/1",
                      dto: { name: (_h = unref(goodsInfo)) == null ? void 0 : _h.name[Math.floor(Math.random())] },
                      limit: 10
                    }, null, 8, ["dto"])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/goods/detail/[id].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _id_ = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-8e9053af"]]);

export { _id_ as default };
//# sourceMappingURL=_id_-a48dba4b.mjs.map
