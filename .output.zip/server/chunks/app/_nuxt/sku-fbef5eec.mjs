import { u as useFetch } from './fetch-da5935af.mjs';
import { b as BaseUrl } from './useFetchUtil-5309feca.mjs';
import { $ as useHttp } from '../server.mjs';

function getGoodsSkuByGid(gid) {
  return useFetch(BaseUrl + `/goods/sku?gid=${gid}`, "$AfkcphgTcz");
}
function getGoodsSkuByIds(ids) {
  return useHttp.post(`/goods/sku`, {
    ids: [...ids]
  });
}

export { getGoodsSkuByIds as a, getGoodsSkuByGid as g };
//# sourceMappingURL=sku-fbef5eec.mjs.map
