import { _ as __nuxt_component_0 } from './layout-9cd450dc.mjs';
import { defineComponent, withAsyncContext, withCtx, createVNode, useSSRContext } from 'vue';
import { a as useRoute, b as useHead, X as appName } from '../server.mjs';
import { ssrRenderComponent } from 'vue/server-renderer';
import { a as getGoodsSkuByIds } from './sku-fbef5eec.mjs';
import 'vue-router';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'destr';
import 'h3';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'ufo';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import 'pinia-plugin-persistedstate';
import 'gsap';
import 'lodash-unified';
import 'nprogress';
import '@kangc/v-md-editor';
import 'async-validator';
import '@ctrl/tinycolor';
import 'defu';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'klona';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import './fetch-da5935af.mjs';
import './useFetchUtil-5309feca.mjs';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "list",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a;
    let __temp, __restore;
    const route = useRoute();
    const orderItems = (_a = route.query) == null ? void 0 : _a.orderItems;
    const skuIdList = [];
    orderItems.forEach((p) => {
      skuIdList.push(p.skuId);
    });
    [__temp, __restore] = withAsyncContext(() => getGoodsSkuByIds(skuIdList)), __temp = await __temp, __restore();
    useHead({
      title: appName + " - \u8BA2\u5355",
      meta: [
        {
          name: "description",
          content: "\u6781\u7269\u5708-\u6211\u7684\u8BA2\u5355"
        }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLayout = __nuxt_component_0;
      _push(ssrRenderComponent(_component_NuxtLayout, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div layout-default w-700px${_scopeId}><div class="top" border-default border-0 border-b="2px"${_scopeId}><h3 mb-4${_scopeId}>dd</h3></div></div>`);
          } else {
            return [
              createVNode("div", {
                "layout-default": "",
                "w-700px": ""
              }, [
                createVNode("div", {
                  class: "top",
                  "border-default": "",
                  "border-0": "",
                  "border-b": "2px"
                }, [
                  createVNode("h3", { "mb-4": "" }, "dd")
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/order/list.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=list-e64cfdde.mjs.map
