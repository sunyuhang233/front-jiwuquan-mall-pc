import { b as buildAssetsURL } from '../../handlers/renderer.mjs';

const _imports_0 = "" + buildAssetsURL("logo.f2f3cfb9.png");
const _imports_1 = "" + buildAssetsURL("logo_dark.692df090.png");

export { _imports_0 as _, _imports_1 as a };
//# sourceMappingURL=logo_dark-b7cf3e36.mjs.map
