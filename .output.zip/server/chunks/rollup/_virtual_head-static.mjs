const _virtual__headStatic = {"headTags":"<meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<meta name=\"description\" content=\"极物圈\">\n<meta name=\"apple-mobile-web-app-status-bar-style\" content=\"black-translucent\">\n<link rel=\"icon\" href=\"/logo.png\" sizes=\"any\">\n<link rel=\"apple-touch-icon\" href=\"/logo.png\">","bodyTags":"","bodyTagsOpen":"","htmlAttrs":"","bodyAttrs":""};

export { _virtual__headStatic as default };
//# sourceMappingURL=_virtual_head-static.mjs.map
