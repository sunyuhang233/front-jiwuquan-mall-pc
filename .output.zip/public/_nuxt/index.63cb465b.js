import{a as e,j as c,o as n}from"./entry.1e2e194c.js";const o={};function r(t,a){return n(),c("div")}const _=e(o,[["render",r]]);export{_ as default};
