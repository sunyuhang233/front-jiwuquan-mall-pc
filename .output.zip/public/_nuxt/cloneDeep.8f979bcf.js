import{bS as o}from"./entry.90c9e699.js";var r=1,n=4;function a(e){return o(e,r|n)}export{a as c};
