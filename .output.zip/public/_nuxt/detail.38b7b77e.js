import{f as t,h as a,o,i as s,t as n,u as r}from"./entry.556ed651.js";const l=t({__name:"detail",setup(u){const e=a();return(c,i)=>(o(),s("div",null,n(r(e).params.id),1))}});export{l as default};
