import{a as e,j as c,o}from"./entry.1e2e194c.js";const n={};function r(t,a){return o(),c("div")}const _=e(n,[["render",r]]);export{_ as default};
