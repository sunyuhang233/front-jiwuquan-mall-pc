import"./entry.90c9e699.js";const o=""+new URL("logo_txt.318d9294.png",import.meta.url).href;export{o as _};
