import{by as e}from"./entry.90c9e699.js";const s=e(),r=s+"/res/image/",o=s+"/res/video/";export{r as B,o as a,s as b};
