import{aY as o,aM as a,aZ as r}from"./entry.556ed651.js";const n=o((s,t)=>{const e=a();if(!(s.meta.isPermission&&e.token!==""&&e.isLogin))return r({...t})});export{n as default};
