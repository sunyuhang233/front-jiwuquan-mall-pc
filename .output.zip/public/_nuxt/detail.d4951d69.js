import{f as t,h as a,o,j as s,t as n,u as r}from"./entry.1e2e194c.js";const l=t({__name:"detail",setup(u){const e=a();return(c,p)=>(o(),s("div",null,n(r(e).params.id),1))}});export{l as default};
