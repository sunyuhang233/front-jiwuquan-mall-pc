import{a as e,i as o,o as t,b as c}from"./entry.556ed651.js";const n={},s=c("h3",null,"搜索记录",-1),a=[s];function r(_,d){return t(),o("div",null,a)}const l=e(n,[["render",r]]);export{l as default};
