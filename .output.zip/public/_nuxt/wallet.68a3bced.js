import{a as e,j as c,o as t}from"./entry.1e2e194c.js";const o={};function r(a,n){return t(),c("div")}const _=e(o,[["render",r]]);export{_ as default};
