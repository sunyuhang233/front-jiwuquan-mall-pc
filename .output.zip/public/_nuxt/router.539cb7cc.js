import{aW as o,aI as a,aX as r}from"./entry.1e2e194c.js";const n=o((s,t)=>{const e=a();if(!(s.meta.isPermission&&e.token!==""&&e.isLogin))return r({...t})});export{n as default};
