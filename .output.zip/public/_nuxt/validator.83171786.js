import{bu as i}from"./entry.90c9e699.js";const n=o=>["",...i].includes(o);export{n as i};
