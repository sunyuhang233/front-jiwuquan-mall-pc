import{f as t,h as a,o,j as s,t as n,u as r}from"./entry.1e2e194c.js";const _=t({__name:"[id]",setup(u){const e=a();return(c,p)=>(o(),s("div",null,n(r(e).params.id),1))}});export{_ as default};
